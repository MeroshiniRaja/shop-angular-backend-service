/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 915:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "ArchivalSummaryFilterSensitiveLog": () => (/* reexport */ ArchivalSummaryFilterSensitiveLog),
  "AttributeDefinitionFilterSensitiveLog": () => (/* reexport */ AttributeDefinitionFilterSensitiveLog),
  "AttributeValue": () => (/* reexport */ AttributeValue),
  "AttributeValueFilterSensitiveLog": () => (/* reexport */ AttributeValueFilterSensitiveLog),
  "AttributeValueUpdateFilterSensitiveLog": () => (/* reexport */ AttributeValueUpdateFilterSensitiveLog),
  "AutoScalingPolicyDescriptionFilterSensitiveLog": () => (/* reexport */ AutoScalingPolicyDescriptionFilterSensitiveLog),
  "AutoScalingPolicyUpdateFilterSensitiveLog": () => (/* reexport */ AutoScalingPolicyUpdateFilterSensitiveLog),
  "AutoScalingSettingsDescriptionFilterSensitiveLog": () => (/* reexport */ AutoScalingSettingsDescriptionFilterSensitiveLog),
  "AutoScalingSettingsUpdateFilterSensitiveLog": () => (/* reexport */ AutoScalingSettingsUpdateFilterSensitiveLog),
  "AutoScalingTargetTrackingScalingPolicyConfigurationDescriptionFilterSensitiveLog": () => (/* reexport */ AutoScalingTargetTrackingScalingPolicyConfigurationDescriptionFilterSensitiveLog),
  "AutoScalingTargetTrackingScalingPolicyConfigurationUpdateFilterSensitiveLog": () => (/* reexport */ AutoScalingTargetTrackingScalingPolicyConfigurationUpdateFilterSensitiveLog),
  "BackupDescriptionFilterSensitiveLog": () => (/* reexport */ BackupDescriptionFilterSensitiveLog),
  "BackupDetailsFilterSensitiveLog": () => (/* reexport */ BackupDetailsFilterSensitiveLog),
  "BackupInUseException": () => (/* reexport */ BackupInUseException),
  "BackupNotFoundException": () => (/* reexport */ BackupNotFoundException),
  "BackupSummaryFilterSensitiveLog": () => (/* reexport */ BackupSummaryFilterSensitiveLog),
  "BackupType": () => (/* reexport */ BackupType),
  "BackupTypeFilter": () => (/* reexport */ BackupTypeFilter),
  "BatchExecuteStatementCommand": () => (/* reexport */ BatchExecuteStatementCommand),
  "BatchExecuteStatementInputFilterSensitiveLog": () => (/* reexport */ BatchExecuteStatementInputFilterSensitiveLog),
  "BatchExecuteStatementOutputFilterSensitiveLog": () => (/* reexport */ BatchExecuteStatementOutputFilterSensitiveLog),
  "BatchGetItemCommand": () => (/* reexport */ BatchGetItemCommand),
  "BatchGetItemInputFilterSensitiveLog": () => (/* reexport */ BatchGetItemInputFilterSensitiveLog),
  "BatchGetItemOutputFilterSensitiveLog": () => (/* reexport */ BatchGetItemOutputFilterSensitiveLog),
  "BatchStatementErrorCodeEnum": () => (/* reexport */ BatchStatementErrorCodeEnum),
  "BatchStatementErrorFilterSensitiveLog": () => (/* reexport */ BatchStatementErrorFilterSensitiveLog),
  "BatchStatementRequestFilterSensitiveLog": () => (/* reexport */ BatchStatementRequestFilterSensitiveLog),
  "BatchStatementResponseFilterSensitiveLog": () => (/* reexport */ BatchStatementResponseFilterSensitiveLog),
  "BatchWriteItemCommand": () => (/* reexport */ BatchWriteItemCommand),
  "BatchWriteItemInputFilterSensitiveLog": () => (/* reexport */ BatchWriteItemInputFilterSensitiveLog),
  "BatchWriteItemOutputFilterSensitiveLog": () => (/* reexport */ BatchWriteItemOutputFilterSensitiveLog),
  "BillingModeSummaryFilterSensitiveLog": () => (/* reexport */ BillingModeSummaryFilterSensitiveLog),
  "CancellationReasonFilterSensitiveLog": () => (/* reexport */ CancellationReasonFilterSensitiveLog),
  "CapacityFilterSensitiveLog": () => (/* reexport */ CapacityFilterSensitiveLog),
  "ConditionCheckFilterSensitiveLog": () => (/* reexport */ ConditionCheckFilterSensitiveLog),
  "ConditionFilterSensitiveLog": () => (/* reexport */ ConditionFilterSensitiveLog),
  "ConditionalCheckFailedException": () => (/* reexport */ ConditionalCheckFailedException),
  "ConsumedCapacityFilterSensitiveLog": () => (/* reexport */ ConsumedCapacityFilterSensitiveLog),
  "ContinuousBackupsDescriptionFilterSensitiveLog": () => (/* reexport */ ContinuousBackupsDescriptionFilterSensitiveLog),
  "ContinuousBackupsUnavailableException": () => (/* reexport */ ContinuousBackupsUnavailableException),
  "ContributorInsightsSummaryFilterSensitiveLog": () => (/* reexport */ ContributorInsightsSummaryFilterSensitiveLog),
  "CreateBackupCommand": () => (/* reexport */ CreateBackupCommand),
  "CreateBackupInputFilterSensitiveLog": () => (/* reexport */ CreateBackupInputFilterSensitiveLog),
  "CreateBackupOutputFilterSensitiveLog": () => (/* reexport */ CreateBackupOutputFilterSensitiveLog),
  "CreateGlobalSecondaryIndexActionFilterSensitiveLog": () => (/* reexport */ CreateGlobalSecondaryIndexActionFilterSensitiveLog),
  "CreateGlobalTableCommand": () => (/* reexport */ CreateGlobalTableCommand),
  "CreateGlobalTableInputFilterSensitiveLog": () => (/* reexport */ CreateGlobalTableInputFilterSensitiveLog),
  "CreateGlobalTableOutputFilterSensitiveLog": () => (/* reexport */ CreateGlobalTableOutputFilterSensitiveLog),
  "CreateReplicaActionFilterSensitiveLog": () => (/* reexport */ CreateReplicaActionFilterSensitiveLog),
  "CreateReplicationGroupMemberActionFilterSensitiveLog": () => (/* reexport */ CreateReplicationGroupMemberActionFilterSensitiveLog),
  "CreateTableCommand": () => (/* reexport */ CreateTableCommand),
  "CreateTableInputFilterSensitiveLog": () => (/* reexport */ CreateTableInputFilterSensitiveLog),
  "CreateTableOutputFilterSensitiveLog": () => (/* reexport */ CreateTableOutputFilterSensitiveLog),
  "CsvOptionsFilterSensitiveLog": () => (/* reexport */ CsvOptionsFilterSensitiveLog),
  "DeleteBackupCommand": () => (/* reexport */ DeleteBackupCommand),
  "DeleteBackupInputFilterSensitiveLog": () => (/* reexport */ DeleteBackupInputFilterSensitiveLog),
  "DeleteBackupOutputFilterSensitiveLog": () => (/* reexport */ DeleteBackupOutputFilterSensitiveLog),
  "DeleteFilterSensitiveLog": () => (/* reexport */ DeleteFilterSensitiveLog),
  "DeleteGlobalSecondaryIndexActionFilterSensitiveLog": () => (/* reexport */ DeleteGlobalSecondaryIndexActionFilterSensitiveLog),
  "DeleteItemCommand": () => (/* reexport */ DeleteItemCommand),
  "DeleteItemInputFilterSensitiveLog": () => (/* reexport */ DeleteItemInputFilterSensitiveLog),
  "DeleteItemOutputFilterSensitiveLog": () => (/* reexport */ DeleteItemOutputFilterSensitiveLog),
  "DeleteReplicaActionFilterSensitiveLog": () => (/* reexport */ DeleteReplicaActionFilterSensitiveLog),
  "DeleteReplicationGroupMemberActionFilterSensitiveLog": () => (/* reexport */ DeleteReplicationGroupMemberActionFilterSensitiveLog),
  "DeleteRequestFilterSensitiveLog": () => (/* reexport */ DeleteRequestFilterSensitiveLog),
  "DeleteTableCommand": () => (/* reexport */ DeleteTableCommand),
  "DeleteTableInputFilterSensitiveLog": () => (/* reexport */ DeleteTableInputFilterSensitiveLog),
  "DeleteTableOutputFilterSensitiveLog": () => (/* reexport */ DeleteTableOutputFilterSensitiveLog),
  "DescribeBackupCommand": () => (/* reexport */ DescribeBackupCommand),
  "DescribeBackupInputFilterSensitiveLog": () => (/* reexport */ DescribeBackupInputFilterSensitiveLog),
  "DescribeBackupOutputFilterSensitiveLog": () => (/* reexport */ DescribeBackupOutputFilterSensitiveLog),
  "DescribeContinuousBackupsCommand": () => (/* reexport */ DescribeContinuousBackupsCommand),
  "DescribeContinuousBackupsInputFilterSensitiveLog": () => (/* reexport */ DescribeContinuousBackupsInputFilterSensitiveLog),
  "DescribeContinuousBackupsOutputFilterSensitiveLog": () => (/* reexport */ DescribeContinuousBackupsOutputFilterSensitiveLog),
  "DescribeContributorInsightsCommand": () => (/* reexport */ DescribeContributorInsightsCommand),
  "DescribeContributorInsightsInputFilterSensitiveLog": () => (/* reexport */ DescribeContributorInsightsInputFilterSensitiveLog),
  "DescribeContributorInsightsOutputFilterSensitiveLog": () => (/* reexport */ DescribeContributorInsightsOutputFilterSensitiveLog),
  "DescribeEndpointsCommand": () => (/* reexport */ DescribeEndpointsCommand),
  "DescribeEndpointsRequestFilterSensitiveLog": () => (/* reexport */ DescribeEndpointsRequestFilterSensitiveLog),
  "DescribeEndpointsResponseFilterSensitiveLog": () => (/* reexport */ DescribeEndpointsResponseFilterSensitiveLog),
  "DescribeExportCommand": () => (/* reexport */ DescribeExportCommand),
  "DescribeExportInputFilterSensitiveLog": () => (/* reexport */ DescribeExportInputFilterSensitiveLog),
  "DescribeExportOutputFilterSensitiveLog": () => (/* reexport */ DescribeExportOutputFilterSensitiveLog),
  "DescribeGlobalTableCommand": () => (/* reexport */ DescribeGlobalTableCommand),
  "DescribeGlobalTableInputFilterSensitiveLog": () => (/* reexport */ DescribeGlobalTableInputFilterSensitiveLog),
  "DescribeGlobalTableOutputFilterSensitiveLog": () => (/* reexport */ DescribeGlobalTableOutputFilterSensitiveLog),
  "DescribeGlobalTableSettingsCommand": () => (/* reexport */ DescribeGlobalTableSettingsCommand),
  "DescribeGlobalTableSettingsInputFilterSensitiveLog": () => (/* reexport */ DescribeGlobalTableSettingsInputFilterSensitiveLog),
  "DescribeGlobalTableSettingsOutputFilterSensitiveLog": () => (/* reexport */ DescribeGlobalTableSettingsOutputFilterSensitiveLog),
  "DescribeImportCommand": () => (/* reexport */ DescribeImportCommand),
  "DescribeImportInputFilterSensitiveLog": () => (/* reexport */ DescribeImportInputFilterSensitiveLog),
  "DescribeImportOutputFilterSensitiveLog": () => (/* reexport */ DescribeImportOutputFilterSensitiveLog),
  "DescribeKinesisStreamingDestinationCommand": () => (/* reexport */ DescribeKinesisStreamingDestinationCommand),
  "DescribeKinesisStreamingDestinationInputFilterSensitiveLog": () => (/* reexport */ DescribeKinesisStreamingDestinationInputFilterSensitiveLog),
  "DescribeKinesisStreamingDestinationOutputFilterSensitiveLog": () => (/* reexport */ DescribeKinesisStreamingDestinationOutputFilterSensitiveLog),
  "DescribeLimitsCommand": () => (/* reexport */ DescribeLimitsCommand),
  "DescribeLimitsInputFilterSensitiveLog": () => (/* reexport */ DescribeLimitsInputFilterSensitiveLog),
  "DescribeLimitsOutputFilterSensitiveLog": () => (/* reexport */ DescribeLimitsOutputFilterSensitiveLog),
  "DescribeTableCommand": () => (/* reexport */ DescribeTableCommand),
  "DescribeTableInputFilterSensitiveLog": () => (/* reexport */ DescribeTableInputFilterSensitiveLog),
  "DescribeTableOutputFilterSensitiveLog": () => (/* reexport */ DescribeTableOutputFilterSensitiveLog),
  "DescribeTableReplicaAutoScalingCommand": () => (/* reexport */ DescribeTableReplicaAutoScalingCommand),
  "DescribeTableReplicaAutoScalingInputFilterSensitiveLog": () => (/* reexport */ DescribeTableReplicaAutoScalingInputFilterSensitiveLog),
  "DescribeTableReplicaAutoScalingOutputFilterSensitiveLog": () => (/* reexport */ DescribeTableReplicaAutoScalingOutputFilterSensitiveLog),
  "DescribeTimeToLiveCommand": () => (/* reexport */ DescribeTimeToLiveCommand),
  "DescribeTimeToLiveInputFilterSensitiveLog": () => (/* reexport */ DescribeTimeToLiveInputFilterSensitiveLog),
  "DescribeTimeToLiveOutputFilterSensitiveLog": () => (/* reexport */ DescribeTimeToLiveOutputFilterSensitiveLog),
  "DisableKinesisStreamingDestinationCommand": () => (/* reexport */ DisableKinesisStreamingDestinationCommand),
  "DuplicateItemException": () => (/* reexport */ DuplicateItemException),
  "DynamoDB": () => (/* reexport */ DynamoDB),
  "DynamoDBClient": () => (/* reexport */ DynamoDBClient),
  "DynamoDBServiceException": () => (/* reexport */ DynamoDBServiceException),
  "EnableKinesisStreamingDestinationCommand": () => (/* reexport */ EnableKinesisStreamingDestinationCommand),
  "EndpointFilterSensitiveLog": () => (/* reexport */ EndpointFilterSensitiveLog),
  "ExecuteStatementCommand": () => (/* reexport */ ExecuteStatementCommand),
  "ExecuteStatementInputFilterSensitiveLog": () => (/* reexport */ ExecuteStatementInputFilterSensitiveLog),
  "ExecuteStatementOutputFilterSensitiveLog": () => (/* reexport */ ExecuteStatementOutputFilterSensitiveLog),
  "ExecuteTransactionCommand": () => (/* reexport */ ExecuteTransactionCommand),
  "ExecuteTransactionInputFilterSensitiveLog": () => (/* reexport */ ExecuteTransactionInputFilterSensitiveLog),
  "ExecuteTransactionOutputFilterSensitiveLog": () => (/* reexport */ ExecuteTransactionOutputFilterSensitiveLog),
  "ExpectedAttributeValueFilterSensitiveLog": () => (/* reexport */ ExpectedAttributeValueFilterSensitiveLog),
  "ExportConflictException": () => (/* reexport */ ExportConflictException),
  "ExportDescriptionFilterSensitiveLog": () => (/* reexport */ ExportDescriptionFilterSensitiveLog),
  "ExportFormat": () => (/* reexport */ ExportFormat),
  "ExportNotFoundException": () => (/* reexport */ ExportNotFoundException),
  "ExportStatus": () => (/* reexport */ ExportStatus),
  "ExportSummaryFilterSensitiveLog": () => (/* reexport */ ExportSummaryFilterSensitiveLog),
  "ExportTableToPointInTimeCommand": () => (/* reexport */ ExportTableToPointInTimeCommand),
  "ExportTableToPointInTimeInputFilterSensitiveLog": () => (/* reexport */ ExportTableToPointInTimeInputFilterSensitiveLog),
  "ExportTableToPointInTimeOutputFilterSensitiveLog": () => (/* reexport */ ExportTableToPointInTimeOutputFilterSensitiveLog),
  "FailureExceptionFilterSensitiveLog": () => (/* reexport */ FailureExceptionFilterSensitiveLog),
  "GetFilterSensitiveLog": () => (/* reexport */ GetFilterSensitiveLog),
  "GetItemCommand": () => (/* reexport */ GetItemCommand),
  "GetItemInputFilterSensitiveLog": () => (/* reexport */ GetItemInputFilterSensitiveLog),
  "GetItemOutputFilterSensitiveLog": () => (/* reexport */ GetItemOutputFilterSensitiveLog),
  "GlobalSecondaryIndexAutoScalingUpdateFilterSensitiveLog": () => (/* reexport */ GlobalSecondaryIndexAutoScalingUpdateFilterSensitiveLog),
  "GlobalSecondaryIndexDescriptionFilterSensitiveLog": () => (/* reexport */ GlobalSecondaryIndexDescriptionFilterSensitiveLog),
  "GlobalSecondaryIndexFilterSensitiveLog": () => (/* reexport */ GlobalSecondaryIndexFilterSensitiveLog),
  "GlobalSecondaryIndexInfoFilterSensitiveLog": () => (/* reexport */ GlobalSecondaryIndexInfoFilterSensitiveLog),
  "GlobalSecondaryIndexUpdateFilterSensitiveLog": () => (/* reexport */ GlobalSecondaryIndexUpdateFilterSensitiveLog),
  "GlobalTableAlreadyExistsException": () => (/* reexport */ GlobalTableAlreadyExistsException),
  "GlobalTableDescriptionFilterSensitiveLog": () => (/* reexport */ GlobalTableDescriptionFilterSensitiveLog),
  "GlobalTableFilterSensitiveLog": () => (/* reexport */ GlobalTableFilterSensitiveLog),
  "GlobalTableGlobalSecondaryIndexSettingsUpdateFilterSensitiveLog": () => (/* reexport */ GlobalTableGlobalSecondaryIndexSettingsUpdateFilterSensitiveLog),
  "GlobalTableNotFoundException": () => (/* reexport */ GlobalTableNotFoundException),
  "IdempotentParameterMismatchException": () => (/* reexport */ IdempotentParameterMismatchException),
  "ImportConflictException": () => (/* reexport */ ImportConflictException),
  "ImportNotFoundException": () => (/* reexport */ ImportNotFoundException),
  "ImportStatus": () => (/* reexport */ ImportStatus),
  "ImportSummaryFilterSensitiveLog": () => (/* reexport */ ImportSummaryFilterSensitiveLog),
  "ImportTableCommand": () => (/* reexport */ ImportTableCommand),
  "ImportTableDescriptionFilterSensitiveLog": () => (/* reexport */ ImportTableDescriptionFilterSensitiveLog),
  "ImportTableInputFilterSensitiveLog": () => (/* reexport */ ImportTableInputFilterSensitiveLog),
  "ImportTableOutputFilterSensitiveLog": () => (/* reexport */ ImportTableOutputFilterSensitiveLog),
  "IndexNotFoundException": () => (/* reexport */ IndexNotFoundException),
  "InputCompressionType": () => (/* reexport */ InputCompressionType),
  "InputFormat": () => (/* reexport */ InputFormat),
  "InputFormatOptionsFilterSensitiveLog": () => (/* reexport */ InputFormatOptionsFilterSensitiveLog),
  "InternalServerError": () => (/* reexport */ InternalServerError),
  "InvalidEndpointException": () => (/* reexport */ InvalidEndpointException),
  "InvalidExportTimeException": () => (/* reexport */ InvalidExportTimeException),
  "InvalidRestoreTimeException": () => (/* reexport */ InvalidRestoreTimeException),
  "ItemCollectionMetricsFilterSensitiveLog": () => (/* reexport */ ItemCollectionMetricsFilterSensitiveLog),
  "ItemCollectionSizeLimitExceededException": () => (/* reexport */ ItemCollectionSizeLimitExceededException),
  "ItemResponseFilterSensitiveLog": () => (/* reexport */ ItemResponseFilterSensitiveLog),
  "KeySchemaElementFilterSensitiveLog": () => (/* reexport */ KeySchemaElementFilterSensitiveLog),
  "KeysAndAttributesFilterSensitiveLog": () => (/* reexport */ KeysAndAttributesFilterSensitiveLog),
  "KinesisDataStreamDestinationFilterSensitiveLog": () => (/* reexport */ KinesisDataStreamDestinationFilterSensitiveLog),
  "KinesisStreamingDestinationInputFilterSensitiveLog": () => (/* reexport */ KinesisStreamingDestinationInputFilterSensitiveLog),
  "KinesisStreamingDestinationOutputFilterSensitiveLog": () => (/* reexport */ KinesisStreamingDestinationOutputFilterSensitiveLog),
  "LimitExceededException": () => (/* reexport */ LimitExceededException),
  "ListBackupsCommand": () => (/* reexport */ ListBackupsCommand),
  "ListBackupsInputFilterSensitiveLog": () => (/* reexport */ ListBackupsInputFilterSensitiveLog),
  "ListBackupsOutputFilterSensitiveLog": () => (/* reexport */ ListBackupsOutputFilterSensitiveLog),
  "ListContributorInsightsCommand": () => (/* reexport */ ListContributorInsightsCommand),
  "ListContributorInsightsInputFilterSensitiveLog": () => (/* reexport */ ListContributorInsightsInputFilterSensitiveLog),
  "ListContributorInsightsOutputFilterSensitiveLog": () => (/* reexport */ ListContributorInsightsOutputFilterSensitiveLog),
  "ListExportsCommand": () => (/* reexport */ ListExportsCommand),
  "ListExportsInputFilterSensitiveLog": () => (/* reexport */ ListExportsInputFilterSensitiveLog),
  "ListExportsOutputFilterSensitiveLog": () => (/* reexport */ ListExportsOutputFilterSensitiveLog),
  "ListGlobalTablesCommand": () => (/* reexport */ ListGlobalTablesCommand),
  "ListGlobalTablesInputFilterSensitiveLog": () => (/* reexport */ ListGlobalTablesInputFilterSensitiveLog),
  "ListGlobalTablesOutputFilterSensitiveLog": () => (/* reexport */ ListGlobalTablesOutputFilterSensitiveLog),
  "ListImportsCommand": () => (/* reexport */ ListImportsCommand),
  "ListImportsInputFilterSensitiveLog": () => (/* reexport */ ListImportsInputFilterSensitiveLog),
  "ListImportsOutputFilterSensitiveLog": () => (/* reexport */ ListImportsOutputFilterSensitiveLog),
  "ListTablesCommand": () => (/* reexport */ ListTablesCommand),
  "ListTablesInputFilterSensitiveLog": () => (/* reexport */ ListTablesInputFilterSensitiveLog),
  "ListTablesOutputFilterSensitiveLog": () => (/* reexport */ ListTablesOutputFilterSensitiveLog),
  "ListTagsOfResourceCommand": () => (/* reexport */ ListTagsOfResourceCommand),
  "ListTagsOfResourceInputFilterSensitiveLog": () => (/* reexport */ ListTagsOfResourceInputFilterSensitiveLog),
  "ListTagsOfResourceOutputFilterSensitiveLog": () => (/* reexport */ ListTagsOfResourceOutputFilterSensitiveLog),
  "LocalSecondaryIndexDescriptionFilterSensitiveLog": () => (/* reexport */ LocalSecondaryIndexDescriptionFilterSensitiveLog),
  "LocalSecondaryIndexFilterSensitiveLog": () => (/* reexport */ LocalSecondaryIndexFilterSensitiveLog),
  "LocalSecondaryIndexInfoFilterSensitiveLog": () => (/* reexport */ LocalSecondaryIndexInfoFilterSensitiveLog),
  "ParameterizedStatementFilterSensitiveLog": () => (/* reexport */ ParameterizedStatementFilterSensitiveLog),
  "PointInTimeRecoveryDescriptionFilterSensitiveLog": () => (/* reexport */ PointInTimeRecoveryDescriptionFilterSensitiveLog),
  "PointInTimeRecoverySpecificationFilterSensitiveLog": () => (/* reexport */ PointInTimeRecoverySpecificationFilterSensitiveLog),
  "PointInTimeRecoveryUnavailableException": () => (/* reexport */ PointInTimeRecoveryUnavailableException),
  "ProjectionFilterSensitiveLog": () => (/* reexport */ ProjectionFilterSensitiveLog),
  "ProvisionedThroughputDescriptionFilterSensitiveLog": () => (/* reexport */ ProvisionedThroughputDescriptionFilterSensitiveLog),
  "ProvisionedThroughputExceededException": () => (/* reexport */ ProvisionedThroughputExceededException),
  "ProvisionedThroughputFilterSensitiveLog": () => (/* reexport */ ProvisionedThroughputFilterSensitiveLog),
  "ProvisionedThroughputOverrideFilterSensitiveLog": () => (/* reexport */ ProvisionedThroughputOverrideFilterSensitiveLog),
  "PutFilterSensitiveLog": () => (/* reexport */ PutFilterSensitiveLog),
  "PutItemCommand": () => (/* reexport */ PutItemCommand),
  "PutItemInputFilterSensitiveLog": () => (/* reexport */ PutItemInputFilterSensitiveLog),
  "PutItemOutputFilterSensitiveLog": () => (/* reexport */ PutItemOutputFilterSensitiveLog),
  "PutRequestFilterSensitiveLog": () => (/* reexport */ PutRequestFilterSensitiveLog),
  "QueryCommand": () => (/* reexport */ QueryCommand),
  "QueryInputFilterSensitiveLog": () => (/* reexport */ QueryInputFilterSensitiveLog),
  "QueryOutputFilterSensitiveLog": () => (/* reexport */ QueryOutputFilterSensitiveLog),
  "ReplicaAlreadyExistsException": () => (/* reexport */ ReplicaAlreadyExistsException),
  "ReplicaAutoScalingDescriptionFilterSensitiveLog": () => (/* reexport */ ReplicaAutoScalingDescriptionFilterSensitiveLog),
  "ReplicaAutoScalingUpdateFilterSensitiveLog": () => (/* reexport */ ReplicaAutoScalingUpdateFilterSensitiveLog),
  "ReplicaDescriptionFilterSensitiveLog": () => (/* reexport */ ReplicaDescriptionFilterSensitiveLog),
  "ReplicaFilterSensitiveLog": () => (/* reexport */ ReplicaFilterSensitiveLog),
  "ReplicaGlobalSecondaryIndexAutoScalingDescriptionFilterSensitiveLog": () => (/* reexport */ ReplicaGlobalSecondaryIndexAutoScalingDescriptionFilterSensitiveLog),
  "ReplicaGlobalSecondaryIndexAutoScalingUpdateFilterSensitiveLog": () => (/* reexport */ ReplicaGlobalSecondaryIndexAutoScalingUpdateFilterSensitiveLog),
  "ReplicaGlobalSecondaryIndexDescriptionFilterSensitiveLog": () => (/* reexport */ ReplicaGlobalSecondaryIndexDescriptionFilterSensitiveLog),
  "ReplicaGlobalSecondaryIndexFilterSensitiveLog": () => (/* reexport */ ReplicaGlobalSecondaryIndexFilterSensitiveLog),
  "ReplicaGlobalSecondaryIndexSettingsDescriptionFilterSensitiveLog": () => (/* reexport */ ReplicaGlobalSecondaryIndexSettingsDescriptionFilterSensitiveLog),
  "ReplicaGlobalSecondaryIndexSettingsUpdateFilterSensitiveLog": () => (/* reexport */ ReplicaGlobalSecondaryIndexSettingsUpdateFilterSensitiveLog),
  "ReplicaNotFoundException": () => (/* reexport */ ReplicaNotFoundException),
  "ReplicaSettingsDescriptionFilterSensitiveLog": () => (/* reexport */ ReplicaSettingsDescriptionFilterSensitiveLog),
  "ReplicaSettingsUpdateFilterSensitiveLog": () => (/* reexport */ ReplicaSettingsUpdateFilterSensitiveLog),
  "ReplicaUpdateFilterSensitiveLog": () => (/* reexport */ ReplicaUpdateFilterSensitiveLog),
  "ReplicationGroupUpdateFilterSensitiveLog": () => (/* reexport */ ReplicationGroupUpdateFilterSensitiveLog),
  "RequestLimitExceeded": () => (/* reexport */ RequestLimitExceeded),
  "ResourceInUseException": () => (/* reexport */ ResourceInUseException),
  "ResourceNotFoundException": () => (/* reexport */ ResourceNotFoundException),
  "RestoreSummaryFilterSensitiveLog": () => (/* reexport */ RestoreSummaryFilterSensitiveLog),
  "RestoreTableFromBackupCommand": () => (/* reexport */ RestoreTableFromBackupCommand),
  "RestoreTableFromBackupInputFilterSensitiveLog": () => (/* reexport */ RestoreTableFromBackupInputFilterSensitiveLog),
  "RestoreTableFromBackupOutputFilterSensitiveLog": () => (/* reexport */ RestoreTableFromBackupOutputFilterSensitiveLog),
  "RestoreTableToPointInTimeCommand": () => (/* reexport */ RestoreTableToPointInTimeCommand),
  "RestoreTableToPointInTimeInputFilterSensitiveLog": () => (/* reexport */ RestoreTableToPointInTimeInputFilterSensitiveLog),
  "RestoreTableToPointInTimeOutputFilterSensitiveLog": () => (/* reexport */ RestoreTableToPointInTimeOutputFilterSensitiveLog),
  "S3BucketSourceFilterSensitiveLog": () => (/* reexport */ S3BucketSourceFilterSensitiveLog),
  "SSEDescriptionFilterSensitiveLog": () => (/* reexport */ SSEDescriptionFilterSensitiveLog),
  "SSESpecificationFilterSensitiveLog": () => (/* reexport */ SSESpecificationFilterSensitiveLog),
  "ScanCommand": () => (/* reexport */ ScanCommand),
  "ScanInputFilterSensitiveLog": () => (/* reexport */ ScanInputFilterSensitiveLog),
  "ScanOutputFilterSensitiveLog": () => (/* reexport */ ScanOutputFilterSensitiveLog),
  "SourceTableDetailsFilterSensitiveLog": () => (/* reexport */ SourceTableDetailsFilterSensitiveLog),
  "SourceTableFeatureDetailsFilterSensitiveLog": () => (/* reexport */ SourceTableFeatureDetailsFilterSensitiveLog),
  "StreamSpecificationFilterSensitiveLog": () => (/* reexport */ StreamSpecificationFilterSensitiveLog),
  "TableAlreadyExistsException": () => (/* reexport */ TableAlreadyExistsException),
  "TableAutoScalingDescriptionFilterSensitiveLog": () => (/* reexport */ TableAutoScalingDescriptionFilterSensitiveLog),
  "TableClass": () => (/* reexport */ TableClass),
  "TableClassSummaryFilterSensitiveLog": () => (/* reexport */ TableClassSummaryFilterSensitiveLog),
  "TableCreationParametersFilterSensitiveLog": () => (/* reexport */ TableCreationParametersFilterSensitiveLog),
  "TableDescriptionFilterSensitiveLog": () => (/* reexport */ TableDescriptionFilterSensitiveLog),
  "TableInUseException": () => (/* reexport */ TableInUseException),
  "TableNotFoundException": () => (/* reexport */ TableNotFoundException),
  "TagFilterSensitiveLog": () => (/* reexport */ TagFilterSensitiveLog),
  "TagResourceCommand": () => (/* reexport */ TagResourceCommand),
  "TagResourceInputFilterSensitiveLog": () => (/* reexport */ TagResourceInputFilterSensitiveLog),
  "TimeToLiveDescriptionFilterSensitiveLog": () => (/* reexport */ TimeToLiveDescriptionFilterSensitiveLog),
  "TimeToLiveSpecificationFilterSensitiveLog": () => (/* reexport */ TimeToLiveSpecificationFilterSensitiveLog),
  "TransactGetItemFilterSensitiveLog": () => (/* reexport */ TransactGetItemFilterSensitiveLog),
  "TransactGetItemsCommand": () => (/* reexport */ TransactGetItemsCommand),
  "TransactGetItemsInputFilterSensitiveLog": () => (/* reexport */ TransactGetItemsInputFilterSensitiveLog),
  "TransactGetItemsOutputFilterSensitiveLog": () => (/* reexport */ TransactGetItemsOutputFilterSensitiveLog),
  "TransactWriteItemFilterSensitiveLog": () => (/* reexport */ TransactWriteItemFilterSensitiveLog),
  "TransactWriteItemsCommand": () => (/* reexport */ TransactWriteItemsCommand),
  "TransactWriteItemsInputFilterSensitiveLog": () => (/* reexport */ TransactWriteItemsInputFilterSensitiveLog),
  "TransactWriteItemsOutputFilterSensitiveLog": () => (/* reexport */ TransactWriteItemsOutputFilterSensitiveLog),
  "TransactionCanceledException": () => (/* reexport */ TransactionCanceledException),
  "TransactionConflictException": () => (/* reexport */ TransactionConflictException),
  "TransactionInProgressException": () => (/* reexport */ TransactionInProgressException),
  "UntagResourceCommand": () => (/* reexport */ UntagResourceCommand),
  "UntagResourceInputFilterSensitiveLog": () => (/* reexport */ UntagResourceInputFilterSensitiveLog),
  "UpdateContinuousBackupsCommand": () => (/* reexport */ UpdateContinuousBackupsCommand),
  "UpdateContinuousBackupsInputFilterSensitiveLog": () => (/* reexport */ UpdateContinuousBackupsInputFilterSensitiveLog),
  "UpdateContinuousBackupsOutputFilterSensitiveLog": () => (/* reexport */ UpdateContinuousBackupsOutputFilterSensitiveLog),
  "UpdateContributorInsightsCommand": () => (/* reexport */ UpdateContributorInsightsCommand),
  "UpdateContributorInsightsInputFilterSensitiveLog": () => (/* reexport */ UpdateContributorInsightsInputFilterSensitiveLog),
  "UpdateContributorInsightsOutputFilterSensitiveLog": () => (/* reexport */ UpdateContributorInsightsOutputFilterSensitiveLog),
  "UpdateFilterSensitiveLog": () => (/* reexport */ UpdateFilterSensitiveLog),
  "UpdateGlobalSecondaryIndexActionFilterSensitiveLog": () => (/* reexport */ UpdateGlobalSecondaryIndexActionFilterSensitiveLog),
  "UpdateGlobalTableCommand": () => (/* reexport */ UpdateGlobalTableCommand),
  "UpdateGlobalTableInputFilterSensitiveLog": () => (/* reexport */ UpdateGlobalTableInputFilterSensitiveLog),
  "UpdateGlobalTableOutputFilterSensitiveLog": () => (/* reexport */ UpdateGlobalTableOutputFilterSensitiveLog),
  "UpdateGlobalTableSettingsCommand": () => (/* reexport */ UpdateGlobalTableSettingsCommand),
  "UpdateGlobalTableSettingsInputFilterSensitiveLog": () => (/* reexport */ UpdateGlobalTableSettingsInputFilterSensitiveLog),
  "UpdateGlobalTableSettingsOutputFilterSensitiveLog": () => (/* reexport */ UpdateGlobalTableSettingsOutputFilterSensitiveLog),
  "UpdateItemCommand": () => (/* reexport */ UpdateItemCommand),
  "UpdateItemInputFilterSensitiveLog": () => (/* reexport */ UpdateItemInputFilterSensitiveLog),
  "UpdateItemOutputFilterSensitiveLog": () => (/* reexport */ UpdateItemOutputFilterSensitiveLog),
  "UpdateReplicationGroupMemberActionFilterSensitiveLog": () => (/* reexport */ UpdateReplicationGroupMemberActionFilterSensitiveLog),
  "UpdateTableCommand": () => (/* reexport */ UpdateTableCommand),
  "UpdateTableInputFilterSensitiveLog": () => (/* reexport */ UpdateTableInputFilterSensitiveLog),
  "UpdateTableOutputFilterSensitiveLog": () => (/* reexport */ UpdateTableOutputFilterSensitiveLog),
  "UpdateTableReplicaAutoScalingCommand": () => (/* reexport */ UpdateTableReplicaAutoScalingCommand),
  "UpdateTableReplicaAutoScalingInputFilterSensitiveLog": () => (/* reexport */ UpdateTableReplicaAutoScalingInputFilterSensitiveLog),
  "UpdateTableReplicaAutoScalingOutputFilterSensitiveLog": () => (/* reexport */ UpdateTableReplicaAutoScalingOutputFilterSensitiveLog),
  "UpdateTimeToLiveCommand": () => (/* reexport */ UpdateTimeToLiveCommand),
  "UpdateTimeToLiveInputFilterSensitiveLog": () => (/* reexport */ UpdateTimeToLiveInputFilterSensitiveLog),
  "UpdateTimeToLiveOutputFilterSensitiveLog": () => (/* reexport */ UpdateTimeToLiveOutputFilterSensitiveLog),
  "WriteRequestFilterSensitiveLog": () => (/* reexport */ WriteRequestFilterSensitiveLog),
  "paginateListContributorInsights": () => (/* reexport */ paginateListContributorInsights),
  "paginateListExports": () => (/* reexport */ paginateListExports),
  "paginateListImports": () => (/* reexport */ paginateListImports),
  "paginateListTables": () => (/* reexport */ paginateListTables),
  "paginateQuery": () => (/* reexport */ paginateQuery),
  "paginateScan": () => (/* reexport */ paginateScan),
  "waitForTableExists": () => (/* reexport */ waitForTableExists),
  "waitForTableNotExists": () => (/* reexport */ waitForTableNotExists),
  "waitUntilTableExists": () => (/* reexport */ waitUntilTableExists),
  "waitUntilTableNotExists": () => (/* reexport */ waitUntilTableNotExists)
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-serde/dist-es/deserializerMiddleware.js
const deserializerMiddleware = (options, deserializer) => (next, context) => async (args) => {
    const { response } = await next(args);
    try {
        const parsed = await deserializer(response, options);
        return {
            response,
            output: parsed,
        };
    }
    catch (error) {
        Object.defineProperty(error, "$response", {
            value: response,
        });
        throw error;
    }
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-serde/dist-es/serializerMiddleware.js
const serializerMiddleware = (options, serializer) => (next, context) => async (args) => {
    const endpoint = context.endpointV2?.url && options.urlParser
        ? async () => options.urlParser(context.endpointV2.url)
        : options.endpoint;
    if (!endpoint) {
        throw new Error("No valid endpoint provider available.");
    }
    const request = await serializer(args.input, { ...options, endpoint });
    return next({
        ...args,
        request,
    });
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-serde/dist-es/serdePlugin.js


const deserializerMiddlewareOption = {
    name: "deserializerMiddleware",
    step: "deserialize",
    tags: ["DESERIALIZER"],
    override: true,
};
const serializerMiddlewareOption = {
    name: "serializerMiddleware",
    step: "serialize",
    tags: ["SERIALIZER"],
    override: true,
};
function getSerdePlugin(config, serializer, deserializer) {
    return {
        applyToStack: (commandStack) => {
            commandStack.add(deserializerMiddleware(config, deserializer), deserializerMiddlewareOption);
            commandStack.add(serializerMiddleware(config, serializer), serializerMiddlewareOption);
        },
    };
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-serde/dist-es/index.js




;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-stack/dist-es/MiddlewareStack.js
const constructStack = () => {
    let absoluteEntries = [];
    let relativeEntries = [];
    const entriesNameSet = new Set();
    const sort = (entries) => entries.sort((a, b) => stepWeights[b.step] - stepWeights[a.step] ||
        priorityWeights[b.priority || "normal"] - priorityWeights[a.priority || "normal"]);
    const removeByName = (toRemove) => {
        let isRemoved = false;
        const filterCb = (entry) => {
            if (entry.name && entry.name === toRemove) {
                isRemoved = true;
                entriesNameSet.delete(toRemove);
                return false;
            }
            return true;
        };
        absoluteEntries = absoluteEntries.filter(filterCb);
        relativeEntries = relativeEntries.filter(filterCb);
        return isRemoved;
    };
    const removeByReference = (toRemove) => {
        let isRemoved = false;
        const filterCb = (entry) => {
            if (entry.middleware === toRemove) {
                isRemoved = true;
                if (entry.name)
                    entriesNameSet.delete(entry.name);
                return false;
            }
            return true;
        };
        absoluteEntries = absoluteEntries.filter(filterCb);
        relativeEntries = relativeEntries.filter(filterCb);
        return isRemoved;
    };
    const cloneTo = (toStack) => {
        absoluteEntries.forEach((entry) => {
            toStack.add(entry.middleware, { ...entry });
        });
        relativeEntries.forEach((entry) => {
            toStack.addRelativeTo(entry.middleware, { ...entry });
        });
        return toStack;
    };
    const expandRelativeMiddlewareList = (from) => {
        const expandedMiddlewareList = [];
        from.before.forEach((entry) => {
            if (entry.before.length === 0 && entry.after.length === 0) {
                expandedMiddlewareList.push(entry);
            }
            else {
                expandedMiddlewareList.push(...expandRelativeMiddlewareList(entry));
            }
        });
        expandedMiddlewareList.push(from);
        from.after.reverse().forEach((entry) => {
            if (entry.before.length === 0 && entry.after.length === 0) {
                expandedMiddlewareList.push(entry);
            }
            else {
                expandedMiddlewareList.push(...expandRelativeMiddlewareList(entry));
            }
        });
        return expandedMiddlewareList;
    };
    const getMiddlewareList = (debug = false) => {
        const normalizedAbsoluteEntries = [];
        const normalizedRelativeEntries = [];
        const normalizedEntriesNameMap = {};
        absoluteEntries.forEach((entry) => {
            const normalizedEntry = {
                ...entry,
                before: [],
                after: [],
            };
            if (normalizedEntry.name)
                normalizedEntriesNameMap[normalizedEntry.name] = normalizedEntry;
            normalizedAbsoluteEntries.push(normalizedEntry);
        });
        relativeEntries.forEach((entry) => {
            const normalizedEntry = {
                ...entry,
                before: [],
                after: [],
            };
            if (normalizedEntry.name)
                normalizedEntriesNameMap[normalizedEntry.name] = normalizedEntry;
            normalizedRelativeEntries.push(normalizedEntry);
        });
        normalizedRelativeEntries.forEach((entry) => {
            if (entry.toMiddleware) {
                const toMiddleware = normalizedEntriesNameMap[entry.toMiddleware];
                if (toMiddleware === undefined) {
                    if (debug) {
                        return;
                    }
                    throw new Error(`${entry.toMiddleware} is not found when adding ${entry.name || "anonymous"} middleware ${entry.relation} ${entry.toMiddleware}`);
                }
                if (entry.relation === "after") {
                    toMiddleware.after.push(entry);
                }
                if (entry.relation === "before") {
                    toMiddleware.before.push(entry);
                }
            }
        });
        const mainChain = sort(normalizedAbsoluteEntries)
            .map(expandRelativeMiddlewareList)
            .reduce((wholeList, expendedMiddlewareList) => {
            wholeList.push(...expendedMiddlewareList);
            return wholeList;
        }, []);
        return mainChain;
    };
    const stack = {
        add: (middleware, options = {}) => {
            const { name, override } = options;
            const entry = {
                step: "initialize",
                priority: "normal",
                middleware,
                ...options,
            };
            if (name) {
                if (entriesNameSet.has(name)) {
                    if (!override)
                        throw new Error(`Duplicate middleware name '${name}'`);
                    const toOverrideIndex = absoluteEntries.findIndex((entry) => entry.name === name);
                    const toOverride = absoluteEntries[toOverrideIndex];
                    if (toOverride.step !== entry.step || toOverride.priority !== entry.priority) {
                        throw new Error(`"${name}" middleware with ${toOverride.priority} priority in ${toOverride.step} step cannot be ` +
                            `overridden by same-name middleware with ${entry.priority} priority in ${entry.step} step.`);
                    }
                    absoluteEntries.splice(toOverrideIndex, 1);
                }
                entriesNameSet.add(name);
            }
            absoluteEntries.push(entry);
        },
        addRelativeTo: (middleware, options) => {
            const { name, override } = options;
            const entry = {
                middleware,
                ...options,
            };
            if (name) {
                if (entriesNameSet.has(name)) {
                    if (!override)
                        throw new Error(`Duplicate middleware name '${name}'`);
                    const toOverrideIndex = relativeEntries.findIndex((entry) => entry.name === name);
                    const toOverride = relativeEntries[toOverrideIndex];
                    if (toOverride.toMiddleware !== entry.toMiddleware || toOverride.relation !== entry.relation) {
                        throw new Error(`"${name}" middleware ${toOverride.relation} "${toOverride.toMiddleware}" middleware cannot be overridden ` +
                            `by same-name middleware ${entry.relation} "${entry.toMiddleware}" middleware.`);
                    }
                    relativeEntries.splice(toOverrideIndex, 1);
                }
                entriesNameSet.add(name);
            }
            relativeEntries.push(entry);
        },
        clone: () => cloneTo(constructStack()),
        use: (plugin) => {
            plugin.applyToStack(stack);
        },
        remove: (toRemove) => {
            if (typeof toRemove === "string")
                return removeByName(toRemove);
            else
                return removeByReference(toRemove);
        },
        removeByTag: (toRemove) => {
            let isRemoved = false;
            const filterCb = (entry) => {
                const { tags, name } = entry;
                if (tags && tags.includes(toRemove)) {
                    if (name)
                        entriesNameSet.delete(name);
                    isRemoved = true;
                    return false;
                }
                return true;
            };
            absoluteEntries = absoluteEntries.filter(filterCb);
            relativeEntries = relativeEntries.filter(filterCb);
            return isRemoved;
        },
        concat: (from) => {
            const cloned = cloneTo(constructStack());
            cloned.use(from);
            return cloned;
        },
        applyToStack: cloneTo,
        identify: () => {
            return getMiddlewareList(true).map((mw) => {
                return mw.name + ": " + (mw.tags || []).join(",");
            });
        },
        resolve: (handler, context) => {
            for (const middleware of getMiddlewareList()
                .map((entry) => entry.middleware)
                .reverse()) {
                handler = middleware(handler, context);
            }
            return handler;
        },
    };
    return stack;
};
const stepWeights = {
    initialize: 5,
    serialize: 4,
    build: 3,
    finalizeRequest: 2,
    deserialize: 1,
};
const priorityWeights = {
    high: 3,
    normal: 2,
    low: 1,
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-stack/dist-es/index.js


;// CONCATENATED MODULE: ../node_modules/@aws-sdk/smithy-client/dist-es/client.js

class Client {
    constructor(config) {
        this.middlewareStack = constructStack();
        this.config = config;
    }
    send(command, optionsOrCb, cb) {
        const options = typeof optionsOrCb !== "function" ? optionsOrCb : undefined;
        const callback = typeof optionsOrCb === "function" ? optionsOrCb : cb;
        const handler = command.resolveMiddleware(this.middlewareStack, this.config, options);
        if (callback) {
            handler(command)
                .then((result) => callback(null, result.output), (err) => callback(err))
                .catch(() => { });
        }
        else {
            return handler(command).then((result) => result.output);
        }
    }
    destroy() {
        if (this.config.requestHandler.destroy)
            this.config.requestHandler.destroy();
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/smithy-client/dist-es/command.js

class Command {
    constructor() {
        this.middlewareStack = constructStack();
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/smithy-client/dist-es/constants.js
const constants_SENSITIVE_STRING = "***SensitiveInformation***";

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/smithy-client/dist-es/parse-utils.js
const parseBoolean = (value) => {
    switch (value) {
        case "true":
            return true;
        case "false":
            return false;
        default:
            throw new Error(`Unable to parse boolean value "${value}"`);
    }
};
const expectBoolean = (value) => {
    if (value === null || value === undefined) {
        return undefined;
    }
    if (typeof value === "number") {
        if (value === 0 || value === 1) {
            logger.warn(stackTraceWarning(`Expected boolean, got ${typeof value}: ${value}`));
        }
        if (value === 0) {
            return false;
        }
        if (value === 1) {
            return true;
        }
    }
    if (typeof value === "string") {
        const lower = value.toLowerCase();
        if (lower === "false" || lower === "true") {
            logger.warn(stackTraceWarning(`Expected boolean, got ${typeof value}: ${value}`));
        }
        if (lower === "false") {
            return false;
        }
        if (lower === "true") {
            return true;
        }
    }
    if (typeof value === "boolean") {
        return value;
    }
    throw new TypeError(`Expected boolean, got ${typeof value}: ${value}`);
};
const expectNumber = (value) => {
    if (value === null || value === undefined) {
        return undefined;
    }
    if (typeof value === "string") {
        const parsed = parseFloat(value);
        if (!Number.isNaN(parsed)) {
            if (String(parsed) !== String(value)) {
                logger.warn(stackTraceWarning(`Expected number but observed string: ${value}`));
            }
            return parsed;
        }
    }
    if (typeof value === "number") {
        return value;
    }
    throw new TypeError(`Expected number, got ${typeof value}: ${value}`);
};
const MAX_FLOAT = Math.ceil(2 ** 127 * (2 - 2 ** -23));
const expectFloat32 = (value) => {
    const expected = expectNumber(value);
    if (expected !== undefined && !Number.isNaN(expected) && expected !== Infinity && expected !== -Infinity) {
        if (Math.abs(expected) > MAX_FLOAT) {
            throw new TypeError(`Expected 32-bit float, got ${value}`);
        }
    }
    return expected;
};
const expectLong = (value) => {
    if (value === null || value === undefined) {
        return undefined;
    }
    if (Number.isInteger(value) && !Number.isNaN(value)) {
        return value;
    }
    throw new TypeError(`Expected integer, got ${typeof value}: ${value}`);
};
const expectInt = (/* unused pure expression or super */ null && (expectLong));
const expectInt32 = (value) => expectSizedInt(value, 32);
const expectShort = (value) => expectSizedInt(value, 16);
const expectByte = (value) => expectSizedInt(value, 8);
const expectSizedInt = (value, size) => {
    const expected = expectLong(value);
    if (expected !== undefined && castInt(expected, size) !== expected) {
        throw new TypeError(`Expected ${size}-bit integer, got ${value}`);
    }
    return expected;
};
const castInt = (value, size) => {
    switch (size) {
        case 32:
            return Int32Array.of(value)[0];
        case 16:
            return Int16Array.of(value)[0];
        case 8:
            return Int8Array.of(value)[0];
    }
};
const expectNonNull = (value, location) => {
    if (value === null || value === undefined) {
        if (location) {
            throw new TypeError(`Expected a non-null value for ${location}`);
        }
        throw new TypeError("Expected a non-null value");
    }
    return value;
};
const expectObject = (value) => {
    if (value === null || value === undefined) {
        return undefined;
    }
    if (typeof value === "object" && !Array.isArray(value)) {
        return value;
    }
    const receivedType = Array.isArray(value) ? "array" : typeof value;
    throw new TypeError(`Expected object, got ${receivedType}: ${value}`);
};
const expectString = (value) => {
    if (value === null || value === undefined) {
        return undefined;
    }
    if (typeof value === "string") {
        return value;
    }
    if (["boolean", "number", "bigint"].includes(typeof value)) {
        logger.warn(stackTraceWarning(`Expected string, got ${typeof value}: ${value}`));
        return String(value);
    }
    throw new TypeError(`Expected string, got ${typeof value}: ${value}`);
};
const expectUnion = (value) => {
    if (value === null || value === undefined) {
        return undefined;
    }
    const asObject = expectObject(value);
    const setKeys = Object.entries(asObject)
        .filter(([, v]) => v != null)
        .map(([k]) => k);
    if (setKeys.length === 0) {
        throw new TypeError(`Unions must have exactly one non-null member. None were found.`);
    }
    if (setKeys.length > 1) {
        throw new TypeError(`Unions must have exactly one non-null member. Keys ${setKeys} were not null.`);
    }
    return asObject;
};
const strictParseDouble = (value) => {
    if (typeof value == "string") {
        return expectNumber(parseNumber(value));
    }
    return expectNumber(value);
};
const strictParseFloat = (/* unused pure expression or super */ null && (strictParseDouble));
const strictParseFloat32 = (value) => {
    if (typeof value == "string") {
        return expectFloat32(parseNumber(value));
    }
    return expectFloat32(value);
};
const NUMBER_REGEX = /(-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)|(-?Infinity)|(NaN)/g;
const parseNumber = (value) => {
    const matches = value.match(NUMBER_REGEX);
    if (matches === null || matches[0].length !== value.length) {
        throw new TypeError(`Expected real number, got implicit NaN`);
    }
    return parseFloat(value);
};
const limitedParseDouble = (value) => {
    if (typeof value == "string") {
        return parseFloatString(value);
    }
    return expectNumber(value);
};
const handleFloat = (/* unused pure expression or super */ null && (limitedParseDouble));
const limitedParseFloat = (/* unused pure expression or super */ null && (limitedParseDouble));
const limitedParseFloat32 = (value) => {
    if (typeof value == "string") {
        return parseFloatString(value);
    }
    return expectFloat32(value);
};
const parseFloatString = (value) => {
    switch (value) {
        case "NaN":
            return NaN;
        case "Infinity":
            return Infinity;
        case "-Infinity":
            return -Infinity;
        default:
            throw new Error(`Unable to parse float value: ${value}`);
    }
};
const strictParseLong = (value) => {
    if (typeof value === "string") {
        return expectLong(parseNumber(value));
    }
    return expectLong(value);
};
const strictParseInt = (/* unused pure expression or super */ null && (strictParseLong));
const strictParseInt32 = (value) => {
    if (typeof value === "string") {
        return expectInt32(parseNumber(value));
    }
    return expectInt32(value);
};
const parse_utils_strictParseShort = (value) => {
    if (typeof value === "string") {
        return expectShort(parseNumber(value));
    }
    return expectShort(value);
};
const strictParseByte = (value) => {
    if (typeof value === "string") {
        return expectByte(parseNumber(value));
    }
    return expectByte(value);
};
const stackTraceWarning = (message) => {
    return String(new TypeError(message).stack || message)
        .split("\n")
        .slice(0, 5)
        .filter((s) => !s.includes("stackTraceWarning"))
        .join("\n");
};
const logger = {
    warn: console.warn,
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/smithy-client/dist-es/date-utils.js

const DAYS = (/* unused pure expression or super */ null && (["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]));
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function dateToUtcString(date) {
    const year = date.getUTCFullYear();
    const month = date.getUTCMonth();
    const dayOfWeek = date.getUTCDay();
    const dayOfMonthInt = date.getUTCDate();
    const hoursInt = date.getUTCHours();
    const minutesInt = date.getUTCMinutes();
    const secondsInt = date.getUTCSeconds();
    const dayOfMonthString = dayOfMonthInt < 10 ? `0${dayOfMonthInt}` : `${dayOfMonthInt}`;
    const hoursString = hoursInt < 10 ? `0${hoursInt}` : `${hoursInt}`;
    const minutesString = minutesInt < 10 ? `0${minutesInt}` : `${minutesInt}`;
    const secondsString = secondsInt < 10 ? `0${secondsInt}` : `${secondsInt}`;
    return `${DAYS[dayOfWeek]}, ${dayOfMonthString} ${MONTHS[month]} ${year} ${hoursString}:${minutesString}:${secondsString} GMT`;
}
const RFC3339 = new RegExp(/^(\d{4})-(\d{2})-(\d{2})[tT](\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?[zZ]$/);
const parseRfc3339DateTime = (value) => {
    if (value === null || value === undefined) {
        return undefined;
    }
    if (typeof value !== "string") {
        throw new TypeError("RFC-3339 date-times must be expressed as strings");
    }
    const match = RFC3339.exec(value);
    if (!match) {
        throw new TypeError("Invalid RFC-3339 date-time value");
    }
    const [_, yearStr, monthStr, dayStr, hours, minutes, seconds, fractionalMilliseconds] = match;
    const year = parse_utils_strictParseShort(stripLeadingZeroes(yearStr));
    const month = parseDateValue(monthStr, "month", 1, 12);
    const day = parseDateValue(dayStr, "day", 1, 31);
    return buildDate(year, month, day, { hours, minutes, seconds, fractionalMilliseconds });
};
const IMF_FIXDATE = (/* unused pure expression or super */ null && (new RegExp(/^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun), (\d{2}) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) (\d{4}) (\d{1,2}):(\d{2}):(\d{2})(?:\.(\d+))? GMT$/)));
const RFC_850_DATE = (/* unused pure expression or super */ null && (new RegExp(/^(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday), (\d{2})-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-(\d{2}) (\d{1,2}):(\d{2}):(\d{2})(?:\.(\d+))? GMT$/)));
const ASC_TIME = (/* unused pure expression or super */ null && (new RegExp(/^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) ( [1-9]|\d{2}) (\d{1,2}):(\d{2}):(\d{2})(?:\.(\d+))? (\d{4})$/)));
const parseRfc7231DateTime = (value) => {
    if (value === null || value === undefined) {
        return undefined;
    }
    if (typeof value !== "string") {
        throw new TypeError("RFC-7231 date-times must be expressed as strings");
    }
    let match = IMF_FIXDATE.exec(value);
    if (match) {
        const [_, dayStr, monthStr, yearStr, hours, minutes, seconds, fractionalMilliseconds] = match;
        return buildDate(strictParseShort(stripLeadingZeroes(yearStr)), parseMonthByShortName(monthStr), parseDateValue(dayStr, "day", 1, 31), { hours, minutes, seconds, fractionalMilliseconds });
    }
    match = RFC_850_DATE.exec(value);
    if (match) {
        const [_, dayStr, monthStr, yearStr, hours, minutes, seconds, fractionalMilliseconds] = match;
        return adjustRfc850Year(buildDate(parseTwoDigitYear(yearStr), parseMonthByShortName(monthStr), parseDateValue(dayStr, "day", 1, 31), {
            hours,
            minutes,
            seconds,
            fractionalMilliseconds,
        }));
    }
    match = ASC_TIME.exec(value);
    if (match) {
        const [_, monthStr, dayStr, hours, minutes, seconds, fractionalMilliseconds, yearStr] = match;
        return buildDate(strictParseShort(stripLeadingZeroes(yearStr)), parseMonthByShortName(monthStr), parseDateValue(dayStr.trimLeft(), "day", 1, 31), { hours, minutes, seconds, fractionalMilliseconds });
    }
    throw new TypeError("Invalid RFC-7231 date-time value");
};
const parseEpochTimestamp = (value) => {
    if (value === null || value === undefined) {
        return undefined;
    }
    let valueAsDouble;
    if (typeof value === "number") {
        valueAsDouble = value;
    }
    else if (typeof value === "string") {
        valueAsDouble = strictParseDouble(value);
    }
    else {
        throw new TypeError("Epoch timestamps must be expressed as floating point numbers or their string representation");
    }
    if (Number.isNaN(valueAsDouble) || valueAsDouble === Infinity || valueAsDouble === -Infinity) {
        throw new TypeError("Epoch timestamps must be valid, non-Infinite, non-NaN numerics");
    }
    return new Date(Math.round(valueAsDouble * 1000));
};
const buildDate = (year, month, day, time) => {
    const adjustedMonth = month - 1;
    validateDayOfMonth(year, adjustedMonth, day);
    return new Date(Date.UTC(year, adjustedMonth, day, parseDateValue(time.hours, "hour", 0, 23), parseDateValue(time.minutes, "minute", 0, 59), parseDateValue(time.seconds, "seconds", 0, 60), parseMilliseconds(time.fractionalMilliseconds)));
};
const parseTwoDigitYear = (value) => {
    const thisYear = new Date().getUTCFullYear();
    const valueInThisCentury = Math.floor(thisYear / 100) * 100 + strictParseShort(stripLeadingZeroes(value));
    if (valueInThisCentury < thisYear) {
        return valueInThisCentury + 100;
    }
    return valueInThisCentury;
};
const FIFTY_YEARS_IN_MILLIS = (/* unused pure expression or super */ null && (50 * 365 * 24 * 60 * 60 * 1000));
const adjustRfc850Year = (input) => {
    if (input.getTime() - new Date().getTime() > FIFTY_YEARS_IN_MILLIS) {
        return new Date(Date.UTC(input.getUTCFullYear() - 100, input.getUTCMonth(), input.getUTCDate(), input.getUTCHours(), input.getUTCMinutes(), input.getUTCSeconds(), input.getUTCMilliseconds()));
    }
    return input;
};
const parseMonthByShortName = (value) => {
    const monthIdx = MONTHS.indexOf(value);
    if (monthIdx < 0) {
        throw new TypeError(`Invalid month: ${value}`);
    }
    return monthIdx + 1;
};
const DAYS_IN_MONTH = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
const validateDayOfMonth = (year, month, day) => {
    let maxDays = DAYS_IN_MONTH[month];
    if (month === 1 && isLeapYear(year)) {
        maxDays = 29;
    }
    if (day > maxDays) {
        throw new TypeError(`Invalid day for ${MONTHS[month]} in ${year}: ${day}`);
    }
};
const isLeapYear = (year) => {
    return year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
};
const parseDateValue = (value, type, lower, upper) => {
    const dateVal = strictParseByte(stripLeadingZeroes(value));
    if (dateVal < lower || dateVal > upper) {
        throw new TypeError(`${type} must be between ${lower} and ${upper}, inclusive`);
    }
    return dateVal;
};
const parseMilliseconds = (value) => {
    if (value === null || value === undefined) {
        return 0;
    }
    return strictParseFloat32("0." + value) * 1000;
};
const stripLeadingZeroes = (value) => {
    let idx = 0;
    while (idx < value.length - 1 && value.charAt(idx) === "0") {
        idx++;
    }
    if (idx === 0) {
        return value;
    }
    return value.slice(idx);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/smithy-client/dist-es/exceptions.js
class ServiceException extends Error {
    constructor(options) {
        super(options.message);
        Object.setPrototypeOf(this, ServiceException.prototype);
        this.name = options.name;
        this.$fault = options.$fault;
        this.$metadata = options.$metadata;
    }
}
const decorateServiceException = (exception, additions = {}) => {
    Object.entries(additions)
        .filter(([, v]) => v !== undefined)
        .forEach(([k, v]) => {
        if (exception[k] == undefined || exception[k] === "") {
            exception[k] = v;
        }
    });
    const message = exception.message || exception.Message || "UnknownError";
    exception.message = message;
    delete exception.Message;
    return exception;
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/smithy-client/dist-es/default-error-handler.js

const default_error_handler_throwDefaultError = ({ output, parsedBody, exceptionCtor, errorCode }) => {
    const $metadata = deserializeMetadata(output);
    const statusCode = $metadata.httpStatusCode ? $metadata.httpStatusCode + "" : undefined;
    const response = new exceptionCtor({
        name: parsedBody.code || parsedBody.Code || errorCode || statusCode || "UnknowError",
        $fault: "client",
        $metadata,
    });
    throw decorateServiceException(response, parsedBody);
};
const deserializeMetadata = (output) => ({
    httpStatusCode: output.statusCode,
    requestId: output.headers["x-amzn-requestid"] ?? output.headers["x-amzn-request-id"],
    extendedRequestId: output.headers["x-amz-id-2"],
    cfId: output.headers["x-amz-cf-id"],
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/smithy-client/dist-es/defaults-mode.js
const loadConfigsForDefaultMode = (mode) => {
    switch (mode) {
        case "standard":
            return {
                retryMode: "standard",
                connectionTimeout: 3100,
            };
        case "in-region":
            return {
                retryMode: "standard",
                connectionTimeout: 1100,
            };
        case "cross-region":
            return {
                retryMode: "standard",
                connectionTimeout: 3100,
            };
        case "mobile":
            return {
                retryMode: "standard",
                connectionTimeout: 30000,
            };
        default:
            return {};
    }
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/smithy-client/dist-es/emitWarningIfUnsupportedVersion.js
let warningEmitted = false;
const emitWarningIfUnsupportedVersion = (version) => {
    if (version && !warningEmitted && parseInt(version.substring(1, version.indexOf("."))) < 14) {
        warningEmitted = true;
        process.emitWarning(`The AWS SDK for JavaScript (v3) will\n` +
            `no longer support Node.js ${version} on November 1, 2022.\n\n` +
            `To continue receiving updates to AWS services, bug fixes, and security\n` +
            `updates please upgrade to Node.js 14.x or later.\n\n` +
            `For details, please refer our blog post: https://a.co/48dbdYz`, `NodeDeprecationWarning`);
    }
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/smithy-client/dist-es/extended-encode-uri-component.js
function extendedEncodeURIComponent(str) {
    return encodeURIComponent(str).replace(/[!'()*]/g, function (c) {
        return "%" + c.charCodeAt(0).toString(16).toUpperCase();
    });
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/smithy-client/dist-es/get-value-from-text-node.js
const getValueFromTextNode = (obj) => {
    const textNodeName = "#text";
    for (const key in obj) {
        if (obj.hasOwnProperty(key) && obj[key][textNodeName] !== undefined) {
            obj[key] = obj[key][textNodeName];
        }
        else if (typeof obj[key] === "object" && obj[key] !== null) {
            obj[key] = getValueFromTextNode(obj[key]);
        }
    }
    return obj;
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/smithy-client/dist-es/lazy-json.js
const StringWrapper = function () {
    const Class = Object.getPrototypeOf(this).constructor;
    const Constructor = Function.bind.apply(String, [null, ...arguments]);
    const instance = new Constructor();
    Object.setPrototypeOf(instance, Class.prototype);
    return instance;
};
StringWrapper.prototype = Object.create(String.prototype, {
    constructor: {
        value: StringWrapper,
        enumerable: false,
        writable: true,
        configurable: true,
    },
});
Object.setPrototypeOf(StringWrapper, String);
class LazyJsonString extends (/* unused pure expression or super */ null && (StringWrapper)) {
    deserializeJSON() {
        return JSON.parse(super.toString());
    }
    toJSON() {
        return super.toString();
    }
    static fromObject(object) {
        if (object instanceof LazyJsonString) {
            return object;
        }
        else if (object instanceof String || typeof object === "string") {
            return new LazyJsonString(object);
        }
        return new LazyJsonString(JSON.stringify(object));
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/smithy-client/dist-es/object-mapping.js
function map(arg0, arg1, arg2) {
    let target;
    let filter;
    let instructions;
    if (typeof arg1 === "undefined" && typeof arg2 === "undefined") {
        target = {};
        instructions = arg0;
    }
    else {
        target = arg0;
        if (typeof arg1 === "function") {
            filter = arg1;
            instructions = arg2;
            return mapWithFilter(target, filter, instructions);
        }
        else {
            instructions = arg1;
        }
    }
    for (const key of Object.keys(instructions)) {
        if (!Array.isArray(instructions[key])) {
            target[key] = instructions[key];
            continue;
        }
        let [filter, value] = instructions[key];
        if (typeof value === "function") {
            let _value;
            const defaultFilterPassed = filter === undefined && (_value = value()) != null;
            const customFilterPassed = (typeof filter === "function" && !!filter(void 0)) || (typeof filter !== "function" && !!filter);
            if (defaultFilterPassed) {
                target[key] = _value;
            }
            else if (customFilterPassed) {
                target[key] = value();
            }
        }
        else {
            const defaultFilterPassed = filter === undefined && value != null;
            const customFilterPassed = (typeof filter === "function" && !!filter(value)) || (typeof filter !== "function" && !!filter);
            if (defaultFilterPassed || customFilterPassed) {
                target[key] = value;
            }
        }
    }
    return target;
}
const convertMap = (target) => {
    const output = {};
    for (const [k, v] of Object.entries(target || {})) {
        output[k] = [, v];
    }
    return output;
};
const mapWithFilter = (target, filter, instructions) => {
    return map(target, Object.entries(instructions).reduce((_instructions, [key, value]) => {
        if (Array.isArray(value)) {
            _instructions[key] = value;
        }
        else {
            if (typeof value === "function") {
                _instructions[key] = [filter, value()];
            }
            else {
                _instructions[key] = [filter, value];
            }
        }
        return _instructions;
    }, {}));
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/smithy-client/dist-es/ser-utils.js
const serializeFloat = (value) => {
    if (value !== value) {
        return "NaN";
    }
    switch (value) {
        case Infinity:
            return "Infinity";
        case -Infinity:
            return "-Infinity";
        default:
            return value;
    }
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/smithy-client/dist-es/index.js


















;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/models/DynamoDBServiceException.js

class DynamoDBServiceException extends ServiceException {
    constructor(options) {
        super(options);
        Object.setPrototypeOf(this, DynamoDBServiceException.prototype);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/models/models_0.js

var BackupType;
(function (BackupType) {
    BackupType["AWS_BACKUP"] = "AWS_BACKUP";
    BackupType["SYSTEM"] = "SYSTEM";
    BackupType["USER"] = "USER";
})(BackupType || (BackupType = {}));
class BackupInUseException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "BackupInUseException",
            $fault: "client",
            ...opts,
        });
        this.name = "BackupInUseException";
        this.$fault = "client";
        Object.setPrototypeOf(this, BackupInUseException.prototype);
    }
}
class BackupNotFoundException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "BackupNotFoundException",
            $fault: "client",
            ...opts,
        });
        this.name = "BackupNotFoundException";
        this.$fault = "client";
        Object.setPrototypeOf(this, BackupNotFoundException.prototype);
    }
}
var BackupTypeFilter;
(function (BackupTypeFilter) {
    BackupTypeFilter["ALL"] = "ALL";
    BackupTypeFilter["AWS_BACKUP"] = "AWS_BACKUP";
    BackupTypeFilter["SYSTEM"] = "SYSTEM";
    BackupTypeFilter["USER"] = "USER";
})(BackupTypeFilter || (BackupTypeFilter = {}));
var BatchStatementErrorCodeEnum;
(function (BatchStatementErrorCodeEnum) {
    BatchStatementErrorCodeEnum["AccessDenied"] = "AccessDenied";
    BatchStatementErrorCodeEnum["ConditionalCheckFailed"] = "ConditionalCheckFailed";
    BatchStatementErrorCodeEnum["DuplicateItem"] = "DuplicateItem";
    BatchStatementErrorCodeEnum["InternalServerError"] = "InternalServerError";
    BatchStatementErrorCodeEnum["ItemCollectionSizeLimitExceeded"] = "ItemCollectionSizeLimitExceeded";
    BatchStatementErrorCodeEnum["ProvisionedThroughputExceeded"] = "ProvisionedThroughputExceeded";
    BatchStatementErrorCodeEnum["RequestLimitExceeded"] = "RequestLimitExceeded";
    BatchStatementErrorCodeEnum["ResourceNotFound"] = "ResourceNotFound";
    BatchStatementErrorCodeEnum["ThrottlingError"] = "ThrottlingError";
    BatchStatementErrorCodeEnum["TransactionConflict"] = "TransactionConflict";
    BatchStatementErrorCodeEnum["ValidationError"] = "ValidationError";
})(BatchStatementErrorCodeEnum || (BatchStatementErrorCodeEnum = {}));
class InternalServerError extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "InternalServerError",
            $fault: "server",
            ...opts,
        });
        this.name = "InternalServerError";
        this.$fault = "server";
        Object.setPrototypeOf(this, InternalServerError.prototype);
    }
}
class RequestLimitExceeded extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "RequestLimitExceeded",
            $fault: "client",
            ...opts,
        });
        this.name = "RequestLimitExceeded";
        this.$fault = "client";
        Object.setPrototypeOf(this, RequestLimitExceeded.prototype);
    }
}
class InvalidEndpointException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "InvalidEndpointException",
            $fault: "client",
            ...opts,
        });
        this.name = "InvalidEndpointException";
        this.$fault = "client";
        Object.setPrototypeOf(this, InvalidEndpointException.prototype);
        this.Message = opts.Message;
    }
}
class ProvisionedThroughputExceededException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "ProvisionedThroughputExceededException",
            $fault: "client",
            ...opts,
        });
        this.name = "ProvisionedThroughputExceededException";
        this.$fault = "client";
        Object.setPrototypeOf(this, ProvisionedThroughputExceededException.prototype);
    }
}
class ResourceNotFoundException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "ResourceNotFoundException",
            $fault: "client",
            ...opts,
        });
        this.name = "ResourceNotFoundException";
        this.$fault = "client";
        Object.setPrototypeOf(this, ResourceNotFoundException.prototype);
    }
}
class ItemCollectionSizeLimitExceededException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "ItemCollectionSizeLimitExceededException",
            $fault: "client",
            ...opts,
        });
        this.name = "ItemCollectionSizeLimitExceededException";
        this.$fault = "client";
        Object.setPrototypeOf(this, ItemCollectionSizeLimitExceededException.prototype);
    }
}
class ConditionalCheckFailedException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "ConditionalCheckFailedException",
            $fault: "client",
            ...opts,
        });
        this.name = "ConditionalCheckFailedException";
        this.$fault = "client";
        Object.setPrototypeOf(this, ConditionalCheckFailedException.prototype);
    }
}
class ContinuousBackupsUnavailableException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "ContinuousBackupsUnavailableException",
            $fault: "client",
            ...opts,
        });
        this.name = "ContinuousBackupsUnavailableException";
        this.$fault = "client";
        Object.setPrototypeOf(this, ContinuousBackupsUnavailableException.prototype);
    }
}
class LimitExceededException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "LimitExceededException",
            $fault: "client",
            ...opts,
        });
        this.name = "LimitExceededException";
        this.$fault = "client";
        Object.setPrototypeOf(this, LimitExceededException.prototype);
    }
}
class TableInUseException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "TableInUseException",
            $fault: "client",
            ...opts,
        });
        this.name = "TableInUseException";
        this.$fault = "client";
        Object.setPrototypeOf(this, TableInUseException.prototype);
    }
}
class TableNotFoundException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "TableNotFoundException",
            $fault: "client",
            ...opts,
        });
        this.name = "TableNotFoundException";
        this.$fault = "client";
        Object.setPrototypeOf(this, TableNotFoundException.prototype);
    }
}
var TableClass;
(function (TableClass) {
    TableClass["STANDARD"] = "STANDARD";
    TableClass["STANDARD_INFREQUENT_ACCESS"] = "STANDARD_INFREQUENT_ACCESS";
})(TableClass || (TableClass = {}));
class GlobalTableAlreadyExistsException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "GlobalTableAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        this.name = "GlobalTableAlreadyExistsException";
        this.$fault = "client";
        Object.setPrototypeOf(this, GlobalTableAlreadyExistsException.prototype);
    }
}
class ResourceInUseException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "ResourceInUseException",
            $fault: "client",
            ...opts,
        });
        this.name = "ResourceInUseException";
        this.$fault = "client";
        Object.setPrototypeOf(this, ResourceInUseException.prototype);
    }
}
class TransactionConflictException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "TransactionConflictException",
            $fault: "client",
            ...opts,
        });
        this.name = "TransactionConflictException";
        this.$fault = "client";
        Object.setPrototypeOf(this, TransactionConflictException.prototype);
    }
}
var ExportFormat;
(function (ExportFormat) {
    ExportFormat["DYNAMODB_JSON"] = "DYNAMODB_JSON";
    ExportFormat["ION"] = "ION";
})(ExportFormat || (ExportFormat = {}));
var ExportStatus;
(function (ExportStatus) {
    ExportStatus["COMPLETED"] = "COMPLETED";
    ExportStatus["FAILED"] = "FAILED";
    ExportStatus["IN_PROGRESS"] = "IN_PROGRESS";
})(ExportStatus || (ExportStatus = {}));
class ExportNotFoundException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "ExportNotFoundException",
            $fault: "client",
            ...opts,
        });
        this.name = "ExportNotFoundException";
        this.$fault = "client";
        Object.setPrototypeOf(this, ExportNotFoundException.prototype);
    }
}
class GlobalTableNotFoundException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "GlobalTableNotFoundException",
            $fault: "client",
            ...opts,
        });
        this.name = "GlobalTableNotFoundException";
        this.$fault = "client";
        Object.setPrototypeOf(this, GlobalTableNotFoundException.prototype);
    }
}
var ImportStatus;
(function (ImportStatus) {
    ImportStatus["CANCELLED"] = "CANCELLED";
    ImportStatus["CANCELLING"] = "CANCELLING";
    ImportStatus["COMPLETED"] = "COMPLETED";
    ImportStatus["FAILED"] = "FAILED";
    ImportStatus["IN_PROGRESS"] = "IN_PROGRESS";
})(ImportStatus || (ImportStatus = {}));
var InputCompressionType;
(function (InputCompressionType) {
    InputCompressionType["GZIP"] = "GZIP";
    InputCompressionType["NONE"] = "NONE";
    InputCompressionType["ZSTD"] = "ZSTD";
})(InputCompressionType || (InputCompressionType = {}));
var InputFormat;
(function (InputFormat) {
    InputFormat["CSV"] = "CSV";
    InputFormat["DYNAMODB_JSON"] = "DYNAMODB_JSON";
    InputFormat["ION"] = "ION";
})(InputFormat || (InputFormat = {}));
class ImportNotFoundException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "ImportNotFoundException",
            $fault: "client",
            ...opts,
        });
        this.name = "ImportNotFoundException";
        this.$fault = "client";
        Object.setPrototypeOf(this, ImportNotFoundException.prototype);
    }
}
class DuplicateItemException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "DuplicateItemException",
            $fault: "client",
            ...opts,
        });
        this.name = "DuplicateItemException";
        this.$fault = "client";
        Object.setPrototypeOf(this, DuplicateItemException.prototype);
    }
}
class IdempotentParameterMismatchException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "IdempotentParameterMismatchException",
            $fault: "client",
            ...opts,
        });
        this.name = "IdempotentParameterMismatchException";
        this.$fault = "client";
        Object.setPrototypeOf(this, IdempotentParameterMismatchException.prototype);
        this.Message = opts.Message;
    }
}
class TransactionInProgressException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "TransactionInProgressException",
            $fault: "client",
            ...opts,
        });
        this.name = "TransactionInProgressException";
        this.$fault = "client";
        Object.setPrototypeOf(this, TransactionInProgressException.prototype);
        this.Message = opts.Message;
    }
}
class ExportConflictException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "ExportConflictException",
            $fault: "client",
            ...opts,
        });
        this.name = "ExportConflictException";
        this.$fault = "client";
        Object.setPrototypeOf(this, ExportConflictException.prototype);
    }
}
class InvalidExportTimeException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "InvalidExportTimeException",
            $fault: "client",
            ...opts,
        });
        this.name = "InvalidExportTimeException";
        this.$fault = "client";
        Object.setPrototypeOf(this, InvalidExportTimeException.prototype);
    }
}
class PointInTimeRecoveryUnavailableException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "PointInTimeRecoveryUnavailableException",
            $fault: "client",
            ...opts,
        });
        this.name = "PointInTimeRecoveryUnavailableException";
        this.$fault = "client";
        Object.setPrototypeOf(this, PointInTimeRecoveryUnavailableException.prototype);
    }
}
class ImportConflictException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "ImportConflictException",
            $fault: "client",
            ...opts,
        });
        this.name = "ImportConflictException";
        this.$fault = "client";
        Object.setPrototypeOf(this, ImportConflictException.prototype);
    }
}
class TableAlreadyExistsException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "TableAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        this.name = "TableAlreadyExistsException";
        this.$fault = "client";
        Object.setPrototypeOf(this, TableAlreadyExistsException.prototype);
    }
}
class InvalidRestoreTimeException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "InvalidRestoreTimeException",
            $fault: "client",
            ...opts,
        });
        this.name = "InvalidRestoreTimeException";
        this.$fault = "client";
        Object.setPrototypeOf(this, InvalidRestoreTimeException.prototype);
    }
}
class ReplicaAlreadyExistsException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "ReplicaAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        this.name = "ReplicaAlreadyExistsException";
        this.$fault = "client";
        Object.setPrototypeOf(this, ReplicaAlreadyExistsException.prototype);
    }
}
class ReplicaNotFoundException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "ReplicaNotFoundException",
            $fault: "client",
            ...opts,
        });
        this.name = "ReplicaNotFoundException";
        this.$fault = "client";
        Object.setPrototypeOf(this, ReplicaNotFoundException.prototype);
    }
}
class IndexNotFoundException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "IndexNotFoundException",
            $fault: "client",
            ...opts,
        });
        this.name = "IndexNotFoundException";
        this.$fault = "client";
        Object.setPrototypeOf(this, IndexNotFoundException.prototype);
    }
}
var AttributeValue;
(function (AttributeValue) {
    AttributeValue.visit = (value, visitor) => {
        if (value.S !== undefined)
            return visitor.S(value.S);
        if (value.N !== undefined)
            return visitor.N(value.N);
        if (value.B !== undefined)
            return visitor.B(value.B);
        if (value.SS !== undefined)
            return visitor.SS(value.SS);
        if (value.NS !== undefined)
            return visitor.NS(value.NS);
        if (value.BS !== undefined)
            return visitor.BS(value.BS);
        if (value.M !== undefined)
            return visitor.M(value.M);
        if (value.L !== undefined)
            return visitor.L(value.L);
        if (value.NULL !== undefined)
            return visitor.NULL(value.NULL);
        if (value.BOOL !== undefined)
            return visitor.BOOL(value.BOOL);
        return visitor._(value.$unknown[0], value.$unknown[1]);
    };
})(AttributeValue || (AttributeValue = {}));
class TransactionCanceledException extends DynamoDBServiceException {
    constructor(opts) {
        super({
            name: "TransactionCanceledException",
            $fault: "client",
            ...opts,
        });
        this.name = "TransactionCanceledException";
        this.$fault = "client";
        Object.setPrototypeOf(this, TransactionCanceledException.prototype);
        this.Message = opts.Message;
        this.CancellationReasons = opts.CancellationReasons;
    }
}
const ArchivalSummaryFilterSensitiveLog = (obj) => ({
    ...obj,
});
const AttributeDefinitionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const AutoScalingTargetTrackingScalingPolicyConfigurationDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const AutoScalingPolicyDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const AutoScalingTargetTrackingScalingPolicyConfigurationUpdateFilterSensitiveLog = (obj) => ({
    ...obj,
});
const AutoScalingPolicyUpdateFilterSensitiveLog = (obj) => ({
    ...obj,
});
const AutoScalingSettingsDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const AutoScalingSettingsUpdateFilterSensitiveLog = (obj) => ({
    ...obj,
});
const BackupDetailsFilterSensitiveLog = (obj) => ({
    ...obj,
});
const KeySchemaElementFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ProvisionedThroughputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const SourceTableDetailsFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ProjectionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const GlobalSecondaryIndexInfoFilterSensitiveLog = (obj) => ({
    ...obj,
});
const LocalSecondaryIndexInfoFilterSensitiveLog = (obj) => ({
    ...obj,
});
const SSEDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const StreamSpecificationFilterSensitiveLog = (obj) => ({
    ...obj,
});
const TimeToLiveDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const SourceTableFeatureDetailsFilterSensitiveLog = (obj) => ({
    ...obj,
});
const BackupDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const BackupSummaryFilterSensitiveLog = (obj) => ({
    ...obj,
});
const CapacityFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ConsumedCapacityFilterSensitiveLog = (obj) => ({
    ...obj,
});
const BatchStatementErrorFilterSensitiveLog = (obj) => ({
    ...obj,
});
const BillingModeSummaryFilterSensitiveLog = (obj) => ({
    ...obj,
});
const PointInTimeRecoveryDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ContinuousBackupsDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ContributorInsightsSummaryFilterSensitiveLog = (obj) => ({
    ...obj,
});
const CreateBackupInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const CreateBackupOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const CreateGlobalSecondaryIndexActionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ReplicaFilterSensitiveLog = (obj) => ({
    ...obj,
});
const CreateGlobalTableInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ProvisionedThroughputOverrideFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ReplicaGlobalSecondaryIndexDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const TableClassSummaryFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ReplicaDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const GlobalTableDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const CreateGlobalTableOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const CreateReplicaActionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ReplicaGlobalSecondaryIndexFilterSensitiveLog = (obj) => ({
    ...obj,
});
const CreateReplicationGroupMemberActionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const GlobalSecondaryIndexFilterSensitiveLog = (obj) => ({
    ...obj,
});
const LocalSecondaryIndexFilterSensitiveLog = (obj) => ({
    ...obj,
});
const SSESpecificationFilterSensitiveLog = (obj) => ({
    ...obj,
});
const TagFilterSensitiveLog = (obj) => ({
    ...obj,
});
const CreateTableInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ProvisionedThroughputDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const GlobalSecondaryIndexDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const LocalSecondaryIndexDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const RestoreSummaryFilterSensitiveLog = (obj) => ({
    ...obj,
});
const TableDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const CreateTableOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const CsvOptionsFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DeleteBackupInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DeleteBackupOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DeleteGlobalSecondaryIndexActionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DeleteReplicaActionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DeleteReplicationGroupMemberActionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DeleteTableInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DeleteTableOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeBackupInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeBackupOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeContinuousBackupsInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeContinuousBackupsOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeContributorInsightsInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const FailureExceptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeContributorInsightsOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeEndpointsRequestFilterSensitiveLog = (obj) => ({
    ...obj,
});
const EndpointFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeEndpointsResponseFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeExportInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ExportDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeExportOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeGlobalTableInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeGlobalTableOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeGlobalTableSettingsInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ReplicaGlobalSecondaryIndexSettingsDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ReplicaSettingsDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeGlobalTableSettingsOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeImportInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const InputFormatOptionsFilterSensitiveLog = (obj) => ({
    ...obj,
});
const S3BucketSourceFilterSensitiveLog = (obj) => ({
    ...obj,
});
const TableCreationParametersFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ImportTableDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeImportOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeKinesisStreamingDestinationInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const KinesisDataStreamDestinationFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeKinesisStreamingDestinationOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeLimitsInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeLimitsOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeTableInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeTableOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeTableReplicaAutoScalingInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ReplicaGlobalSecondaryIndexAutoScalingDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ReplicaAutoScalingDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const TableAutoScalingDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeTableReplicaAutoScalingOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeTimeToLiveInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DescribeTimeToLiveOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const KinesisStreamingDestinationInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const KinesisStreamingDestinationOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ExportTableToPointInTimeInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ExportTableToPointInTimeOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ImportTableInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ImportTableOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ListBackupsInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ListBackupsOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ListContributorInsightsInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ListContributorInsightsOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ListExportsInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ExportSummaryFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ListExportsOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ListGlobalTablesInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const GlobalTableFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ListGlobalTablesOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ListImportsInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ImportSummaryFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ListImportsOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ListTablesInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ListTablesOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ListTagsOfResourceInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ListTagsOfResourceOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const RestoreTableFromBackupInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const RestoreTableFromBackupOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const RestoreTableToPointInTimeInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const RestoreTableToPointInTimeOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const TagResourceInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const UntagResourceInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const PointInTimeRecoverySpecificationFilterSensitiveLog = (obj) => ({
    ...obj,
});
const UpdateContinuousBackupsInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const UpdateContinuousBackupsOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const UpdateContributorInsightsInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const UpdateContributorInsightsOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ReplicaUpdateFilterSensitiveLog = (obj) => ({
    ...obj,
});
const UpdateGlobalTableInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const UpdateGlobalTableOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const GlobalTableGlobalSecondaryIndexSettingsUpdateFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ReplicaGlobalSecondaryIndexSettingsUpdateFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ReplicaSettingsUpdateFilterSensitiveLog = (obj) => ({
    ...obj,
});
const UpdateGlobalTableSettingsInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const UpdateGlobalTableSettingsOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const UpdateGlobalSecondaryIndexActionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const GlobalSecondaryIndexUpdateFilterSensitiveLog = (obj) => ({
    ...obj,
});
const UpdateReplicationGroupMemberActionFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ReplicationGroupUpdateFilterSensitiveLog = (obj) => ({
    ...obj,
});
const UpdateTableInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const UpdateTableOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const GlobalSecondaryIndexAutoScalingUpdateFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ReplicaGlobalSecondaryIndexAutoScalingUpdateFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ReplicaAutoScalingUpdateFilterSensitiveLog = (obj) => ({
    ...obj,
});
const UpdateTableReplicaAutoScalingInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const UpdateTableReplicaAutoScalingOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const TimeToLiveSpecificationFilterSensitiveLog = (obj) => ({
    ...obj,
});
const UpdateTimeToLiveInputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const UpdateTimeToLiveOutputFilterSensitiveLog = (obj) => ({
    ...obj,
});
const AttributeValueFilterSensitiveLog = (obj) => {
    if (obj.S !== undefined)
        return { S: obj.S };
    if (obj.N !== undefined)
        return { N: obj.N };
    if (obj.B !== undefined)
        return { B: obj.B };
    if (obj.SS !== undefined)
        return { SS: obj.SS };
    if (obj.NS !== undefined)
        return { NS: obj.NS };
    if (obj.BS !== undefined)
        return { BS: obj.BS };
    if (obj.M !== undefined)
        return {
            M: Object.entries(obj.M).reduce((acc, [key, value]) => ({
                ...acc,
                [key]: AttributeValueFilterSensitiveLog(value),
            }), {}),
        };
    if (obj.L !== undefined)
        return { L: obj.L.map((item) => AttributeValueFilterSensitiveLog(item)) };
    if (obj.NULL !== undefined)
        return { NULL: obj.NULL };
    if (obj.BOOL !== undefined)
        return { BOOL: obj.BOOL };
    if (obj.$unknown !== undefined)
        return { [obj.$unknown[0]]: "UNKNOWN" };
};
const AttributeValueUpdateFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Value && { Value: AttributeValueFilterSensitiveLog(obj.Value) }),
});
const BatchStatementRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Parameters && { Parameters: obj.Parameters.map((item) => AttributeValueFilterSensitiveLog(item)) }),
});
const BatchStatementResponseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Item && {
        Item: Object.entries(obj.Item).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const CancellationReasonFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Item && {
        Item: Object.entries(obj.Item).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const ConditionFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.AttributeValueList && {
        AttributeValueList: obj.AttributeValueList.map((item) => AttributeValueFilterSensitiveLog(item)),
    }),
});
const DeleteRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Key && {
        Key: Object.entries(obj.Key).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const ExecuteStatementInputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Parameters && { Parameters: obj.Parameters.map((item) => AttributeValueFilterSensitiveLog(item)) }),
});
const GetFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Key && {
        Key: Object.entries(obj.Key).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const GetItemInputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Key && {
        Key: Object.entries(obj.Key).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const GetItemOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Item && {
        Item: Object.entries(obj.Item).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const ItemCollectionMetricsFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.ItemCollectionKey && {
        ItemCollectionKey: Object.entries(obj.ItemCollectionKey).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const ItemResponseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Item && {
        Item: Object.entries(obj.Item).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const ParameterizedStatementFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Parameters && { Parameters: obj.Parameters.map((item) => AttributeValueFilterSensitiveLog(item)) }),
});
const PutRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Item && {
        Item: Object.entries(obj.Item).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const KeysAndAttributesFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Keys && {
        Keys: obj.Keys.map((item) => Object.entries(item).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {})),
    }),
});
const TransactGetItemFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Get && { Get: GetFilterSensitiveLog(obj.Get) }),
});
const BatchExecuteStatementInputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Statements && { Statements: obj.Statements.map((item) => BatchStatementRequestFilterSensitiveLog(item)) }),
});
const BatchExecuteStatementOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Responses && { Responses: obj.Responses.map((item) => BatchStatementResponseFilterSensitiveLog(item)) }),
});
const ExecuteTransactionInputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.TransactStatements && {
        TransactStatements: obj.TransactStatements.map((item) => ParameterizedStatementFilterSensitiveLog(item)),
    }),
});
const ExecuteTransactionOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Responses && { Responses: obj.Responses.map((item) => ItemResponseFilterSensitiveLog(item)) }),
});
const TransactGetItemsOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Responses && { Responses: obj.Responses.map((item) => ItemResponseFilterSensitiveLog(item)) }),
});
const BatchGetItemInputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.RequestItems && {
        RequestItems: Object.entries(obj.RequestItems).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: KeysAndAttributesFilterSensitiveLog(value),
        }), {}),
    }),
});
const ExpectedAttributeValueFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Value && { Value: AttributeValueFilterSensitiveLog(obj.Value) }),
    ...(obj.AttributeValueList && {
        AttributeValueList: obj.AttributeValueList.map((item) => AttributeValueFilterSensitiveLog(item)),
    }),
});
const TransactGetItemsInputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.TransactItems && { TransactItems: obj.TransactItems.map((item) => TransactGetItemFilterSensitiveLog(item)) }),
});
const TransactWriteItemsOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.ItemCollectionMetrics && {
        ItemCollectionMetrics: Object.entries(obj.ItemCollectionMetrics).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: value.map((item) => ItemCollectionMetricsFilterSensitiveLog(item)),
        }), {}),
    }),
});
const ConditionCheckFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Key && {
        Key: Object.entries(obj.Key).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.ExpressionAttributeValues && {
        ExpressionAttributeValues: Object.entries(obj.ExpressionAttributeValues).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const DeleteFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Key && {
        Key: Object.entries(obj.Key).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.ExpressionAttributeValues && {
        ExpressionAttributeValues: Object.entries(obj.ExpressionAttributeValues).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const PutFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Item && {
        Item: Object.entries(obj.Item).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.ExpressionAttributeValues && {
        ExpressionAttributeValues: Object.entries(obj.ExpressionAttributeValues).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const UpdateFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Key && {
        Key: Object.entries(obj.Key).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.ExpressionAttributeValues && {
        ExpressionAttributeValues: Object.entries(obj.ExpressionAttributeValues).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const DeleteItemOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Attributes && {
        Attributes: Object.entries(obj.Attributes).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.ItemCollectionMetrics && {
        ItemCollectionMetrics: ItemCollectionMetricsFilterSensitiveLog(obj.ItemCollectionMetrics),
    }),
});
const ExecuteStatementOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Items && {
        Items: obj.Items.map((item) => Object.entries(item).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {})),
    }),
    ...(obj.LastEvaluatedKey && {
        LastEvaluatedKey: Object.entries(obj.LastEvaluatedKey).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const PutItemOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Attributes && {
        Attributes: Object.entries(obj.Attributes).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.ItemCollectionMetrics && {
        ItemCollectionMetrics: ItemCollectionMetricsFilterSensitiveLog(obj.ItemCollectionMetrics),
    }),
});
const QueryOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Items && {
        Items: obj.Items.map((item) => Object.entries(item).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {})),
    }),
    ...(obj.LastEvaluatedKey && {
        LastEvaluatedKey: Object.entries(obj.LastEvaluatedKey).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const ScanOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Items && {
        Items: obj.Items.map((item) => Object.entries(item).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {})),
    }),
    ...(obj.LastEvaluatedKey && {
        LastEvaluatedKey: Object.entries(obj.LastEvaluatedKey).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const UpdateItemOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Attributes && {
        Attributes: Object.entries(obj.Attributes).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.ItemCollectionMetrics && {
        ItemCollectionMetrics: ItemCollectionMetricsFilterSensitiveLog(obj.ItemCollectionMetrics),
    }),
});
const WriteRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.PutRequest && { PutRequest: PutRequestFilterSensitiveLog(obj.PutRequest) }),
    ...(obj.DeleteRequest && { DeleteRequest: DeleteRequestFilterSensitiveLog(obj.DeleteRequest) }),
});
const BatchGetItemOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Responses && {
        Responses: Object.entries(obj.Responses).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: value.map((item) => Object.entries(item).reduce((acc, [key, value]) => ({
                ...acc,
                [key]: AttributeValueFilterSensitiveLog(value),
            }), {})),
        }), {}),
    }),
    ...(obj.UnprocessedKeys && {
        UnprocessedKeys: Object.entries(obj.UnprocessedKeys).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: KeysAndAttributesFilterSensitiveLog(value),
        }), {}),
    }),
});
const ScanInputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.ScanFilter && {
        ScanFilter: Object.entries(obj.ScanFilter).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: ConditionFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.ExclusiveStartKey && {
        ExclusiveStartKey: Object.entries(obj.ExclusiveStartKey).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.ExpressionAttributeValues && {
        ExpressionAttributeValues: Object.entries(obj.ExpressionAttributeValues).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const BatchWriteItemInputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.RequestItems && {
        RequestItems: Object.entries(obj.RequestItems).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: value.map((item) => WriteRequestFilterSensitiveLog(item)),
        }), {}),
    }),
});
const DeleteItemInputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Key && {
        Key: Object.entries(obj.Key).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.Expected && {
        Expected: Object.entries(obj.Expected).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: ExpectedAttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.ExpressionAttributeValues && {
        ExpressionAttributeValues: Object.entries(obj.ExpressionAttributeValues).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const PutItemInputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Item && {
        Item: Object.entries(obj.Item).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.Expected && {
        Expected: Object.entries(obj.Expected).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: ExpectedAttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.ExpressionAttributeValues && {
        ExpressionAttributeValues: Object.entries(obj.ExpressionAttributeValues).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const QueryInputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.KeyConditions && {
        KeyConditions: Object.entries(obj.KeyConditions).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: ConditionFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.QueryFilter && {
        QueryFilter: Object.entries(obj.QueryFilter).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: ConditionFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.ExclusiveStartKey && {
        ExclusiveStartKey: Object.entries(obj.ExclusiveStartKey).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.ExpressionAttributeValues && {
        ExpressionAttributeValues: Object.entries(obj.ExpressionAttributeValues).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const BatchWriteItemOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.UnprocessedItems && {
        UnprocessedItems: Object.entries(obj.UnprocessedItems).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: value.map((item) => WriteRequestFilterSensitiveLog(item)),
        }), {}),
    }),
    ...(obj.ItemCollectionMetrics && {
        ItemCollectionMetrics: Object.entries(obj.ItemCollectionMetrics).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: value.map((item) => ItemCollectionMetricsFilterSensitiveLog(item)),
        }), {}),
    }),
});
const UpdateItemInputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Key && {
        Key: Object.entries(obj.Key).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.AttributeUpdates && {
        AttributeUpdates: Object.entries(obj.AttributeUpdates).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueUpdateFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.Expected && {
        Expected: Object.entries(obj.Expected).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: ExpectedAttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
    ...(obj.ExpressionAttributeValues && {
        ExpressionAttributeValues: Object.entries(obj.ExpressionAttributeValues).reduce((acc, [key, value]) => ({
            ...acc,
            [key]: AttributeValueFilterSensitiveLog(value),
        }), {}),
    }),
});
const TransactWriteItemFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.ConditionCheck && { ConditionCheck: ConditionCheckFilterSensitiveLog(obj.ConditionCheck) }),
    ...(obj.Put && { Put: PutFilterSensitiveLog(obj.Put) }),
    ...(obj.Delete && { Delete: DeleteFilterSensitiveLog(obj.Delete) }),
    ...(obj.Update && { Update: UpdateFilterSensitiveLog(obj.Update) }),
});
const TransactWriteItemsInputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.TransactItems && {
        TransactItems: obj.TransactItems.map((item) => TransactWriteItemFilterSensitiveLog(item)),
    }),
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/protocol-http/dist-es/httpRequest.js
class httpRequest_HttpRequest {
    constructor(options) {
        this.method = options.method || "GET";
        this.hostname = options.hostname || "localhost";
        this.port = options.port;
        this.query = options.query || {};
        this.headers = options.headers || {};
        this.body = options.body;
        this.protocol = options.protocol
            ? options.protocol.slice(-1) !== ":"
                ? `${options.protocol}:`
                : options.protocol
            : "https:";
        this.path = options.path ? (options.path.charAt(0) !== "/" ? `/${options.path}` : options.path) : "/";
    }
    static isInstance(request) {
        if (!request)
            return false;
        const req = request;
        return ("method" in req &&
            "protocol" in req &&
            "hostname" in req &&
            "path" in req &&
            typeof req["query"] === "object" &&
            typeof req["headers"] === "object");
    }
    clone() {
        const cloned = new httpRequest_HttpRequest({
            ...this,
            headers: { ...this.headers },
        });
        if (cloned.query)
            cloned.query = cloneQuery(cloned.query);
        return cloned;
    }
}
function cloneQuery(query) {
    return Object.keys(query).reduce((carry, paramName) => {
        const param = query[paramName];
        return {
            ...carry,
            [paramName]: Array.isArray(param) ? [...param] : param,
        };
    }, {});
}

;// CONCATENATED MODULE: external "crypto"
const external_crypto_namespaceObject = require("crypto");
var external_crypto_default = /*#__PURE__*/__webpack_require__.n(external_crypto_namespaceObject);
;// CONCATENATED MODULE: ../node_modules/uuid/dist/esm-node/rng.js

const rnds8Pool = new Uint8Array(256); // # of random values to pre-allocate

let poolPtr = rnds8Pool.length;
function rng() {
  if (poolPtr > rnds8Pool.length - 16) {
    external_crypto_default().randomFillSync(rnds8Pool);
    poolPtr = 0;
  }

  return rnds8Pool.slice(poolPtr, poolPtr += 16);
}
;// CONCATENATED MODULE: ../node_modules/uuid/dist/esm-node/regex.js
/* harmony default export */ const regex = (/^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i);
;// CONCATENATED MODULE: ../node_modules/uuid/dist/esm-node/validate.js


function validate(uuid) {
  return typeof uuid === 'string' && regex.test(uuid);
}

/* harmony default export */ const esm_node_validate = (validate);
;// CONCATENATED MODULE: ../node_modules/uuid/dist/esm-node/stringify.js

/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */

const byteToHex = [];

for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 0x100).toString(16).substr(1));
}

function stringify(arr, offset = 0) {
  // Note: Be careful editing this code!  It's been tuned for performance
  // and works in ways you may not expect. See https://github.com/uuidjs/uuid/pull/434
  const uuid = (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + '-' + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + '-' + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + '-' + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + '-' + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase(); // Consistency check for valid UUID.  If this throws, it's likely due to one
  // of the following:
  // - One or more input array values don't map to a hex octet (leading to
  // "undefined" in the uuid)
  // - Invalid input values for the RFC `version` or `variant` fields

  if (!esm_node_validate(uuid)) {
    throw TypeError('Stringified UUID is invalid');
  }

  return uuid;
}

/* harmony default export */ const esm_node_stringify = (stringify);
;// CONCATENATED MODULE: ../node_modules/uuid/dist/esm-node/v4.js



function v4(options, buf, offset) {
  options = options || {};
  const rnds = options.random || (options.rng || rng)(); // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`

  rnds[6] = rnds[6] & 0x0f | 0x40;
  rnds[8] = rnds[8] & 0x3f | 0x80; // Copy bytes to buffer, if provided

  if (buf) {
    offset = offset || 0;

    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }

    return buf;
  }

  return esm_node_stringify(rnds);
}

/* harmony default export */ const esm_node_v4 = (v4);
;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/protocols/Aws_json1_0.js





const serializeAws_json1_0BatchExecuteStatementCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.BatchExecuteStatement",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0BatchExecuteStatementInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0BatchGetItemCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.BatchGetItem",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0BatchGetItemInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0BatchWriteItemCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.BatchWriteItem",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0BatchWriteItemInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0CreateBackupCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.CreateBackup",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0CreateBackupInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0CreateGlobalTableCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.CreateGlobalTable",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0CreateGlobalTableInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0CreateTableCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.CreateTable",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0CreateTableInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0DeleteBackupCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.DeleteBackup",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0DeleteBackupInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0DeleteItemCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.DeleteItem",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0DeleteItemInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0DeleteTableCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.DeleteTable",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0DeleteTableInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0DescribeBackupCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.DescribeBackup",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0DescribeBackupInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0DescribeContinuousBackupsCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.DescribeContinuousBackups",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0DescribeContinuousBackupsInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0DescribeContributorInsightsCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.DescribeContributorInsights",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0DescribeContributorInsightsInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0DescribeEndpointsCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.DescribeEndpoints",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0DescribeEndpointsRequest(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0DescribeExportCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.DescribeExport",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0DescribeExportInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0DescribeGlobalTableCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.DescribeGlobalTable",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0DescribeGlobalTableInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0DescribeGlobalTableSettingsCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.DescribeGlobalTableSettings",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0DescribeGlobalTableSettingsInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0DescribeImportCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.DescribeImport",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0DescribeImportInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0DescribeKinesisStreamingDestinationCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.DescribeKinesisStreamingDestination",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0DescribeKinesisStreamingDestinationInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0DescribeLimitsCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.DescribeLimits",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0DescribeLimitsInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0DescribeTableCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.DescribeTable",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0DescribeTableInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0DescribeTableReplicaAutoScalingCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.DescribeTableReplicaAutoScaling",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0DescribeTableReplicaAutoScalingInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0DescribeTimeToLiveCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.DescribeTimeToLive",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0DescribeTimeToLiveInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0DisableKinesisStreamingDestinationCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.DisableKinesisStreamingDestination",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0KinesisStreamingDestinationInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0EnableKinesisStreamingDestinationCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.EnableKinesisStreamingDestination",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0KinesisStreamingDestinationInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0ExecuteStatementCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.ExecuteStatement",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0ExecuteStatementInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0ExecuteTransactionCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.ExecuteTransaction",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0ExecuteTransactionInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0ExportTableToPointInTimeCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.ExportTableToPointInTime",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0ExportTableToPointInTimeInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0GetItemCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.GetItem",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0GetItemInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0ImportTableCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.ImportTable",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0ImportTableInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0ListBackupsCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.ListBackups",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0ListBackupsInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0ListContributorInsightsCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.ListContributorInsights",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0ListContributorInsightsInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0ListExportsCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.ListExports",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0ListExportsInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0ListGlobalTablesCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.ListGlobalTables",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0ListGlobalTablesInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0ListImportsCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.ListImports",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0ListImportsInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0ListTablesCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.ListTables",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0ListTablesInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0ListTagsOfResourceCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.ListTagsOfResource",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0ListTagsOfResourceInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0PutItemCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.PutItem",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0PutItemInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0QueryCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.Query",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0QueryInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0RestoreTableFromBackupCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.RestoreTableFromBackup",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0RestoreTableFromBackupInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0RestoreTableToPointInTimeCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.RestoreTableToPointInTime",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0RestoreTableToPointInTimeInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0ScanCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.Scan",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0ScanInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0TagResourceCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.TagResource",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0TagResourceInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0TransactGetItemsCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.TransactGetItems",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0TransactGetItemsInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0TransactWriteItemsCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.TransactWriteItems",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0TransactWriteItemsInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0UntagResourceCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.UntagResource",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0UntagResourceInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0UpdateContinuousBackupsCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.UpdateContinuousBackups",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0UpdateContinuousBackupsInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0UpdateContributorInsightsCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.UpdateContributorInsights",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0UpdateContributorInsightsInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0UpdateGlobalTableCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.UpdateGlobalTable",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0UpdateGlobalTableInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0UpdateGlobalTableSettingsCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.UpdateGlobalTableSettings",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0UpdateGlobalTableSettingsInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0UpdateItemCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.UpdateItem",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0UpdateItemInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0UpdateTableCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.UpdateTable",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0UpdateTableInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0UpdateTableReplicaAutoScalingCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.UpdateTableReplicaAutoScaling",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0UpdateTableReplicaAutoScalingInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_json1_0UpdateTimeToLiveCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": "DynamoDB_20120810.UpdateTimeToLive",
    };
    let body;
    body = JSON.stringify(serializeAws_json1_0UpdateTimeToLiveInput(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const deserializeAws_json1_0BatchExecuteStatementCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0BatchExecuteStatementCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0BatchExecuteStatementOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0BatchExecuteStatementCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "RequestLimitExceeded":
        case "com.amazonaws.dynamodb#RequestLimitExceeded":
            throw await deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0BatchGetItemCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0BatchGetItemCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0BatchGetItemOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0BatchGetItemCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "ProvisionedThroughputExceededException":
        case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException":
            throw await deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context);
        case "RequestLimitExceeded":
        case "com.amazonaws.dynamodb#RequestLimitExceeded":
            throw await deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0BatchWriteItemCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0BatchWriteItemCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0BatchWriteItemOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0BatchWriteItemCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "ItemCollectionSizeLimitExceededException":
        case "com.amazonaws.dynamodb#ItemCollectionSizeLimitExceededException":
            throw await deserializeAws_json1_0ItemCollectionSizeLimitExceededExceptionResponse(parsedOutput, context);
        case "ProvisionedThroughputExceededException":
        case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException":
            throw await deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context);
        case "RequestLimitExceeded":
        case "com.amazonaws.dynamodb#RequestLimitExceeded":
            throw await deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0CreateBackupCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0CreateBackupCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0CreateBackupOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0CreateBackupCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "BackupInUseException":
        case "com.amazonaws.dynamodb#BackupInUseException":
            throw await deserializeAws_json1_0BackupInUseExceptionResponse(parsedOutput, context);
        case "ContinuousBackupsUnavailableException":
        case "com.amazonaws.dynamodb#ContinuousBackupsUnavailableException":
            throw await deserializeAws_json1_0ContinuousBackupsUnavailableExceptionResponse(parsedOutput, context);
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        case "TableInUseException":
        case "com.amazonaws.dynamodb#TableInUseException":
            throw await deserializeAws_json1_0TableInUseExceptionResponse(parsedOutput, context);
        case "TableNotFoundException":
        case "com.amazonaws.dynamodb#TableNotFoundException":
            throw await deserializeAws_json1_0TableNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0CreateGlobalTableCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0CreateGlobalTableCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0CreateGlobalTableOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0CreateGlobalTableCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "GlobalTableAlreadyExistsException":
        case "com.amazonaws.dynamodb#GlobalTableAlreadyExistsException":
            throw await deserializeAws_json1_0GlobalTableAlreadyExistsExceptionResponse(parsedOutput, context);
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        case "TableNotFoundException":
        case "com.amazonaws.dynamodb#TableNotFoundException":
            throw await deserializeAws_json1_0TableNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0CreateTableCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0CreateTableCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0CreateTableOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0CreateTableCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        case "ResourceInUseException":
        case "com.amazonaws.dynamodb#ResourceInUseException":
            throw await deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0DeleteBackupCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0DeleteBackupCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0DeleteBackupOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0DeleteBackupCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "BackupInUseException":
        case "com.amazonaws.dynamodb#BackupInUseException":
            throw await deserializeAws_json1_0BackupInUseExceptionResponse(parsedOutput, context);
        case "BackupNotFoundException":
        case "com.amazonaws.dynamodb#BackupNotFoundException":
            throw await deserializeAws_json1_0BackupNotFoundExceptionResponse(parsedOutput, context);
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0DeleteItemCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0DeleteItemCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0DeleteItemOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0DeleteItemCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "ConditionalCheckFailedException":
        case "com.amazonaws.dynamodb#ConditionalCheckFailedException":
            throw await deserializeAws_json1_0ConditionalCheckFailedExceptionResponse(parsedOutput, context);
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "ItemCollectionSizeLimitExceededException":
        case "com.amazonaws.dynamodb#ItemCollectionSizeLimitExceededException":
            throw await deserializeAws_json1_0ItemCollectionSizeLimitExceededExceptionResponse(parsedOutput, context);
        case "ProvisionedThroughputExceededException":
        case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException":
            throw await deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context);
        case "RequestLimitExceeded":
        case "com.amazonaws.dynamodb#RequestLimitExceeded":
            throw await deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        case "TransactionConflictException":
        case "com.amazonaws.dynamodb#TransactionConflictException":
            throw await deserializeAws_json1_0TransactionConflictExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0DeleteTableCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0DeleteTableCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0DeleteTableOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0DeleteTableCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        case "ResourceInUseException":
        case "com.amazonaws.dynamodb#ResourceInUseException":
            throw await deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0DescribeBackupCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0DescribeBackupCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0DescribeBackupOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0DescribeBackupCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "BackupNotFoundException":
        case "com.amazonaws.dynamodb#BackupNotFoundException":
            throw await deserializeAws_json1_0BackupNotFoundExceptionResponse(parsedOutput, context);
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0DescribeContinuousBackupsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0DescribeContinuousBackupsCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0DescribeContinuousBackupsOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0DescribeContinuousBackupsCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "TableNotFoundException":
        case "com.amazonaws.dynamodb#TableNotFoundException":
            throw await deserializeAws_json1_0TableNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0DescribeContributorInsightsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0DescribeContributorInsightsCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0DescribeContributorInsightsOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0DescribeContributorInsightsCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0DescribeEndpointsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0DescribeEndpointsCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0DescribeEndpointsResponse(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0DescribeEndpointsCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    const parsedBody = parsedOutput.body;
    default_error_handler_throwDefaultError({
        output,
        parsedBody,
        exceptionCtor: DynamoDBServiceException,
        errorCode,
    });
};
const deserializeAws_json1_0DescribeExportCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0DescribeExportCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0DescribeExportOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0DescribeExportCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "ExportNotFoundException":
        case "com.amazonaws.dynamodb#ExportNotFoundException":
            throw await deserializeAws_json1_0ExportNotFoundExceptionResponse(parsedOutput, context);
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0DescribeGlobalTableCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0DescribeGlobalTableCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0DescribeGlobalTableOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0DescribeGlobalTableCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "GlobalTableNotFoundException":
        case "com.amazonaws.dynamodb#GlobalTableNotFoundException":
            throw await deserializeAws_json1_0GlobalTableNotFoundExceptionResponse(parsedOutput, context);
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0DescribeGlobalTableSettingsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0DescribeGlobalTableSettingsCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0DescribeGlobalTableSettingsOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0DescribeGlobalTableSettingsCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "GlobalTableNotFoundException":
        case "com.amazonaws.dynamodb#GlobalTableNotFoundException":
            throw await deserializeAws_json1_0GlobalTableNotFoundExceptionResponse(parsedOutput, context);
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0DescribeImportCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0DescribeImportCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0DescribeImportOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0DescribeImportCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "ImportNotFoundException":
        case "com.amazonaws.dynamodb#ImportNotFoundException":
            throw await deserializeAws_json1_0ImportNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0DescribeKinesisStreamingDestinationCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0DescribeKinesisStreamingDestinationCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0DescribeKinesisStreamingDestinationOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0DescribeKinesisStreamingDestinationCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0DescribeLimitsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0DescribeLimitsCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0DescribeLimitsOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0DescribeLimitsCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0DescribeTableCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0DescribeTableCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0DescribeTableOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0DescribeTableCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0DescribeTableReplicaAutoScalingCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0DescribeTableReplicaAutoScalingCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0DescribeTableReplicaAutoScalingOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0DescribeTableReplicaAutoScalingCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0DescribeTimeToLiveCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0DescribeTimeToLiveCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0DescribeTimeToLiveOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0DescribeTimeToLiveCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0DisableKinesisStreamingDestinationCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0DisableKinesisStreamingDestinationCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0KinesisStreamingDestinationOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0DisableKinesisStreamingDestinationCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        case "ResourceInUseException":
        case "com.amazonaws.dynamodb#ResourceInUseException":
            throw await deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0EnableKinesisStreamingDestinationCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0EnableKinesisStreamingDestinationCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0KinesisStreamingDestinationOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0EnableKinesisStreamingDestinationCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        case "ResourceInUseException":
        case "com.amazonaws.dynamodb#ResourceInUseException":
            throw await deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0ExecuteStatementCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0ExecuteStatementCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0ExecuteStatementOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0ExecuteStatementCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "ConditionalCheckFailedException":
        case "com.amazonaws.dynamodb#ConditionalCheckFailedException":
            throw await deserializeAws_json1_0ConditionalCheckFailedExceptionResponse(parsedOutput, context);
        case "DuplicateItemException":
        case "com.amazonaws.dynamodb#DuplicateItemException":
            throw await deserializeAws_json1_0DuplicateItemExceptionResponse(parsedOutput, context);
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "ItemCollectionSizeLimitExceededException":
        case "com.amazonaws.dynamodb#ItemCollectionSizeLimitExceededException":
            throw await deserializeAws_json1_0ItemCollectionSizeLimitExceededExceptionResponse(parsedOutput, context);
        case "ProvisionedThroughputExceededException":
        case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException":
            throw await deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context);
        case "RequestLimitExceeded":
        case "com.amazonaws.dynamodb#RequestLimitExceeded":
            throw await deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        case "TransactionConflictException":
        case "com.amazonaws.dynamodb#TransactionConflictException":
            throw await deserializeAws_json1_0TransactionConflictExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0ExecuteTransactionCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0ExecuteTransactionCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0ExecuteTransactionOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0ExecuteTransactionCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "IdempotentParameterMismatchException":
        case "com.amazonaws.dynamodb#IdempotentParameterMismatchException":
            throw await deserializeAws_json1_0IdempotentParameterMismatchExceptionResponse(parsedOutput, context);
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "ProvisionedThroughputExceededException":
        case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException":
            throw await deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context);
        case "RequestLimitExceeded":
        case "com.amazonaws.dynamodb#RequestLimitExceeded":
            throw await deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        case "TransactionCanceledException":
        case "com.amazonaws.dynamodb#TransactionCanceledException":
            throw await deserializeAws_json1_0TransactionCanceledExceptionResponse(parsedOutput, context);
        case "TransactionInProgressException":
        case "com.amazonaws.dynamodb#TransactionInProgressException":
            throw await deserializeAws_json1_0TransactionInProgressExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0ExportTableToPointInTimeCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0ExportTableToPointInTimeCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0ExportTableToPointInTimeOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0ExportTableToPointInTimeCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "ExportConflictException":
        case "com.amazonaws.dynamodb#ExportConflictException":
            throw await deserializeAws_json1_0ExportConflictExceptionResponse(parsedOutput, context);
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidExportTimeException":
        case "com.amazonaws.dynamodb#InvalidExportTimeException":
            throw await deserializeAws_json1_0InvalidExportTimeExceptionResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        case "PointInTimeRecoveryUnavailableException":
        case "com.amazonaws.dynamodb#PointInTimeRecoveryUnavailableException":
            throw await deserializeAws_json1_0PointInTimeRecoveryUnavailableExceptionResponse(parsedOutput, context);
        case "TableNotFoundException":
        case "com.amazonaws.dynamodb#TableNotFoundException":
            throw await deserializeAws_json1_0TableNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0GetItemCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0GetItemCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0GetItemOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0GetItemCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "ProvisionedThroughputExceededException":
        case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException":
            throw await deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context);
        case "RequestLimitExceeded":
        case "com.amazonaws.dynamodb#RequestLimitExceeded":
            throw await deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0ImportTableCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0ImportTableCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0ImportTableOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0ImportTableCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "ImportConflictException":
        case "com.amazonaws.dynamodb#ImportConflictException":
            throw await deserializeAws_json1_0ImportConflictExceptionResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        case "ResourceInUseException":
        case "com.amazonaws.dynamodb#ResourceInUseException":
            throw await deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0ListBackupsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0ListBackupsCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0ListBackupsOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0ListBackupsCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0ListContributorInsightsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0ListContributorInsightsCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0ListContributorInsightsOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0ListContributorInsightsCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0ListExportsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0ListExportsCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0ListExportsOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0ListExportsCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0ListGlobalTablesCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0ListGlobalTablesCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0ListGlobalTablesOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0ListGlobalTablesCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0ListImportsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0ListImportsCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0ListImportsOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0ListImportsCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0ListTablesCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0ListTablesCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0ListTablesOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0ListTablesCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0ListTagsOfResourceCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0ListTagsOfResourceCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0ListTagsOfResourceOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0ListTagsOfResourceCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0PutItemCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0PutItemCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0PutItemOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0PutItemCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "ConditionalCheckFailedException":
        case "com.amazonaws.dynamodb#ConditionalCheckFailedException":
            throw await deserializeAws_json1_0ConditionalCheckFailedExceptionResponse(parsedOutput, context);
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "ItemCollectionSizeLimitExceededException":
        case "com.amazonaws.dynamodb#ItemCollectionSizeLimitExceededException":
            throw await deserializeAws_json1_0ItemCollectionSizeLimitExceededExceptionResponse(parsedOutput, context);
        case "ProvisionedThroughputExceededException":
        case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException":
            throw await deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context);
        case "RequestLimitExceeded":
        case "com.amazonaws.dynamodb#RequestLimitExceeded":
            throw await deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        case "TransactionConflictException":
        case "com.amazonaws.dynamodb#TransactionConflictException":
            throw await deserializeAws_json1_0TransactionConflictExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0QueryCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0QueryCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0QueryOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0QueryCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "ProvisionedThroughputExceededException":
        case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException":
            throw await deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context);
        case "RequestLimitExceeded":
        case "com.amazonaws.dynamodb#RequestLimitExceeded":
            throw await deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0RestoreTableFromBackupCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0RestoreTableFromBackupCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0RestoreTableFromBackupOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0RestoreTableFromBackupCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "BackupInUseException":
        case "com.amazonaws.dynamodb#BackupInUseException":
            throw await deserializeAws_json1_0BackupInUseExceptionResponse(parsedOutput, context);
        case "BackupNotFoundException":
        case "com.amazonaws.dynamodb#BackupNotFoundException":
            throw await deserializeAws_json1_0BackupNotFoundExceptionResponse(parsedOutput, context);
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        case "TableAlreadyExistsException":
        case "com.amazonaws.dynamodb#TableAlreadyExistsException":
            throw await deserializeAws_json1_0TableAlreadyExistsExceptionResponse(parsedOutput, context);
        case "TableInUseException":
        case "com.amazonaws.dynamodb#TableInUseException":
            throw await deserializeAws_json1_0TableInUseExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0RestoreTableToPointInTimeCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0RestoreTableToPointInTimeCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0RestoreTableToPointInTimeOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0RestoreTableToPointInTimeCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "InvalidRestoreTimeException":
        case "com.amazonaws.dynamodb#InvalidRestoreTimeException":
            throw await deserializeAws_json1_0InvalidRestoreTimeExceptionResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        case "PointInTimeRecoveryUnavailableException":
        case "com.amazonaws.dynamodb#PointInTimeRecoveryUnavailableException":
            throw await deserializeAws_json1_0PointInTimeRecoveryUnavailableExceptionResponse(parsedOutput, context);
        case "TableAlreadyExistsException":
        case "com.amazonaws.dynamodb#TableAlreadyExistsException":
            throw await deserializeAws_json1_0TableAlreadyExistsExceptionResponse(parsedOutput, context);
        case "TableInUseException":
        case "com.amazonaws.dynamodb#TableInUseException":
            throw await deserializeAws_json1_0TableInUseExceptionResponse(parsedOutput, context);
        case "TableNotFoundException":
        case "com.amazonaws.dynamodb#TableNotFoundException":
            throw await deserializeAws_json1_0TableNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0ScanCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0ScanCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0ScanOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0ScanCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "ProvisionedThroughputExceededException":
        case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException":
            throw await deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context);
        case "RequestLimitExceeded":
        case "com.amazonaws.dynamodb#RequestLimitExceeded":
            throw await deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0TagResourceCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0TagResourceCommandError(output, context);
    }
    await collectBody(output.body, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0TagResourceCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        case "ResourceInUseException":
        case "com.amazonaws.dynamodb#ResourceInUseException":
            throw await deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0TransactGetItemsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0TransactGetItemsCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0TransactGetItemsOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0TransactGetItemsCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "ProvisionedThroughputExceededException":
        case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException":
            throw await deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context);
        case "RequestLimitExceeded":
        case "com.amazonaws.dynamodb#RequestLimitExceeded":
            throw await deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        case "TransactionCanceledException":
        case "com.amazonaws.dynamodb#TransactionCanceledException":
            throw await deserializeAws_json1_0TransactionCanceledExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0TransactWriteItemsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0TransactWriteItemsCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0TransactWriteItemsOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0TransactWriteItemsCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "IdempotentParameterMismatchException":
        case "com.amazonaws.dynamodb#IdempotentParameterMismatchException":
            throw await deserializeAws_json1_0IdempotentParameterMismatchExceptionResponse(parsedOutput, context);
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "ProvisionedThroughputExceededException":
        case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException":
            throw await deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context);
        case "RequestLimitExceeded":
        case "com.amazonaws.dynamodb#RequestLimitExceeded":
            throw await deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        case "TransactionCanceledException":
        case "com.amazonaws.dynamodb#TransactionCanceledException":
            throw await deserializeAws_json1_0TransactionCanceledExceptionResponse(parsedOutput, context);
        case "TransactionInProgressException":
        case "com.amazonaws.dynamodb#TransactionInProgressException":
            throw await deserializeAws_json1_0TransactionInProgressExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0UntagResourceCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0UntagResourceCommandError(output, context);
    }
    await collectBody(output.body, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0UntagResourceCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        case "ResourceInUseException":
        case "com.amazonaws.dynamodb#ResourceInUseException":
            throw await deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0UpdateContinuousBackupsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0UpdateContinuousBackupsCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0UpdateContinuousBackupsOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0UpdateContinuousBackupsCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "ContinuousBackupsUnavailableException":
        case "com.amazonaws.dynamodb#ContinuousBackupsUnavailableException":
            throw await deserializeAws_json1_0ContinuousBackupsUnavailableExceptionResponse(parsedOutput, context);
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "TableNotFoundException":
        case "com.amazonaws.dynamodb#TableNotFoundException":
            throw await deserializeAws_json1_0TableNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0UpdateContributorInsightsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0UpdateContributorInsightsCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0UpdateContributorInsightsOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0UpdateContributorInsightsCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0UpdateGlobalTableCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0UpdateGlobalTableCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0UpdateGlobalTableOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0UpdateGlobalTableCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "GlobalTableNotFoundException":
        case "com.amazonaws.dynamodb#GlobalTableNotFoundException":
            throw await deserializeAws_json1_0GlobalTableNotFoundExceptionResponse(parsedOutput, context);
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "ReplicaAlreadyExistsException":
        case "com.amazonaws.dynamodb#ReplicaAlreadyExistsException":
            throw await deserializeAws_json1_0ReplicaAlreadyExistsExceptionResponse(parsedOutput, context);
        case "ReplicaNotFoundException":
        case "com.amazonaws.dynamodb#ReplicaNotFoundException":
            throw await deserializeAws_json1_0ReplicaNotFoundExceptionResponse(parsedOutput, context);
        case "TableNotFoundException":
        case "com.amazonaws.dynamodb#TableNotFoundException":
            throw await deserializeAws_json1_0TableNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0UpdateGlobalTableSettingsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0UpdateGlobalTableSettingsCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0UpdateGlobalTableSettingsOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0UpdateGlobalTableSettingsCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "GlobalTableNotFoundException":
        case "com.amazonaws.dynamodb#GlobalTableNotFoundException":
            throw await deserializeAws_json1_0GlobalTableNotFoundExceptionResponse(parsedOutput, context);
        case "IndexNotFoundException":
        case "com.amazonaws.dynamodb#IndexNotFoundException":
            throw await deserializeAws_json1_0IndexNotFoundExceptionResponse(parsedOutput, context);
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        case "ReplicaNotFoundException":
        case "com.amazonaws.dynamodb#ReplicaNotFoundException":
            throw await deserializeAws_json1_0ReplicaNotFoundExceptionResponse(parsedOutput, context);
        case "ResourceInUseException":
        case "com.amazonaws.dynamodb#ResourceInUseException":
            throw await deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0UpdateItemCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0UpdateItemCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0UpdateItemOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0UpdateItemCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "ConditionalCheckFailedException":
        case "com.amazonaws.dynamodb#ConditionalCheckFailedException":
            throw await deserializeAws_json1_0ConditionalCheckFailedExceptionResponse(parsedOutput, context);
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "ItemCollectionSizeLimitExceededException":
        case "com.amazonaws.dynamodb#ItemCollectionSizeLimitExceededException":
            throw await deserializeAws_json1_0ItemCollectionSizeLimitExceededExceptionResponse(parsedOutput, context);
        case "ProvisionedThroughputExceededException":
        case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException":
            throw await deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context);
        case "RequestLimitExceeded":
        case "com.amazonaws.dynamodb#RequestLimitExceeded":
            throw await deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        case "TransactionConflictException":
        case "com.amazonaws.dynamodb#TransactionConflictException":
            throw await deserializeAws_json1_0TransactionConflictExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0UpdateTableCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0UpdateTableCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0UpdateTableOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0UpdateTableCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        case "ResourceInUseException":
        case "com.amazonaws.dynamodb#ResourceInUseException":
            throw await deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0UpdateTableReplicaAutoScalingCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0UpdateTableReplicaAutoScalingCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0UpdateTableReplicaAutoScalingOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0UpdateTableReplicaAutoScalingCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        case "ResourceInUseException":
        case "com.amazonaws.dynamodb#ResourceInUseException":
            throw await deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0UpdateTimeToLiveCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_json1_0UpdateTimeToLiveCommandError(output, context);
    }
    const data = await parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_json1_0UpdateTimeToLiveOutput(data, context);
    const response = {
        $metadata: Aws_json1_0_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_json1_0UpdateTimeToLiveCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.dynamodb#InternalServerError":
            throw await deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context);
        case "InvalidEndpointException":
        case "com.amazonaws.dynamodb#InvalidEndpointException":
            throw await deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context);
        case "LimitExceededException":
        case "com.amazonaws.dynamodb#LimitExceededException":
            throw await deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context);
        case "ResourceInUseException":
        case "com.amazonaws.dynamodb#ResourceInUseException":
            throw await deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.dynamodb#ResourceNotFoundException":
            throw await deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: DynamoDBServiceException,
                errorCode,
            });
    }
};
const deserializeAws_json1_0BackupInUseExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0BackupInUseException(body, context);
    const exception = new BackupInUseException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0BackupNotFoundExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0BackupNotFoundException(body, context);
    const exception = new BackupNotFoundException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0ConditionalCheckFailedExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0ConditionalCheckFailedException(body, context);
    const exception = new ConditionalCheckFailedException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0ContinuousBackupsUnavailableExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0ContinuousBackupsUnavailableException(body, context);
    const exception = new ContinuousBackupsUnavailableException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0DuplicateItemExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0DuplicateItemException(body, context);
    const exception = new DuplicateItemException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0ExportConflictExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0ExportConflictException(body, context);
    const exception = new ExportConflictException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0ExportNotFoundExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0ExportNotFoundException(body, context);
    const exception = new ExportNotFoundException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0GlobalTableAlreadyExistsExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0GlobalTableAlreadyExistsException(body, context);
    const exception = new GlobalTableAlreadyExistsException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0GlobalTableNotFoundExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0GlobalTableNotFoundException(body, context);
    const exception = new GlobalTableNotFoundException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0IdempotentParameterMismatchExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0IdempotentParameterMismatchException(body, context);
    const exception = new IdempotentParameterMismatchException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0ImportConflictExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0ImportConflictException(body, context);
    const exception = new ImportConflictException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0ImportNotFoundExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0ImportNotFoundException(body, context);
    const exception = new ImportNotFoundException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0IndexNotFoundExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0IndexNotFoundException(body, context);
    const exception = new IndexNotFoundException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0InternalServerErrorResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0InternalServerError(body, context);
    const exception = new InternalServerError({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0InvalidEndpointExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0InvalidEndpointException(body, context);
    const exception = new InvalidEndpointException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0InvalidExportTimeExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0InvalidExportTimeException(body, context);
    const exception = new InvalidExportTimeException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0InvalidRestoreTimeExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0InvalidRestoreTimeException(body, context);
    const exception = new InvalidRestoreTimeException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0ItemCollectionSizeLimitExceededExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0ItemCollectionSizeLimitExceededException(body, context);
    const exception = new ItemCollectionSizeLimitExceededException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0LimitExceededExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0LimitExceededException(body, context);
    const exception = new LimitExceededException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0PointInTimeRecoveryUnavailableExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0PointInTimeRecoveryUnavailableException(body, context);
    const exception = new PointInTimeRecoveryUnavailableException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0ProvisionedThroughputExceededException(body, context);
    const exception = new ProvisionedThroughputExceededException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0ReplicaAlreadyExistsExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0ReplicaAlreadyExistsException(body, context);
    const exception = new ReplicaAlreadyExistsException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0ReplicaNotFoundExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0ReplicaNotFoundException(body, context);
    const exception = new ReplicaNotFoundException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0RequestLimitExceededResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0RequestLimitExceeded(body, context);
    const exception = new RequestLimitExceeded({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0ResourceInUseExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0ResourceInUseException(body, context);
    const exception = new ResourceInUseException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0ResourceNotFoundExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0ResourceNotFoundException(body, context);
    const exception = new ResourceNotFoundException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0TableAlreadyExistsExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0TableAlreadyExistsException(body, context);
    const exception = new TableAlreadyExistsException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0TableInUseExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0TableInUseException(body, context);
    const exception = new TableInUseException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0TableNotFoundExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0TableNotFoundException(body, context);
    const exception = new TableNotFoundException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0TransactionCanceledExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0TransactionCanceledException(body, context);
    const exception = new TransactionCanceledException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0TransactionConflictExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0TransactionConflictException(body, context);
    const exception = new TransactionConflictException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_json1_0TransactionInProgressExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_json1_0TransactionInProgressException(body, context);
    const exception = new TransactionInProgressException({
        $metadata: Aws_json1_0_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const serializeAws_json1_0AttributeDefinition = (input, context) => {
    return {
        ...(input.AttributeName != null && { AttributeName: input.AttributeName }),
        ...(input.AttributeType != null && { AttributeType: input.AttributeType }),
    };
};
const serializeAws_json1_0AttributeDefinitions = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0AttributeDefinition(entry, context);
    });
};
const serializeAws_json1_0AttributeNameList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return entry;
    });
};
const serializeAws_json1_0AttributeUpdates = (input, context) => {
    return Object.entries(input).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: serializeAws_json1_0AttributeValueUpdate(value, context),
        };
    }, {});
};
const serializeAws_json1_0AttributeValue = (input, context) => {
    return AttributeValue.visit(input, {
        B: (value) => ({ B: context.base64Encoder(value) }),
        BOOL: (value) => ({ BOOL: value }),
        BS: (value) => ({ BS: serializeAws_json1_0BinarySetAttributeValue(value, context) }),
        L: (value) => ({ L: serializeAws_json1_0ListAttributeValue(value, context) }),
        M: (value) => ({ M: serializeAws_json1_0MapAttributeValue(value, context) }),
        N: (value) => ({ N: value }),
        NS: (value) => ({ NS: serializeAws_json1_0NumberSetAttributeValue(value, context) }),
        NULL: (value) => ({ NULL: value }),
        S: (value) => ({ S: value }),
        SS: (value) => ({ SS: serializeAws_json1_0StringSetAttributeValue(value, context) }),
        _: (name, value) => ({ name: value }),
    });
};
const serializeAws_json1_0AttributeValueList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0AttributeValue(entry, context);
    });
};
const serializeAws_json1_0AttributeValueUpdate = (input, context) => {
    return {
        ...(input.Action != null && { Action: input.Action }),
        ...(input.Value != null && { Value: serializeAws_json1_0AttributeValue(input.Value, context) }),
    };
};
const serializeAws_json1_0AutoScalingPolicyUpdate = (input, context) => {
    return {
        ...(input.PolicyName != null && { PolicyName: input.PolicyName }),
        ...(input.TargetTrackingScalingPolicyConfiguration != null && {
            TargetTrackingScalingPolicyConfiguration: serializeAws_json1_0AutoScalingTargetTrackingScalingPolicyConfigurationUpdate(input.TargetTrackingScalingPolicyConfiguration, context),
        }),
    };
};
const serializeAws_json1_0AutoScalingSettingsUpdate = (input, context) => {
    return {
        ...(input.AutoScalingDisabled != null && { AutoScalingDisabled: input.AutoScalingDisabled }),
        ...(input.AutoScalingRoleArn != null && { AutoScalingRoleArn: input.AutoScalingRoleArn }),
        ...(input.MaximumUnits != null && { MaximumUnits: input.MaximumUnits }),
        ...(input.MinimumUnits != null && { MinimumUnits: input.MinimumUnits }),
        ...(input.ScalingPolicyUpdate != null && {
            ScalingPolicyUpdate: serializeAws_json1_0AutoScalingPolicyUpdate(input.ScalingPolicyUpdate, context),
        }),
    };
};
const serializeAws_json1_0AutoScalingTargetTrackingScalingPolicyConfigurationUpdate = (input, context) => {
    return {
        ...(input.DisableScaleIn != null && { DisableScaleIn: input.DisableScaleIn }),
        ...(input.ScaleInCooldown != null && { ScaleInCooldown: input.ScaleInCooldown }),
        ...(input.ScaleOutCooldown != null && { ScaleOutCooldown: input.ScaleOutCooldown }),
        ...(input.TargetValue != null && { TargetValue: serializeFloat(input.TargetValue) }),
    };
};
const serializeAws_json1_0BatchExecuteStatementInput = (input, context) => {
    return {
        ...(input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity }),
        ...(input.Statements != null && { Statements: serializeAws_json1_0PartiQLBatchRequest(input.Statements, context) }),
    };
};
const serializeAws_json1_0BatchGetItemInput = (input, context) => {
    return {
        ...(input.RequestItems != null && {
            RequestItems: serializeAws_json1_0BatchGetRequestMap(input.RequestItems, context),
        }),
        ...(input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity }),
    };
};
const serializeAws_json1_0BatchGetRequestMap = (input, context) => {
    return Object.entries(input).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: serializeAws_json1_0KeysAndAttributes(value, context),
        };
    }, {});
};
const serializeAws_json1_0BatchStatementRequest = (input, context) => {
    return {
        ...(input.ConsistentRead != null && { ConsistentRead: input.ConsistentRead }),
        ...(input.Parameters != null && {
            Parameters: serializeAws_json1_0PreparedStatementParameters(input.Parameters, context),
        }),
        ...(input.Statement != null && { Statement: input.Statement }),
    };
};
const serializeAws_json1_0BatchWriteItemInput = (input, context) => {
    return {
        ...(input.RequestItems != null && {
            RequestItems: serializeAws_json1_0BatchWriteItemRequestMap(input.RequestItems, context),
        }),
        ...(input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity }),
        ...(input.ReturnItemCollectionMetrics != null && {
            ReturnItemCollectionMetrics: input.ReturnItemCollectionMetrics,
        }),
    };
};
const serializeAws_json1_0BatchWriteItemRequestMap = (input, context) => {
    return Object.entries(input).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: serializeAws_json1_0WriteRequests(value, context),
        };
    }, {});
};
const serializeAws_json1_0BinarySetAttributeValue = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return context.base64Encoder(entry);
    });
};
const serializeAws_json1_0Condition = (input, context) => {
    return {
        ...(input.AttributeValueList != null && {
            AttributeValueList: serializeAws_json1_0AttributeValueList(input.AttributeValueList, context),
        }),
        ...(input.ComparisonOperator != null && { ComparisonOperator: input.ComparisonOperator }),
    };
};
const serializeAws_json1_0ConditionCheck = (input, context) => {
    return {
        ...(input.ConditionExpression != null && { ConditionExpression: input.ConditionExpression }),
        ...(input.ExpressionAttributeNames != null && {
            ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
        }),
        ...(input.ExpressionAttributeValues != null && {
            ExpressionAttributeValues: serializeAws_json1_0ExpressionAttributeValueMap(input.ExpressionAttributeValues, context),
        }),
        ...(input.Key != null && { Key: serializeAws_json1_0Key(input.Key, context) }),
        ...(input.ReturnValuesOnConditionCheckFailure != null && {
            ReturnValuesOnConditionCheckFailure: input.ReturnValuesOnConditionCheckFailure,
        }),
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0CreateBackupInput = (input, context) => {
    return {
        ...(input.BackupName != null && { BackupName: input.BackupName }),
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0CreateGlobalSecondaryIndexAction = (input, context) => {
    return {
        ...(input.IndexName != null && { IndexName: input.IndexName }),
        ...(input.KeySchema != null && { KeySchema: serializeAws_json1_0KeySchema(input.KeySchema, context) }),
        ...(input.Projection != null && { Projection: serializeAws_json1_0Projection(input.Projection, context) }),
        ...(input.ProvisionedThroughput != null && {
            ProvisionedThroughput: serializeAws_json1_0ProvisionedThroughput(input.ProvisionedThroughput, context),
        }),
    };
};
const serializeAws_json1_0CreateGlobalTableInput = (input, context) => {
    return {
        ...(input.GlobalTableName != null && { GlobalTableName: input.GlobalTableName }),
        ...(input.ReplicationGroup != null && {
            ReplicationGroup: serializeAws_json1_0ReplicaList(input.ReplicationGroup, context),
        }),
    };
};
const serializeAws_json1_0CreateReplicaAction = (input, context) => {
    return {
        ...(input.RegionName != null && { RegionName: input.RegionName }),
    };
};
const serializeAws_json1_0CreateReplicationGroupMemberAction = (input, context) => {
    return {
        ...(input.GlobalSecondaryIndexes != null && {
            GlobalSecondaryIndexes: serializeAws_json1_0ReplicaGlobalSecondaryIndexList(input.GlobalSecondaryIndexes, context),
        }),
        ...(input.KMSMasterKeyId != null && { KMSMasterKeyId: input.KMSMasterKeyId }),
        ...(input.ProvisionedThroughputOverride != null && {
            ProvisionedThroughputOverride: serializeAws_json1_0ProvisionedThroughputOverride(input.ProvisionedThroughputOverride, context),
        }),
        ...(input.RegionName != null && { RegionName: input.RegionName }),
        ...(input.TableClassOverride != null && { TableClassOverride: input.TableClassOverride }),
    };
};
const serializeAws_json1_0CreateTableInput = (input, context) => {
    return {
        ...(input.AttributeDefinitions != null && {
            AttributeDefinitions: serializeAws_json1_0AttributeDefinitions(input.AttributeDefinitions, context),
        }),
        ...(input.BillingMode != null && { BillingMode: input.BillingMode }),
        ...(input.GlobalSecondaryIndexes != null && {
            GlobalSecondaryIndexes: serializeAws_json1_0GlobalSecondaryIndexList(input.GlobalSecondaryIndexes, context),
        }),
        ...(input.KeySchema != null && { KeySchema: serializeAws_json1_0KeySchema(input.KeySchema, context) }),
        ...(input.LocalSecondaryIndexes != null && {
            LocalSecondaryIndexes: serializeAws_json1_0LocalSecondaryIndexList(input.LocalSecondaryIndexes, context),
        }),
        ...(input.ProvisionedThroughput != null && {
            ProvisionedThroughput: serializeAws_json1_0ProvisionedThroughput(input.ProvisionedThroughput, context),
        }),
        ...(input.SSESpecification != null && {
            SSESpecification: serializeAws_json1_0SSESpecification(input.SSESpecification, context),
        }),
        ...(input.StreamSpecification != null && {
            StreamSpecification: serializeAws_json1_0StreamSpecification(input.StreamSpecification, context),
        }),
        ...(input.TableClass != null && { TableClass: input.TableClass }),
        ...(input.TableName != null && { TableName: input.TableName }),
        ...(input.Tags != null && { Tags: serializeAws_json1_0TagList(input.Tags, context) }),
    };
};
const serializeAws_json1_0CsvHeaderList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return entry;
    });
};
const serializeAws_json1_0CsvOptions = (input, context) => {
    return {
        ...(input.Delimiter != null && { Delimiter: input.Delimiter }),
        ...(input.HeaderList != null && { HeaderList: serializeAws_json1_0CsvHeaderList(input.HeaderList, context) }),
    };
};
const serializeAws_json1_0Delete = (input, context) => {
    return {
        ...(input.ConditionExpression != null && { ConditionExpression: input.ConditionExpression }),
        ...(input.ExpressionAttributeNames != null && {
            ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
        }),
        ...(input.ExpressionAttributeValues != null && {
            ExpressionAttributeValues: serializeAws_json1_0ExpressionAttributeValueMap(input.ExpressionAttributeValues, context),
        }),
        ...(input.Key != null && { Key: serializeAws_json1_0Key(input.Key, context) }),
        ...(input.ReturnValuesOnConditionCheckFailure != null && {
            ReturnValuesOnConditionCheckFailure: input.ReturnValuesOnConditionCheckFailure,
        }),
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0DeleteBackupInput = (input, context) => {
    return {
        ...(input.BackupArn != null && { BackupArn: input.BackupArn }),
    };
};
const serializeAws_json1_0DeleteGlobalSecondaryIndexAction = (input, context) => {
    return {
        ...(input.IndexName != null && { IndexName: input.IndexName }),
    };
};
const serializeAws_json1_0DeleteItemInput = (input, context) => {
    return {
        ...(input.ConditionExpression != null && { ConditionExpression: input.ConditionExpression }),
        ...(input.ConditionalOperator != null && { ConditionalOperator: input.ConditionalOperator }),
        ...(input.Expected != null && { Expected: serializeAws_json1_0ExpectedAttributeMap(input.Expected, context) }),
        ...(input.ExpressionAttributeNames != null && {
            ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
        }),
        ...(input.ExpressionAttributeValues != null && {
            ExpressionAttributeValues: serializeAws_json1_0ExpressionAttributeValueMap(input.ExpressionAttributeValues, context),
        }),
        ...(input.Key != null && { Key: serializeAws_json1_0Key(input.Key, context) }),
        ...(input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity }),
        ...(input.ReturnItemCollectionMetrics != null && {
            ReturnItemCollectionMetrics: input.ReturnItemCollectionMetrics,
        }),
        ...(input.ReturnValues != null && { ReturnValues: input.ReturnValues }),
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0DeleteReplicaAction = (input, context) => {
    return {
        ...(input.RegionName != null && { RegionName: input.RegionName }),
    };
};
const serializeAws_json1_0DeleteReplicationGroupMemberAction = (input, context) => {
    return {
        ...(input.RegionName != null && { RegionName: input.RegionName }),
    };
};
const serializeAws_json1_0DeleteRequest = (input, context) => {
    return {
        ...(input.Key != null && { Key: serializeAws_json1_0Key(input.Key, context) }),
    };
};
const serializeAws_json1_0DeleteTableInput = (input, context) => {
    return {
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0DescribeBackupInput = (input, context) => {
    return {
        ...(input.BackupArn != null && { BackupArn: input.BackupArn }),
    };
};
const serializeAws_json1_0DescribeContinuousBackupsInput = (input, context) => {
    return {
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0DescribeContributorInsightsInput = (input, context) => {
    return {
        ...(input.IndexName != null && { IndexName: input.IndexName }),
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0DescribeEndpointsRequest = (input, context) => {
    return {};
};
const serializeAws_json1_0DescribeExportInput = (input, context) => {
    return {
        ...(input.ExportArn != null && { ExportArn: input.ExportArn }),
    };
};
const serializeAws_json1_0DescribeGlobalTableInput = (input, context) => {
    return {
        ...(input.GlobalTableName != null && { GlobalTableName: input.GlobalTableName }),
    };
};
const serializeAws_json1_0DescribeGlobalTableSettingsInput = (input, context) => {
    return {
        ...(input.GlobalTableName != null && { GlobalTableName: input.GlobalTableName }),
    };
};
const serializeAws_json1_0DescribeImportInput = (input, context) => {
    return {
        ...(input.ImportArn != null && { ImportArn: input.ImportArn }),
    };
};
const serializeAws_json1_0DescribeKinesisStreamingDestinationInput = (input, context) => {
    return {
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0DescribeLimitsInput = (input, context) => {
    return {};
};
const serializeAws_json1_0DescribeTableInput = (input, context) => {
    return {
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0DescribeTableReplicaAutoScalingInput = (input, context) => {
    return {
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0DescribeTimeToLiveInput = (input, context) => {
    return {
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0ExecuteStatementInput = (input, context) => {
    return {
        ...(input.ConsistentRead != null && { ConsistentRead: input.ConsistentRead }),
        ...(input.Limit != null && { Limit: input.Limit }),
        ...(input.NextToken != null && { NextToken: input.NextToken }),
        ...(input.Parameters != null && {
            Parameters: serializeAws_json1_0PreparedStatementParameters(input.Parameters, context),
        }),
        ...(input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity }),
        ...(input.Statement != null && { Statement: input.Statement }),
    };
};
const serializeAws_json1_0ExecuteTransactionInput = (input, context) => {
    return {
        ClientRequestToken: input.ClientRequestToken ?? esm_node_v4(),
        ...(input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity }),
        ...(input.TransactStatements != null && {
            TransactStatements: serializeAws_json1_0ParameterizedStatements(input.TransactStatements, context),
        }),
    };
};
const serializeAws_json1_0ExpectedAttributeMap = (input, context) => {
    return Object.entries(input).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: serializeAws_json1_0ExpectedAttributeValue(value, context),
        };
    }, {});
};
const serializeAws_json1_0ExpectedAttributeValue = (input, context) => {
    return {
        ...(input.AttributeValueList != null && {
            AttributeValueList: serializeAws_json1_0AttributeValueList(input.AttributeValueList, context),
        }),
        ...(input.ComparisonOperator != null && { ComparisonOperator: input.ComparisonOperator }),
        ...(input.Exists != null && { Exists: input.Exists }),
        ...(input.Value != null && { Value: serializeAws_json1_0AttributeValue(input.Value, context) }),
    };
};
const serializeAws_json1_0ExportTableToPointInTimeInput = (input, context) => {
    return {
        ClientToken: input.ClientToken ?? esm_node_v4(),
        ...(input.ExportFormat != null && { ExportFormat: input.ExportFormat }),
        ...(input.ExportTime != null && { ExportTime: Math.round(input.ExportTime.getTime() / 1000) }),
        ...(input.S3Bucket != null && { S3Bucket: input.S3Bucket }),
        ...(input.S3BucketOwner != null && { S3BucketOwner: input.S3BucketOwner }),
        ...(input.S3Prefix != null && { S3Prefix: input.S3Prefix }),
        ...(input.S3SseAlgorithm != null && { S3SseAlgorithm: input.S3SseAlgorithm }),
        ...(input.S3SseKmsKeyId != null && { S3SseKmsKeyId: input.S3SseKmsKeyId }),
        ...(input.TableArn != null && { TableArn: input.TableArn }),
    };
};
const serializeAws_json1_0ExpressionAttributeNameMap = (input, context) => {
    return Object.entries(input).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: value,
        };
    }, {});
};
const serializeAws_json1_0ExpressionAttributeValueMap = (input, context) => {
    return Object.entries(input).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: serializeAws_json1_0AttributeValue(value, context),
        };
    }, {});
};
const serializeAws_json1_0FilterConditionMap = (input, context) => {
    return Object.entries(input).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: serializeAws_json1_0Condition(value, context),
        };
    }, {});
};
const serializeAws_json1_0Get = (input, context) => {
    return {
        ...(input.ExpressionAttributeNames != null && {
            ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
        }),
        ...(input.Key != null && { Key: serializeAws_json1_0Key(input.Key, context) }),
        ...(input.ProjectionExpression != null && { ProjectionExpression: input.ProjectionExpression }),
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0GetItemInput = (input, context) => {
    return {
        ...(input.AttributesToGet != null && {
            AttributesToGet: serializeAws_json1_0AttributeNameList(input.AttributesToGet, context),
        }),
        ...(input.ConsistentRead != null && { ConsistentRead: input.ConsistentRead }),
        ...(input.ExpressionAttributeNames != null && {
            ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
        }),
        ...(input.Key != null && { Key: serializeAws_json1_0Key(input.Key, context) }),
        ...(input.ProjectionExpression != null && { ProjectionExpression: input.ProjectionExpression }),
        ...(input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity }),
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0GlobalSecondaryIndex = (input, context) => {
    return {
        ...(input.IndexName != null && { IndexName: input.IndexName }),
        ...(input.KeySchema != null && { KeySchema: serializeAws_json1_0KeySchema(input.KeySchema, context) }),
        ...(input.Projection != null && { Projection: serializeAws_json1_0Projection(input.Projection, context) }),
        ...(input.ProvisionedThroughput != null && {
            ProvisionedThroughput: serializeAws_json1_0ProvisionedThroughput(input.ProvisionedThroughput, context),
        }),
    };
};
const serializeAws_json1_0GlobalSecondaryIndexAutoScalingUpdate = (input, context) => {
    return {
        ...(input.IndexName != null && { IndexName: input.IndexName }),
        ...(input.ProvisionedWriteCapacityAutoScalingUpdate != null && {
            ProvisionedWriteCapacityAutoScalingUpdate: serializeAws_json1_0AutoScalingSettingsUpdate(input.ProvisionedWriteCapacityAutoScalingUpdate, context),
        }),
    };
};
const serializeAws_json1_0GlobalSecondaryIndexAutoScalingUpdateList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0GlobalSecondaryIndexAutoScalingUpdate(entry, context);
    });
};
const serializeAws_json1_0GlobalSecondaryIndexList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0GlobalSecondaryIndex(entry, context);
    });
};
const serializeAws_json1_0GlobalSecondaryIndexUpdate = (input, context) => {
    return {
        ...(input.Create != null && {
            Create: serializeAws_json1_0CreateGlobalSecondaryIndexAction(input.Create, context),
        }),
        ...(input.Delete != null && {
            Delete: serializeAws_json1_0DeleteGlobalSecondaryIndexAction(input.Delete, context),
        }),
        ...(input.Update != null && {
            Update: serializeAws_json1_0UpdateGlobalSecondaryIndexAction(input.Update, context),
        }),
    };
};
const serializeAws_json1_0GlobalSecondaryIndexUpdateList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0GlobalSecondaryIndexUpdate(entry, context);
    });
};
const serializeAws_json1_0GlobalTableGlobalSecondaryIndexSettingsUpdate = (input, context) => {
    return {
        ...(input.IndexName != null && { IndexName: input.IndexName }),
        ...(input.ProvisionedWriteCapacityAutoScalingSettingsUpdate != null && {
            ProvisionedWriteCapacityAutoScalingSettingsUpdate: serializeAws_json1_0AutoScalingSettingsUpdate(input.ProvisionedWriteCapacityAutoScalingSettingsUpdate, context),
        }),
        ...(input.ProvisionedWriteCapacityUnits != null && {
            ProvisionedWriteCapacityUnits: input.ProvisionedWriteCapacityUnits,
        }),
    };
};
const serializeAws_json1_0GlobalTableGlobalSecondaryIndexSettingsUpdateList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0GlobalTableGlobalSecondaryIndexSettingsUpdate(entry, context);
    });
};
const serializeAws_json1_0ImportTableInput = (input, context) => {
    return {
        ClientToken: input.ClientToken ?? esm_node_v4(),
        ...(input.InputCompressionType != null && { InputCompressionType: input.InputCompressionType }),
        ...(input.InputFormat != null && { InputFormat: input.InputFormat }),
        ...(input.InputFormatOptions != null && {
            InputFormatOptions: serializeAws_json1_0InputFormatOptions(input.InputFormatOptions, context),
        }),
        ...(input.S3BucketSource != null && {
            S3BucketSource: serializeAws_json1_0S3BucketSource(input.S3BucketSource, context),
        }),
        ...(input.TableCreationParameters != null && {
            TableCreationParameters: serializeAws_json1_0TableCreationParameters(input.TableCreationParameters, context),
        }),
    };
};
const serializeAws_json1_0InputFormatOptions = (input, context) => {
    return {
        ...(input.Csv != null && { Csv: serializeAws_json1_0CsvOptions(input.Csv, context) }),
    };
};
const serializeAws_json1_0Key = (input, context) => {
    return Object.entries(input).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: serializeAws_json1_0AttributeValue(value, context),
        };
    }, {});
};
const serializeAws_json1_0KeyConditions = (input, context) => {
    return Object.entries(input).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: serializeAws_json1_0Condition(value, context),
        };
    }, {});
};
const serializeAws_json1_0KeyList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0Key(entry, context);
    });
};
const serializeAws_json1_0KeysAndAttributes = (input, context) => {
    return {
        ...(input.AttributesToGet != null && {
            AttributesToGet: serializeAws_json1_0AttributeNameList(input.AttributesToGet, context),
        }),
        ...(input.ConsistentRead != null && { ConsistentRead: input.ConsistentRead }),
        ...(input.ExpressionAttributeNames != null && {
            ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
        }),
        ...(input.Keys != null && { Keys: serializeAws_json1_0KeyList(input.Keys, context) }),
        ...(input.ProjectionExpression != null && { ProjectionExpression: input.ProjectionExpression }),
    };
};
const serializeAws_json1_0KeySchema = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0KeySchemaElement(entry, context);
    });
};
const serializeAws_json1_0KeySchemaElement = (input, context) => {
    return {
        ...(input.AttributeName != null && { AttributeName: input.AttributeName }),
        ...(input.KeyType != null && { KeyType: input.KeyType }),
    };
};
const serializeAws_json1_0KinesisStreamingDestinationInput = (input, context) => {
    return {
        ...(input.StreamArn != null && { StreamArn: input.StreamArn }),
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0ListAttributeValue = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0AttributeValue(entry, context);
    });
};
const serializeAws_json1_0ListBackupsInput = (input, context) => {
    return {
        ...(input.BackupType != null && { BackupType: input.BackupType }),
        ...(input.ExclusiveStartBackupArn != null && { ExclusiveStartBackupArn: input.ExclusiveStartBackupArn }),
        ...(input.Limit != null && { Limit: input.Limit }),
        ...(input.TableName != null && { TableName: input.TableName }),
        ...(input.TimeRangeLowerBound != null && {
            TimeRangeLowerBound: Math.round(input.TimeRangeLowerBound.getTime() / 1000),
        }),
        ...(input.TimeRangeUpperBound != null && {
            TimeRangeUpperBound: Math.round(input.TimeRangeUpperBound.getTime() / 1000),
        }),
    };
};
const serializeAws_json1_0ListContributorInsightsInput = (input, context) => {
    return {
        ...(input.MaxResults != null && { MaxResults: input.MaxResults }),
        ...(input.NextToken != null && { NextToken: input.NextToken }),
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0ListExportsInput = (input, context) => {
    return {
        ...(input.MaxResults != null && { MaxResults: input.MaxResults }),
        ...(input.NextToken != null && { NextToken: input.NextToken }),
        ...(input.TableArn != null && { TableArn: input.TableArn }),
    };
};
const serializeAws_json1_0ListGlobalTablesInput = (input, context) => {
    return {
        ...(input.ExclusiveStartGlobalTableName != null && {
            ExclusiveStartGlobalTableName: input.ExclusiveStartGlobalTableName,
        }),
        ...(input.Limit != null && { Limit: input.Limit }),
        ...(input.RegionName != null && { RegionName: input.RegionName }),
    };
};
const serializeAws_json1_0ListImportsInput = (input, context) => {
    return {
        ...(input.NextToken != null && { NextToken: input.NextToken }),
        ...(input.PageSize != null && { PageSize: input.PageSize }),
        ...(input.TableArn != null && { TableArn: input.TableArn }),
    };
};
const serializeAws_json1_0ListTablesInput = (input, context) => {
    return {
        ...(input.ExclusiveStartTableName != null && { ExclusiveStartTableName: input.ExclusiveStartTableName }),
        ...(input.Limit != null && { Limit: input.Limit }),
    };
};
const serializeAws_json1_0ListTagsOfResourceInput = (input, context) => {
    return {
        ...(input.NextToken != null && { NextToken: input.NextToken }),
        ...(input.ResourceArn != null && { ResourceArn: input.ResourceArn }),
    };
};
const serializeAws_json1_0LocalSecondaryIndex = (input, context) => {
    return {
        ...(input.IndexName != null && { IndexName: input.IndexName }),
        ...(input.KeySchema != null && { KeySchema: serializeAws_json1_0KeySchema(input.KeySchema, context) }),
        ...(input.Projection != null && { Projection: serializeAws_json1_0Projection(input.Projection, context) }),
    };
};
const serializeAws_json1_0LocalSecondaryIndexList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0LocalSecondaryIndex(entry, context);
    });
};
const serializeAws_json1_0MapAttributeValue = (input, context) => {
    return Object.entries(input).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: serializeAws_json1_0AttributeValue(value, context),
        };
    }, {});
};
const serializeAws_json1_0NonKeyAttributeNameList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return entry;
    });
};
const serializeAws_json1_0NumberSetAttributeValue = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return entry;
    });
};
const serializeAws_json1_0ParameterizedStatement = (input, context) => {
    return {
        ...(input.Parameters != null && {
            Parameters: serializeAws_json1_0PreparedStatementParameters(input.Parameters, context),
        }),
        ...(input.Statement != null && { Statement: input.Statement }),
    };
};
const serializeAws_json1_0ParameterizedStatements = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0ParameterizedStatement(entry, context);
    });
};
const serializeAws_json1_0PartiQLBatchRequest = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0BatchStatementRequest(entry, context);
    });
};
const serializeAws_json1_0PointInTimeRecoverySpecification = (input, context) => {
    return {
        ...(input.PointInTimeRecoveryEnabled != null && { PointInTimeRecoveryEnabled: input.PointInTimeRecoveryEnabled }),
    };
};
const serializeAws_json1_0PreparedStatementParameters = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0AttributeValue(entry, context);
    });
};
const serializeAws_json1_0Projection = (input, context) => {
    return {
        ...(input.NonKeyAttributes != null && {
            NonKeyAttributes: serializeAws_json1_0NonKeyAttributeNameList(input.NonKeyAttributes, context),
        }),
        ...(input.ProjectionType != null && { ProjectionType: input.ProjectionType }),
    };
};
const serializeAws_json1_0ProvisionedThroughput = (input, context) => {
    return {
        ...(input.ReadCapacityUnits != null && { ReadCapacityUnits: input.ReadCapacityUnits }),
        ...(input.WriteCapacityUnits != null && { WriteCapacityUnits: input.WriteCapacityUnits }),
    };
};
const serializeAws_json1_0ProvisionedThroughputOverride = (input, context) => {
    return {
        ...(input.ReadCapacityUnits != null && { ReadCapacityUnits: input.ReadCapacityUnits }),
    };
};
const serializeAws_json1_0Put = (input, context) => {
    return {
        ...(input.ConditionExpression != null && { ConditionExpression: input.ConditionExpression }),
        ...(input.ExpressionAttributeNames != null && {
            ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
        }),
        ...(input.ExpressionAttributeValues != null && {
            ExpressionAttributeValues: serializeAws_json1_0ExpressionAttributeValueMap(input.ExpressionAttributeValues, context),
        }),
        ...(input.Item != null && { Item: serializeAws_json1_0PutItemInputAttributeMap(input.Item, context) }),
        ...(input.ReturnValuesOnConditionCheckFailure != null && {
            ReturnValuesOnConditionCheckFailure: input.ReturnValuesOnConditionCheckFailure,
        }),
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0PutItemInput = (input, context) => {
    return {
        ...(input.ConditionExpression != null && { ConditionExpression: input.ConditionExpression }),
        ...(input.ConditionalOperator != null && { ConditionalOperator: input.ConditionalOperator }),
        ...(input.Expected != null && { Expected: serializeAws_json1_0ExpectedAttributeMap(input.Expected, context) }),
        ...(input.ExpressionAttributeNames != null && {
            ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
        }),
        ...(input.ExpressionAttributeValues != null && {
            ExpressionAttributeValues: serializeAws_json1_0ExpressionAttributeValueMap(input.ExpressionAttributeValues, context),
        }),
        ...(input.Item != null && { Item: serializeAws_json1_0PutItemInputAttributeMap(input.Item, context) }),
        ...(input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity }),
        ...(input.ReturnItemCollectionMetrics != null && {
            ReturnItemCollectionMetrics: input.ReturnItemCollectionMetrics,
        }),
        ...(input.ReturnValues != null && { ReturnValues: input.ReturnValues }),
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0PutItemInputAttributeMap = (input, context) => {
    return Object.entries(input).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: serializeAws_json1_0AttributeValue(value, context),
        };
    }, {});
};
const serializeAws_json1_0PutRequest = (input, context) => {
    return {
        ...(input.Item != null && { Item: serializeAws_json1_0PutItemInputAttributeMap(input.Item, context) }),
    };
};
const serializeAws_json1_0QueryInput = (input, context) => {
    return {
        ...(input.AttributesToGet != null && {
            AttributesToGet: serializeAws_json1_0AttributeNameList(input.AttributesToGet, context),
        }),
        ...(input.ConditionalOperator != null && { ConditionalOperator: input.ConditionalOperator }),
        ...(input.ConsistentRead != null && { ConsistentRead: input.ConsistentRead }),
        ...(input.ExclusiveStartKey != null && {
            ExclusiveStartKey: serializeAws_json1_0Key(input.ExclusiveStartKey, context),
        }),
        ...(input.ExpressionAttributeNames != null && {
            ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
        }),
        ...(input.ExpressionAttributeValues != null && {
            ExpressionAttributeValues: serializeAws_json1_0ExpressionAttributeValueMap(input.ExpressionAttributeValues, context),
        }),
        ...(input.FilterExpression != null && { FilterExpression: input.FilterExpression }),
        ...(input.IndexName != null && { IndexName: input.IndexName }),
        ...(input.KeyConditionExpression != null && { KeyConditionExpression: input.KeyConditionExpression }),
        ...(input.KeyConditions != null && {
            KeyConditions: serializeAws_json1_0KeyConditions(input.KeyConditions, context),
        }),
        ...(input.Limit != null && { Limit: input.Limit }),
        ...(input.ProjectionExpression != null && { ProjectionExpression: input.ProjectionExpression }),
        ...(input.QueryFilter != null && {
            QueryFilter: serializeAws_json1_0FilterConditionMap(input.QueryFilter, context),
        }),
        ...(input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity }),
        ...(input.ScanIndexForward != null && { ScanIndexForward: input.ScanIndexForward }),
        ...(input.Select != null && { Select: input.Select }),
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0Replica = (input, context) => {
    return {
        ...(input.RegionName != null && { RegionName: input.RegionName }),
    };
};
const serializeAws_json1_0ReplicaAutoScalingUpdate = (input, context) => {
    return {
        ...(input.RegionName != null && { RegionName: input.RegionName }),
        ...(input.ReplicaGlobalSecondaryIndexUpdates != null && {
            ReplicaGlobalSecondaryIndexUpdates: serializeAws_json1_0ReplicaGlobalSecondaryIndexAutoScalingUpdateList(input.ReplicaGlobalSecondaryIndexUpdates, context),
        }),
        ...(input.ReplicaProvisionedReadCapacityAutoScalingUpdate != null && {
            ReplicaProvisionedReadCapacityAutoScalingUpdate: serializeAws_json1_0AutoScalingSettingsUpdate(input.ReplicaProvisionedReadCapacityAutoScalingUpdate, context),
        }),
    };
};
const serializeAws_json1_0ReplicaAutoScalingUpdateList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0ReplicaAutoScalingUpdate(entry, context);
    });
};
const serializeAws_json1_0ReplicaGlobalSecondaryIndex = (input, context) => {
    return {
        ...(input.IndexName != null && { IndexName: input.IndexName }),
        ...(input.ProvisionedThroughputOverride != null && {
            ProvisionedThroughputOverride: serializeAws_json1_0ProvisionedThroughputOverride(input.ProvisionedThroughputOverride, context),
        }),
    };
};
const serializeAws_json1_0ReplicaGlobalSecondaryIndexAutoScalingUpdate = (input, context) => {
    return {
        ...(input.IndexName != null && { IndexName: input.IndexName }),
        ...(input.ProvisionedReadCapacityAutoScalingUpdate != null && {
            ProvisionedReadCapacityAutoScalingUpdate: serializeAws_json1_0AutoScalingSettingsUpdate(input.ProvisionedReadCapacityAutoScalingUpdate, context),
        }),
    };
};
const serializeAws_json1_0ReplicaGlobalSecondaryIndexAutoScalingUpdateList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0ReplicaGlobalSecondaryIndexAutoScalingUpdate(entry, context);
    });
};
const serializeAws_json1_0ReplicaGlobalSecondaryIndexList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0ReplicaGlobalSecondaryIndex(entry, context);
    });
};
const serializeAws_json1_0ReplicaGlobalSecondaryIndexSettingsUpdate = (input, context) => {
    return {
        ...(input.IndexName != null && { IndexName: input.IndexName }),
        ...(input.ProvisionedReadCapacityAutoScalingSettingsUpdate != null && {
            ProvisionedReadCapacityAutoScalingSettingsUpdate: serializeAws_json1_0AutoScalingSettingsUpdate(input.ProvisionedReadCapacityAutoScalingSettingsUpdate, context),
        }),
        ...(input.ProvisionedReadCapacityUnits != null && {
            ProvisionedReadCapacityUnits: input.ProvisionedReadCapacityUnits,
        }),
    };
};
const serializeAws_json1_0ReplicaGlobalSecondaryIndexSettingsUpdateList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0ReplicaGlobalSecondaryIndexSettingsUpdate(entry, context);
    });
};
const serializeAws_json1_0ReplicaList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0Replica(entry, context);
    });
};
const serializeAws_json1_0ReplicaSettingsUpdate = (input, context) => {
    return {
        ...(input.RegionName != null && { RegionName: input.RegionName }),
        ...(input.ReplicaGlobalSecondaryIndexSettingsUpdate != null && {
            ReplicaGlobalSecondaryIndexSettingsUpdate: serializeAws_json1_0ReplicaGlobalSecondaryIndexSettingsUpdateList(input.ReplicaGlobalSecondaryIndexSettingsUpdate, context),
        }),
        ...(input.ReplicaProvisionedReadCapacityAutoScalingSettingsUpdate != null && {
            ReplicaProvisionedReadCapacityAutoScalingSettingsUpdate: serializeAws_json1_0AutoScalingSettingsUpdate(input.ReplicaProvisionedReadCapacityAutoScalingSettingsUpdate, context),
        }),
        ...(input.ReplicaProvisionedReadCapacityUnits != null && {
            ReplicaProvisionedReadCapacityUnits: input.ReplicaProvisionedReadCapacityUnits,
        }),
        ...(input.ReplicaTableClass != null && { ReplicaTableClass: input.ReplicaTableClass }),
    };
};
const serializeAws_json1_0ReplicaSettingsUpdateList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0ReplicaSettingsUpdate(entry, context);
    });
};
const serializeAws_json1_0ReplicationGroupUpdate = (input, context) => {
    return {
        ...(input.Create != null && {
            Create: serializeAws_json1_0CreateReplicationGroupMemberAction(input.Create, context),
        }),
        ...(input.Delete != null && {
            Delete: serializeAws_json1_0DeleteReplicationGroupMemberAction(input.Delete, context),
        }),
        ...(input.Update != null && {
            Update: serializeAws_json1_0UpdateReplicationGroupMemberAction(input.Update, context),
        }),
    };
};
const serializeAws_json1_0ReplicationGroupUpdateList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0ReplicationGroupUpdate(entry, context);
    });
};
const serializeAws_json1_0ReplicaUpdate = (input, context) => {
    return {
        ...(input.Create != null && { Create: serializeAws_json1_0CreateReplicaAction(input.Create, context) }),
        ...(input.Delete != null && { Delete: serializeAws_json1_0DeleteReplicaAction(input.Delete, context) }),
    };
};
const serializeAws_json1_0ReplicaUpdateList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0ReplicaUpdate(entry, context);
    });
};
const serializeAws_json1_0RestoreTableFromBackupInput = (input, context) => {
    return {
        ...(input.BackupArn != null && { BackupArn: input.BackupArn }),
        ...(input.BillingModeOverride != null && { BillingModeOverride: input.BillingModeOverride }),
        ...(input.GlobalSecondaryIndexOverride != null && {
            GlobalSecondaryIndexOverride: serializeAws_json1_0GlobalSecondaryIndexList(input.GlobalSecondaryIndexOverride, context),
        }),
        ...(input.LocalSecondaryIndexOverride != null && {
            LocalSecondaryIndexOverride: serializeAws_json1_0LocalSecondaryIndexList(input.LocalSecondaryIndexOverride, context),
        }),
        ...(input.ProvisionedThroughputOverride != null && {
            ProvisionedThroughputOverride: serializeAws_json1_0ProvisionedThroughput(input.ProvisionedThroughputOverride, context),
        }),
        ...(input.SSESpecificationOverride != null && {
            SSESpecificationOverride: serializeAws_json1_0SSESpecification(input.SSESpecificationOverride, context),
        }),
        ...(input.TargetTableName != null && { TargetTableName: input.TargetTableName }),
    };
};
const serializeAws_json1_0RestoreTableToPointInTimeInput = (input, context) => {
    return {
        ...(input.BillingModeOverride != null && { BillingModeOverride: input.BillingModeOverride }),
        ...(input.GlobalSecondaryIndexOverride != null && {
            GlobalSecondaryIndexOverride: serializeAws_json1_0GlobalSecondaryIndexList(input.GlobalSecondaryIndexOverride, context),
        }),
        ...(input.LocalSecondaryIndexOverride != null && {
            LocalSecondaryIndexOverride: serializeAws_json1_0LocalSecondaryIndexList(input.LocalSecondaryIndexOverride, context),
        }),
        ...(input.ProvisionedThroughputOverride != null && {
            ProvisionedThroughputOverride: serializeAws_json1_0ProvisionedThroughput(input.ProvisionedThroughputOverride, context),
        }),
        ...(input.RestoreDateTime != null && { RestoreDateTime: Math.round(input.RestoreDateTime.getTime() / 1000) }),
        ...(input.SSESpecificationOverride != null && {
            SSESpecificationOverride: serializeAws_json1_0SSESpecification(input.SSESpecificationOverride, context),
        }),
        ...(input.SourceTableArn != null && { SourceTableArn: input.SourceTableArn }),
        ...(input.SourceTableName != null && { SourceTableName: input.SourceTableName }),
        ...(input.TargetTableName != null && { TargetTableName: input.TargetTableName }),
        ...(input.UseLatestRestorableTime != null && { UseLatestRestorableTime: input.UseLatestRestorableTime }),
    };
};
const serializeAws_json1_0S3BucketSource = (input, context) => {
    return {
        ...(input.S3Bucket != null && { S3Bucket: input.S3Bucket }),
        ...(input.S3BucketOwner != null && { S3BucketOwner: input.S3BucketOwner }),
        ...(input.S3KeyPrefix != null && { S3KeyPrefix: input.S3KeyPrefix }),
    };
};
const serializeAws_json1_0ScanInput = (input, context) => {
    return {
        ...(input.AttributesToGet != null && {
            AttributesToGet: serializeAws_json1_0AttributeNameList(input.AttributesToGet, context),
        }),
        ...(input.ConditionalOperator != null && { ConditionalOperator: input.ConditionalOperator }),
        ...(input.ConsistentRead != null && { ConsistentRead: input.ConsistentRead }),
        ...(input.ExclusiveStartKey != null && {
            ExclusiveStartKey: serializeAws_json1_0Key(input.ExclusiveStartKey, context),
        }),
        ...(input.ExpressionAttributeNames != null && {
            ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
        }),
        ...(input.ExpressionAttributeValues != null && {
            ExpressionAttributeValues: serializeAws_json1_0ExpressionAttributeValueMap(input.ExpressionAttributeValues, context),
        }),
        ...(input.FilterExpression != null && { FilterExpression: input.FilterExpression }),
        ...(input.IndexName != null && { IndexName: input.IndexName }),
        ...(input.Limit != null && { Limit: input.Limit }),
        ...(input.ProjectionExpression != null && { ProjectionExpression: input.ProjectionExpression }),
        ...(input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity }),
        ...(input.ScanFilter != null && { ScanFilter: serializeAws_json1_0FilterConditionMap(input.ScanFilter, context) }),
        ...(input.Segment != null && { Segment: input.Segment }),
        ...(input.Select != null && { Select: input.Select }),
        ...(input.TableName != null && { TableName: input.TableName }),
        ...(input.TotalSegments != null && { TotalSegments: input.TotalSegments }),
    };
};
const serializeAws_json1_0SSESpecification = (input, context) => {
    return {
        ...(input.Enabled != null && { Enabled: input.Enabled }),
        ...(input.KMSMasterKeyId != null && { KMSMasterKeyId: input.KMSMasterKeyId }),
        ...(input.SSEType != null && { SSEType: input.SSEType }),
    };
};
const serializeAws_json1_0StreamSpecification = (input, context) => {
    return {
        ...(input.StreamEnabled != null && { StreamEnabled: input.StreamEnabled }),
        ...(input.StreamViewType != null && { StreamViewType: input.StreamViewType }),
    };
};
const serializeAws_json1_0StringSetAttributeValue = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return entry;
    });
};
const serializeAws_json1_0TableCreationParameters = (input, context) => {
    return {
        ...(input.AttributeDefinitions != null && {
            AttributeDefinitions: serializeAws_json1_0AttributeDefinitions(input.AttributeDefinitions, context),
        }),
        ...(input.BillingMode != null && { BillingMode: input.BillingMode }),
        ...(input.GlobalSecondaryIndexes != null && {
            GlobalSecondaryIndexes: serializeAws_json1_0GlobalSecondaryIndexList(input.GlobalSecondaryIndexes, context),
        }),
        ...(input.KeySchema != null && { KeySchema: serializeAws_json1_0KeySchema(input.KeySchema, context) }),
        ...(input.ProvisionedThroughput != null && {
            ProvisionedThroughput: serializeAws_json1_0ProvisionedThroughput(input.ProvisionedThroughput, context),
        }),
        ...(input.SSESpecification != null && {
            SSESpecification: serializeAws_json1_0SSESpecification(input.SSESpecification, context),
        }),
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0Tag = (input, context) => {
    return {
        ...(input.Key != null && { Key: input.Key }),
        ...(input.Value != null && { Value: input.Value }),
    };
};
const serializeAws_json1_0TagKeyList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return entry;
    });
};
const serializeAws_json1_0TagList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0Tag(entry, context);
    });
};
const serializeAws_json1_0TagResourceInput = (input, context) => {
    return {
        ...(input.ResourceArn != null && { ResourceArn: input.ResourceArn }),
        ...(input.Tags != null && { Tags: serializeAws_json1_0TagList(input.Tags, context) }),
    };
};
const serializeAws_json1_0TimeToLiveSpecification = (input, context) => {
    return {
        ...(input.AttributeName != null && { AttributeName: input.AttributeName }),
        ...(input.Enabled != null && { Enabled: input.Enabled }),
    };
};
const serializeAws_json1_0TransactGetItem = (input, context) => {
    return {
        ...(input.Get != null && { Get: serializeAws_json1_0Get(input.Get, context) }),
    };
};
const serializeAws_json1_0TransactGetItemList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0TransactGetItem(entry, context);
    });
};
const serializeAws_json1_0TransactGetItemsInput = (input, context) => {
    return {
        ...(input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity }),
        ...(input.TransactItems != null && {
            TransactItems: serializeAws_json1_0TransactGetItemList(input.TransactItems, context),
        }),
    };
};
const serializeAws_json1_0TransactWriteItem = (input, context) => {
    return {
        ...(input.ConditionCheck != null && {
            ConditionCheck: serializeAws_json1_0ConditionCheck(input.ConditionCheck, context),
        }),
        ...(input.Delete != null && { Delete: serializeAws_json1_0Delete(input.Delete, context) }),
        ...(input.Put != null && { Put: serializeAws_json1_0Put(input.Put, context) }),
        ...(input.Update != null && { Update: serializeAws_json1_0Update(input.Update, context) }),
    };
};
const serializeAws_json1_0TransactWriteItemList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0TransactWriteItem(entry, context);
    });
};
const serializeAws_json1_0TransactWriteItemsInput = (input, context) => {
    return {
        ClientRequestToken: input.ClientRequestToken ?? esm_node_v4(),
        ...(input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity }),
        ...(input.ReturnItemCollectionMetrics != null && {
            ReturnItemCollectionMetrics: input.ReturnItemCollectionMetrics,
        }),
        ...(input.TransactItems != null && {
            TransactItems: serializeAws_json1_0TransactWriteItemList(input.TransactItems, context),
        }),
    };
};
const serializeAws_json1_0UntagResourceInput = (input, context) => {
    return {
        ...(input.ResourceArn != null && { ResourceArn: input.ResourceArn }),
        ...(input.TagKeys != null && { TagKeys: serializeAws_json1_0TagKeyList(input.TagKeys, context) }),
    };
};
const serializeAws_json1_0Update = (input, context) => {
    return {
        ...(input.ConditionExpression != null && { ConditionExpression: input.ConditionExpression }),
        ...(input.ExpressionAttributeNames != null && {
            ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
        }),
        ...(input.ExpressionAttributeValues != null && {
            ExpressionAttributeValues: serializeAws_json1_0ExpressionAttributeValueMap(input.ExpressionAttributeValues, context),
        }),
        ...(input.Key != null && { Key: serializeAws_json1_0Key(input.Key, context) }),
        ...(input.ReturnValuesOnConditionCheckFailure != null && {
            ReturnValuesOnConditionCheckFailure: input.ReturnValuesOnConditionCheckFailure,
        }),
        ...(input.TableName != null && { TableName: input.TableName }),
        ...(input.UpdateExpression != null && { UpdateExpression: input.UpdateExpression }),
    };
};
const serializeAws_json1_0UpdateContinuousBackupsInput = (input, context) => {
    return {
        ...(input.PointInTimeRecoverySpecification != null && {
            PointInTimeRecoverySpecification: serializeAws_json1_0PointInTimeRecoverySpecification(input.PointInTimeRecoverySpecification, context),
        }),
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0UpdateContributorInsightsInput = (input, context) => {
    return {
        ...(input.ContributorInsightsAction != null && { ContributorInsightsAction: input.ContributorInsightsAction }),
        ...(input.IndexName != null && { IndexName: input.IndexName }),
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0UpdateGlobalSecondaryIndexAction = (input, context) => {
    return {
        ...(input.IndexName != null && { IndexName: input.IndexName }),
        ...(input.ProvisionedThroughput != null && {
            ProvisionedThroughput: serializeAws_json1_0ProvisionedThroughput(input.ProvisionedThroughput, context),
        }),
    };
};
const serializeAws_json1_0UpdateGlobalTableInput = (input, context) => {
    return {
        ...(input.GlobalTableName != null && { GlobalTableName: input.GlobalTableName }),
        ...(input.ReplicaUpdates != null && {
            ReplicaUpdates: serializeAws_json1_0ReplicaUpdateList(input.ReplicaUpdates, context),
        }),
    };
};
const serializeAws_json1_0UpdateGlobalTableSettingsInput = (input, context) => {
    return {
        ...(input.GlobalTableBillingMode != null && { GlobalTableBillingMode: input.GlobalTableBillingMode }),
        ...(input.GlobalTableGlobalSecondaryIndexSettingsUpdate != null && {
            GlobalTableGlobalSecondaryIndexSettingsUpdate: serializeAws_json1_0GlobalTableGlobalSecondaryIndexSettingsUpdateList(input.GlobalTableGlobalSecondaryIndexSettingsUpdate, context),
        }),
        ...(input.GlobalTableName != null && { GlobalTableName: input.GlobalTableName }),
        ...(input.GlobalTableProvisionedWriteCapacityAutoScalingSettingsUpdate != null && {
            GlobalTableProvisionedWriteCapacityAutoScalingSettingsUpdate: serializeAws_json1_0AutoScalingSettingsUpdate(input.GlobalTableProvisionedWriteCapacityAutoScalingSettingsUpdate, context),
        }),
        ...(input.GlobalTableProvisionedWriteCapacityUnits != null && {
            GlobalTableProvisionedWriteCapacityUnits: input.GlobalTableProvisionedWriteCapacityUnits,
        }),
        ...(input.ReplicaSettingsUpdate != null && {
            ReplicaSettingsUpdate: serializeAws_json1_0ReplicaSettingsUpdateList(input.ReplicaSettingsUpdate, context),
        }),
    };
};
const serializeAws_json1_0UpdateItemInput = (input, context) => {
    return {
        ...(input.AttributeUpdates != null && {
            AttributeUpdates: serializeAws_json1_0AttributeUpdates(input.AttributeUpdates, context),
        }),
        ...(input.ConditionExpression != null && { ConditionExpression: input.ConditionExpression }),
        ...(input.ConditionalOperator != null && { ConditionalOperator: input.ConditionalOperator }),
        ...(input.Expected != null && { Expected: serializeAws_json1_0ExpectedAttributeMap(input.Expected, context) }),
        ...(input.ExpressionAttributeNames != null && {
            ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
        }),
        ...(input.ExpressionAttributeValues != null && {
            ExpressionAttributeValues: serializeAws_json1_0ExpressionAttributeValueMap(input.ExpressionAttributeValues, context),
        }),
        ...(input.Key != null && { Key: serializeAws_json1_0Key(input.Key, context) }),
        ...(input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity }),
        ...(input.ReturnItemCollectionMetrics != null && {
            ReturnItemCollectionMetrics: input.ReturnItemCollectionMetrics,
        }),
        ...(input.ReturnValues != null && { ReturnValues: input.ReturnValues }),
        ...(input.TableName != null && { TableName: input.TableName }),
        ...(input.UpdateExpression != null && { UpdateExpression: input.UpdateExpression }),
    };
};
const serializeAws_json1_0UpdateReplicationGroupMemberAction = (input, context) => {
    return {
        ...(input.GlobalSecondaryIndexes != null && {
            GlobalSecondaryIndexes: serializeAws_json1_0ReplicaGlobalSecondaryIndexList(input.GlobalSecondaryIndexes, context),
        }),
        ...(input.KMSMasterKeyId != null && { KMSMasterKeyId: input.KMSMasterKeyId }),
        ...(input.ProvisionedThroughputOverride != null && {
            ProvisionedThroughputOverride: serializeAws_json1_0ProvisionedThroughputOverride(input.ProvisionedThroughputOverride, context),
        }),
        ...(input.RegionName != null && { RegionName: input.RegionName }),
        ...(input.TableClassOverride != null && { TableClassOverride: input.TableClassOverride }),
    };
};
const serializeAws_json1_0UpdateTableInput = (input, context) => {
    return {
        ...(input.AttributeDefinitions != null && {
            AttributeDefinitions: serializeAws_json1_0AttributeDefinitions(input.AttributeDefinitions, context),
        }),
        ...(input.BillingMode != null && { BillingMode: input.BillingMode }),
        ...(input.GlobalSecondaryIndexUpdates != null && {
            GlobalSecondaryIndexUpdates: serializeAws_json1_0GlobalSecondaryIndexUpdateList(input.GlobalSecondaryIndexUpdates, context),
        }),
        ...(input.ProvisionedThroughput != null && {
            ProvisionedThroughput: serializeAws_json1_0ProvisionedThroughput(input.ProvisionedThroughput, context),
        }),
        ...(input.ReplicaUpdates != null && {
            ReplicaUpdates: serializeAws_json1_0ReplicationGroupUpdateList(input.ReplicaUpdates, context),
        }),
        ...(input.SSESpecification != null && {
            SSESpecification: serializeAws_json1_0SSESpecification(input.SSESpecification, context),
        }),
        ...(input.StreamSpecification != null && {
            StreamSpecification: serializeAws_json1_0StreamSpecification(input.StreamSpecification, context),
        }),
        ...(input.TableClass != null && { TableClass: input.TableClass }),
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0UpdateTableReplicaAutoScalingInput = (input, context) => {
    return {
        ...(input.GlobalSecondaryIndexUpdates != null && {
            GlobalSecondaryIndexUpdates: serializeAws_json1_0GlobalSecondaryIndexAutoScalingUpdateList(input.GlobalSecondaryIndexUpdates, context),
        }),
        ...(input.ProvisionedWriteCapacityAutoScalingUpdate != null && {
            ProvisionedWriteCapacityAutoScalingUpdate: serializeAws_json1_0AutoScalingSettingsUpdate(input.ProvisionedWriteCapacityAutoScalingUpdate, context),
        }),
        ...(input.ReplicaUpdates != null && {
            ReplicaUpdates: serializeAws_json1_0ReplicaAutoScalingUpdateList(input.ReplicaUpdates, context),
        }),
        ...(input.TableName != null && { TableName: input.TableName }),
    };
};
const serializeAws_json1_0UpdateTimeToLiveInput = (input, context) => {
    return {
        ...(input.TableName != null && { TableName: input.TableName }),
        ...(input.TimeToLiveSpecification != null && {
            TimeToLiveSpecification: serializeAws_json1_0TimeToLiveSpecification(input.TimeToLiveSpecification, context),
        }),
    };
};
const serializeAws_json1_0WriteRequest = (input, context) => {
    return {
        ...(input.DeleteRequest != null && {
            DeleteRequest: serializeAws_json1_0DeleteRequest(input.DeleteRequest, context),
        }),
        ...(input.PutRequest != null && { PutRequest: serializeAws_json1_0PutRequest(input.PutRequest, context) }),
    };
};
const serializeAws_json1_0WriteRequests = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return serializeAws_json1_0WriteRequest(entry, context);
    });
};
const deserializeAws_json1_0ArchivalSummary = (output, context) => {
    return {
        ArchivalBackupArn: expectString(output.ArchivalBackupArn),
        ArchivalDateTime: output.ArchivalDateTime != null
            ? expectNonNull(parseEpochTimestamp(expectNumber(output.ArchivalDateTime)))
            : undefined,
        ArchivalReason: expectString(output.ArchivalReason),
    };
};
const deserializeAws_json1_0AttributeDefinition = (output, context) => {
    return {
        AttributeName: expectString(output.AttributeName),
        AttributeType: expectString(output.AttributeType),
    };
};
const deserializeAws_json1_0AttributeDefinitions = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0AttributeDefinition(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0AttributeMap = (output, context) => {
    return Object.entries(output).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: deserializeAws_json1_0AttributeValue(expectUnion(value), context),
        };
    }, {});
};
const deserializeAws_json1_0AttributeNameList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return expectString(entry);
    });
    return retVal;
};
const deserializeAws_json1_0AttributeValue = (output, context) => {
    if (output.B != null) {
        return {
            B: context.base64Decoder(output.B),
        };
    }
    if (expectBoolean(output.BOOL) !== undefined) {
        return { BOOL: expectBoolean(output.BOOL) };
    }
    if (output.BS != null) {
        return {
            BS: deserializeAws_json1_0BinarySetAttributeValue(output.BS, context),
        };
    }
    if (output.L != null) {
        return {
            L: deserializeAws_json1_0ListAttributeValue(output.L, context),
        };
    }
    if (output.M != null) {
        return {
            M: deserializeAws_json1_0MapAttributeValue(output.M, context),
        };
    }
    if (expectString(output.N) !== undefined) {
        return { N: expectString(output.N) };
    }
    if (output.NS != null) {
        return {
            NS: deserializeAws_json1_0NumberSetAttributeValue(output.NS, context),
        };
    }
    if (expectBoolean(output.NULL) !== undefined) {
        return { NULL: expectBoolean(output.NULL) };
    }
    if (expectString(output.S) !== undefined) {
        return { S: expectString(output.S) };
    }
    if (output.SS != null) {
        return {
            SS: deserializeAws_json1_0StringSetAttributeValue(output.SS, context),
        };
    }
    return { $unknown: Object.entries(output)[0] };
};
const deserializeAws_json1_0AutoScalingPolicyDescription = (output, context) => {
    return {
        PolicyName: expectString(output.PolicyName),
        TargetTrackingScalingPolicyConfiguration: output.TargetTrackingScalingPolicyConfiguration != null
            ? deserializeAws_json1_0AutoScalingTargetTrackingScalingPolicyConfigurationDescription(output.TargetTrackingScalingPolicyConfiguration, context)
            : undefined,
    };
};
const deserializeAws_json1_0AutoScalingPolicyDescriptionList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0AutoScalingPolicyDescription(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0AutoScalingSettingsDescription = (output, context) => {
    return {
        AutoScalingDisabled: expectBoolean(output.AutoScalingDisabled),
        AutoScalingRoleArn: expectString(output.AutoScalingRoleArn),
        MaximumUnits: expectLong(output.MaximumUnits),
        MinimumUnits: expectLong(output.MinimumUnits),
        ScalingPolicies: output.ScalingPolicies != null
            ? deserializeAws_json1_0AutoScalingPolicyDescriptionList(output.ScalingPolicies, context)
            : undefined,
    };
};
const deserializeAws_json1_0AutoScalingTargetTrackingScalingPolicyConfigurationDescription = (output, context) => {
    return {
        DisableScaleIn: expectBoolean(output.DisableScaleIn),
        ScaleInCooldown: expectInt32(output.ScaleInCooldown),
        ScaleOutCooldown: expectInt32(output.ScaleOutCooldown),
        TargetValue: limitedParseDouble(output.TargetValue),
    };
};
const deserializeAws_json1_0BackupDescription = (output, context) => {
    return {
        BackupDetails: output.BackupDetails != null ? deserializeAws_json1_0BackupDetails(output.BackupDetails, context) : undefined,
        SourceTableDetails: output.SourceTableDetails != null
            ? deserializeAws_json1_0SourceTableDetails(output.SourceTableDetails, context)
            : undefined,
        SourceTableFeatureDetails: output.SourceTableFeatureDetails != null
            ? deserializeAws_json1_0SourceTableFeatureDetails(output.SourceTableFeatureDetails, context)
            : undefined,
    };
};
const deserializeAws_json1_0BackupDetails = (output, context) => {
    return {
        BackupArn: expectString(output.BackupArn),
        BackupCreationDateTime: output.BackupCreationDateTime != null
            ? expectNonNull(parseEpochTimestamp(expectNumber(output.BackupCreationDateTime)))
            : undefined,
        BackupExpiryDateTime: output.BackupExpiryDateTime != null
            ? expectNonNull(parseEpochTimestamp(expectNumber(output.BackupExpiryDateTime)))
            : undefined,
        BackupName: expectString(output.BackupName),
        BackupSizeBytes: expectLong(output.BackupSizeBytes),
        BackupStatus: expectString(output.BackupStatus),
        BackupType: expectString(output.BackupType),
    };
};
const deserializeAws_json1_0BackupInUseException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0BackupNotFoundException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0BackupSummaries = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0BackupSummary(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0BackupSummary = (output, context) => {
    return {
        BackupArn: expectString(output.BackupArn),
        BackupCreationDateTime: output.BackupCreationDateTime != null
            ? expectNonNull(parseEpochTimestamp(expectNumber(output.BackupCreationDateTime)))
            : undefined,
        BackupExpiryDateTime: output.BackupExpiryDateTime != null
            ? expectNonNull(parseEpochTimestamp(expectNumber(output.BackupExpiryDateTime)))
            : undefined,
        BackupName: expectString(output.BackupName),
        BackupSizeBytes: expectLong(output.BackupSizeBytes),
        BackupStatus: expectString(output.BackupStatus),
        BackupType: expectString(output.BackupType),
        TableArn: expectString(output.TableArn),
        TableId: expectString(output.TableId),
        TableName: expectString(output.TableName),
    };
};
const deserializeAws_json1_0BatchExecuteStatementOutput = (output, context) => {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacityMultiple(output.ConsumedCapacity, context)
            : undefined,
        Responses: output.Responses != null ? deserializeAws_json1_0PartiQLBatchResponse(output.Responses, context) : undefined,
    };
};
const deserializeAws_json1_0BatchGetItemOutput = (output, context) => {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacityMultiple(output.ConsumedCapacity, context)
            : undefined,
        Responses: output.Responses != null ? deserializeAws_json1_0BatchGetResponseMap(output.Responses, context) : undefined,
        UnprocessedKeys: output.UnprocessedKeys != null
            ? deserializeAws_json1_0BatchGetRequestMap(output.UnprocessedKeys, context)
            : undefined,
    };
};
const deserializeAws_json1_0BatchGetRequestMap = (output, context) => {
    return Object.entries(output).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: deserializeAws_json1_0KeysAndAttributes(value, context),
        };
    }, {});
};
const deserializeAws_json1_0BatchGetResponseMap = (output, context) => {
    return Object.entries(output).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: deserializeAws_json1_0ItemList(value, context),
        };
    }, {});
};
const deserializeAws_json1_0BatchStatementError = (output, context) => {
    return {
        Code: expectString(output.Code),
        Message: expectString(output.Message),
    };
};
const deserializeAws_json1_0BatchStatementResponse = (output, context) => {
    return {
        Error: output.Error != null ? deserializeAws_json1_0BatchStatementError(output.Error, context) : undefined,
        Item: output.Item != null ? deserializeAws_json1_0AttributeMap(output.Item, context) : undefined,
        TableName: expectString(output.TableName),
    };
};
const deserializeAws_json1_0BatchWriteItemOutput = (output, context) => {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacityMultiple(output.ConsumedCapacity, context)
            : undefined,
        ItemCollectionMetrics: output.ItemCollectionMetrics != null
            ? deserializeAws_json1_0ItemCollectionMetricsPerTable(output.ItemCollectionMetrics, context)
            : undefined,
        UnprocessedItems: output.UnprocessedItems != null
            ? deserializeAws_json1_0BatchWriteItemRequestMap(output.UnprocessedItems, context)
            : undefined,
    };
};
const deserializeAws_json1_0BatchWriteItemRequestMap = (output, context) => {
    return Object.entries(output).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: deserializeAws_json1_0WriteRequests(value, context),
        };
    }, {});
};
const deserializeAws_json1_0BillingModeSummary = (output, context) => {
    return {
        BillingMode: expectString(output.BillingMode),
        LastUpdateToPayPerRequestDateTime: output.LastUpdateToPayPerRequestDateTime != null
            ? expectNonNull(parseEpochTimestamp(expectNumber(output.LastUpdateToPayPerRequestDateTime)))
            : undefined,
    };
};
const deserializeAws_json1_0BinarySetAttributeValue = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return context.base64Decoder(entry);
    });
    return retVal;
};
const deserializeAws_json1_0CancellationReason = (output, context) => {
    return {
        Code: expectString(output.Code),
        Item: output.Item != null ? deserializeAws_json1_0AttributeMap(output.Item, context) : undefined,
        Message: expectString(output.Message),
    };
};
const deserializeAws_json1_0CancellationReasonList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0CancellationReason(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0Capacity = (output, context) => {
    return {
        CapacityUnits: limitedParseDouble(output.CapacityUnits),
        ReadCapacityUnits: limitedParseDouble(output.ReadCapacityUnits),
        WriteCapacityUnits: limitedParseDouble(output.WriteCapacityUnits),
    };
};
const deserializeAws_json1_0ConditionalCheckFailedException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0ConsumedCapacity = (output, context) => {
    return {
        CapacityUnits: limitedParseDouble(output.CapacityUnits),
        GlobalSecondaryIndexes: output.GlobalSecondaryIndexes != null
            ? deserializeAws_json1_0SecondaryIndexesCapacityMap(output.GlobalSecondaryIndexes, context)
            : undefined,
        LocalSecondaryIndexes: output.LocalSecondaryIndexes != null
            ? deserializeAws_json1_0SecondaryIndexesCapacityMap(output.LocalSecondaryIndexes, context)
            : undefined,
        ReadCapacityUnits: limitedParseDouble(output.ReadCapacityUnits),
        Table: output.Table != null ? deserializeAws_json1_0Capacity(output.Table, context) : undefined,
        TableName: expectString(output.TableName),
        WriteCapacityUnits: limitedParseDouble(output.WriteCapacityUnits),
    };
};
const deserializeAws_json1_0ConsumedCapacityMultiple = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ConsumedCapacity(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0ContinuousBackupsDescription = (output, context) => {
    return {
        ContinuousBackupsStatus: expectString(output.ContinuousBackupsStatus),
        PointInTimeRecoveryDescription: output.PointInTimeRecoveryDescription != null
            ? deserializeAws_json1_0PointInTimeRecoveryDescription(output.PointInTimeRecoveryDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0ContinuousBackupsUnavailableException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0ContributorInsightsRuleList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return expectString(entry);
    });
    return retVal;
};
const deserializeAws_json1_0ContributorInsightsSummaries = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ContributorInsightsSummary(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0ContributorInsightsSummary = (output, context) => {
    return {
        ContributorInsightsStatus: expectString(output.ContributorInsightsStatus),
        IndexName: expectString(output.IndexName),
        TableName: expectString(output.TableName),
    };
};
const deserializeAws_json1_0CreateBackupOutput = (output, context) => {
    return {
        BackupDetails: output.BackupDetails != null ? deserializeAws_json1_0BackupDetails(output.BackupDetails, context) : undefined,
    };
};
const deserializeAws_json1_0CreateGlobalTableOutput = (output, context) => {
    return {
        GlobalTableDescription: output.GlobalTableDescription != null
            ? deserializeAws_json1_0GlobalTableDescription(output.GlobalTableDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0CreateTableOutput = (output, context) => {
    return {
        TableDescription: output.TableDescription != null
            ? deserializeAws_json1_0TableDescription(output.TableDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0CsvHeaderList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return expectString(entry);
    });
    return retVal;
};
const deserializeAws_json1_0CsvOptions = (output, context) => {
    return {
        Delimiter: expectString(output.Delimiter),
        HeaderList: output.HeaderList != null ? deserializeAws_json1_0CsvHeaderList(output.HeaderList, context) : undefined,
    };
};
const deserializeAws_json1_0DeleteBackupOutput = (output, context) => {
    return {
        BackupDescription: output.BackupDescription != null
            ? deserializeAws_json1_0BackupDescription(output.BackupDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0DeleteItemOutput = (output, context) => {
    return {
        Attributes: output.Attributes != null ? deserializeAws_json1_0AttributeMap(output.Attributes, context) : undefined,
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacity(output.ConsumedCapacity, context)
            : undefined,
        ItemCollectionMetrics: output.ItemCollectionMetrics != null
            ? deserializeAws_json1_0ItemCollectionMetrics(output.ItemCollectionMetrics, context)
            : undefined,
    };
};
const deserializeAws_json1_0DeleteRequest = (output, context) => {
    return {
        Key: output.Key != null ? deserializeAws_json1_0Key(output.Key, context) : undefined,
    };
};
const deserializeAws_json1_0DeleteTableOutput = (output, context) => {
    return {
        TableDescription: output.TableDescription != null
            ? deserializeAws_json1_0TableDescription(output.TableDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0DescribeBackupOutput = (output, context) => {
    return {
        BackupDescription: output.BackupDescription != null
            ? deserializeAws_json1_0BackupDescription(output.BackupDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0DescribeContinuousBackupsOutput = (output, context) => {
    return {
        ContinuousBackupsDescription: output.ContinuousBackupsDescription != null
            ? deserializeAws_json1_0ContinuousBackupsDescription(output.ContinuousBackupsDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0DescribeContributorInsightsOutput = (output, context) => {
    return {
        ContributorInsightsRuleList: output.ContributorInsightsRuleList != null
            ? deserializeAws_json1_0ContributorInsightsRuleList(output.ContributorInsightsRuleList, context)
            : undefined,
        ContributorInsightsStatus: expectString(output.ContributorInsightsStatus),
        FailureException: output.FailureException != null
            ? deserializeAws_json1_0FailureException(output.FailureException, context)
            : undefined,
        IndexName: expectString(output.IndexName),
        LastUpdateDateTime: output.LastUpdateDateTime != null
            ? expectNonNull(parseEpochTimestamp(expectNumber(output.LastUpdateDateTime)))
            : undefined,
        TableName: expectString(output.TableName),
    };
};
const deserializeAws_json1_0DescribeEndpointsResponse = (output, context) => {
    return {
        Endpoints: output.Endpoints != null ? deserializeAws_json1_0Endpoints(output.Endpoints, context) : undefined,
    };
};
const deserializeAws_json1_0DescribeExportOutput = (output, context) => {
    return {
        ExportDescription: output.ExportDescription != null
            ? deserializeAws_json1_0ExportDescription(output.ExportDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0DescribeGlobalTableOutput = (output, context) => {
    return {
        GlobalTableDescription: output.GlobalTableDescription != null
            ? deserializeAws_json1_0GlobalTableDescription(output.GlobalTableDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0DescribeGlobalTableSettingsOutput = (output, context) => {
    return {
        GlobalTableName: expectString(output.GlobalTableName),
        ReplicaSettings: output.ReplicaSettings != null
            ? deserializeAws_json1_0ReplicaSettingsDescriptionList(output.ReplicaSettings, context)
            : undefined,
    };
};
const deserializeAws_json1_0DescribeImportOutput = (output, context) => {
    return {
        ImportTableDescription: output.ImportTableDescription != null
            ? deserializeAws_json1_0ImportTableDescription(output.ImportTableDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0DescribeKinesisStreamingDestinationOutput = (output, context) => {
    return {
        KinesisDataStreamDestinations: output.KinesisDataStreamDestinations != null
            ? deserializeAws_json1_0KinesisDataStreamDestinations(output.KinesisDataStreamDestinations, context)
            : undefined,
        TableName: expectString(output.TableName),
    };
};
const deserializeAws_json1_0DescribeLimitsOutput = (output, context) => {
    return {
        AccountMaxReadCapacityUnits: expectLong(output.AccountMaxReadCapacityUnits),
        AccountMaxWriteCapacityUnits: expectLong(output.AccountMaxWriteCapacityUnits),
        TableMaxReadCapacityUnits: expectLong(output.TableMaxReadCapacityUnits),
        TableMaxWriteCapacityUnits: expectLong(output.TableMaxWriteCapacityUnits),
    };
};
const deserializeAws_json1_0DescribeTableOutput = (output, context) => {
    return {
        Table: output.Table != null ? deserializeAws_json1_0TableDescription(output.Table, context) : undefined,
    };
};
const deserializeAws_json1_0DescribeTableReplicaAutoScalingOutput = (output, context) => {
    return {
        TableAutoScalingDescription: output.TableAutoScalingDescription != null
            ? deserializeAws_json1_0TableAutoScalingDescription(output.TableAutoScalingDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0DescribeTimeToLiveOutput = (output, context) => {
    return {
        TimeToLiveDescription: output.TimeToLiveDescription != null
            ? deserializeAws_json1_0TimeToLiveDescription(output.TimeToLiveDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0DuplicateItemException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0Endpoint = (output, context) => {
    return {
        Address: expectString(output.Address),
        CachePeriodInMinutes: expectLong(output.CachePeriodInMinutes),
    };
};
const deserializeAws_json1_0Endpoints = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0Endpoint(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0ExecuteStatementOutput = (output, context) => {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacity(output.ConsumedCapacity, context)
            : undefined,
        Items: output.Items != null ? deserializeAws_json1_0ItemList(output.Items, context) : undefined,
        LastEvaluatedKey: output.LastEvaluatedKey != null ? deserializeAws_json1_0Key(output.LastEvaluatedKey, context) : undefined,
        NextToken: expectString(output.NextToken),
    };
};
const deserializeAws_json1_0ExecuteTransactionOutput = (output, context) => {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacityMultiple(output.ConsumedCapacity, context)
            : undefined,
        Responses: output.Responses != null ? deserializeAws_json1_0ItemResponseList(output.Responses, context) : undefined,
    };
};
const deserializeAws_json1_0ExportConflictException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0ExportDescription = (output, context) => {
    return {
        BilledSizeBytes: expectLong(output.BilledSizeBytes),
        ClientToken: expectString(output.ClientToken),
        EndTime: output.EndTime != null ? expectNonNull(parseEpochTimestamp(expectNumber(output.EndTime))) : undefined,
        ExportArn: expectString(output.ExportArn),
        ExportFormat: expectString(output.ExportFormat),
        ExportManifest: expectString(output.ExportManifest),
        ExportStatus: expectString(output.ExportStatus),
        ExportTime: output.ExportTime != null ? expectNonNull(parseEpochTimestamp(expectNumber(output.ExportTime))) : undefined,
        FailureCode: expectString(output.FailureCode),
        FailureMessage: expectString(output.FailureMessage),
        ItemCount: expectLong(output.ItemCount),
        S3Bucket: expectString(output.S3Bucket),
        S3BucketOwner: expectString(output.S3BucketOwner),
        S3Prefix: expectString(output.S3Prefix),
        S3SseAlgorithm: expectString(output.S3SseAlgorithm),
        S3SseKmsKeyId: expectString(output.S3SseKmsKeyId),
        StartTime: output.StartTime != null ? expectNonNull(parseEpochTimestamp(expectNumber(output.StartTime))) : undefined,
        TableArn: expectString(output.TableArn),
        TableId: expectString(output.TableId),
    };
};
const deserializeAws_json1_0ExportNotFoundException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0ExportSummaries = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ExportSummary(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0ExportSummary = (output, context) => {
    return {
        ExportArn: expectString(output.ExportArn),
        ExportStatus: expectString(output.ExportStatus),
    };
};
const deserializeAws_json1_0ExportTableToPointInTimeOutput = (output, context) => {
    return {
        ExportDescription: output.ExportDescription != null
            ? deserializeAws_json1_0ExportDescription(output.ExportDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0ExpressionAttributeNameMap = (output, context) => {
    return Object.entries(output).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: expectString(value),
        };
    }, {});
};
const deserializeAws_json1_0FailureException = (output, context) => {
    return {
        ExceptionDescription: expectString(output.ExceptionDescription),
        ExceptionName: expectString(output.ExceptionName),
    };
};
const deserializeAws_json1_0GetItemOutput = (output, context) => {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacity(output.ConsumedCapacity, context)
            : undefined,
        Item: output.Item != null ? deserializeAws_json1_0AttributeMap(output.Item, context) : undefined,
    };
};
const deserializeAws_json1_0GlobalSecondaryIndex = (output, context) => {
    return {
        IndexName: expectString(output.IndexName),
        KeySchema: output.KeySchema != null ? deserializeAws_json1_0KeySchema(output.KeySchema, context) : undefined,
        Projection: output.Projection != null ? deserializeAws_json1_0Projection(output.Projection, context) : undefined,
        ProvisionedThroughput: output.ProvisionedThroughput != null
            ? deserializeAws_json1_0ProvisionedThroughput(output.ProvisionedThroughput, context)
            : undefined,
    };
};
const deserializeAws_json1_0GlobalSecondaryIndexDescription = (output, context) => {
    return {
        Backfilling: expectBoolean(output.Backfilling),
        IndexArn: expectString(output.IndexArn),
        IndexName: expectString(output.IndexName),
        IndexSizeBytes: expectLong(output.IndexSizeBytes),
        IndexStatus: expectString(output.IndexStatus),
        ItemCount: expectLong(output.ItemCount),
        KeySchema: output.KeySchema != null ? deserializeAws_json1_0KeySchema(output.KeySchema, context) : undefined,
        Projection: output.Projection != null ? deserializeAws_json1_0Projection(output.Projection, context) : undefined,
        ProvisionedThroughput: output.ProvisionedThroughput != null
            ? deserializeAws_json1_0ProvisionedThroughputDescription(output.ProvisionedThroughput, context)
            : undefined,
    };
};
const deserializeAws_json1_0GlobalSecondaryIndexDescriptionList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0GlobalSecondaryIndexDescription(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0GlobalSecondaryIndexes = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0GlobalSecondaryIndexInfo(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0GlobalSecondaryIndexInfo = (output, context) => {
    return {
        IndexName: expectString(output.IndexName),
        KeySchema: output.KeySchema != null ? deserializeAws_json1_0KeySchema(output.KeySchema, context) : undefined,
        Projection: output.Projection != null ? deserializeAws_json1_0Projection(output.Projection, context) : undefined,
        ProvisionedThroughput: output.ProvisionedThroughput != null
            ? deserializeAws_json1_0ProvisionedThroughput(output.ProvisionedThroughput, context)
            : undefined,
    };
};
const deserializeAws_json1_0GlobalSecondaryIndexList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0GlobalSecondaryIndex(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0GlobalTable = (output, context) => {
    return {
        GlobalTableName: expectString(output.GlobalTableName),
        ReplicationGroup: output.ReplicationGroup != null ? deserializeAws_json1_0ReplicaList(output.ReplicationGroup, context) : undefined,
    };
};
const deserializeAws_json1_0GlobalTableAlreadyExistsException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0GlobalTableDescription = (output, context) => {
    return {
        CreationDateTime: output.CreationDateTime != null
            ? expectNonNull(parseEpochTimestamp(expectNumber(output.CreationDateTime)))
            : undefined,
        GlobalTableArn: expectString(output.GlobalTableArn),
        GlobalTableName: expectString(output.GlobalTableName),
        GlobalTableStatus: expectString(output.GlobalTableStatus),
        ReplicationGroup: output.ReplicationGroup != null
            ? deserializeAws_json1_0ReplicaDescriptionList(output.ReplicationGroup, context)
            : undefined,
    };
};
const deserializeAws_json1_0GlobalTableList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0GlobalTable(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0GlobalTableNotFoundException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0IdempotentParameterMismatchException = (output, context) => {
    return {
        Message: expectString(output.Message),
    };
};
const deserializeAws_json1_0ImportConflictException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0ImportNotFoundException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0ImportSummary = (output, context) => {
    return {
        CloudWatchLogGroupArn: expectString(output.CloudWatchLogGroupArn),
        EndTime: output.EndTime != null ? expectNonNull(parseEpochTimestamp(expectNumber(output.EndTime))) : undefined,
        ImportArn: expectString(output.ImportArn),
        ImportStatus: expectString(output.ImportStatus),
        InputFormat: expectString(output.InputFormat),
        S3BucketSource: output.S3BucketSource != null ? deserializeAws_json1_0S3BucketSource(output.S3BucketSource, context) : undefined,
        StartTime: output.StartTime != null ? expectNonNull(parseEpochTimestamp(expectNumber(output.StartTime))) : undefined,
        TableArn: expectString(output.TableArn),
    };
};
const deserializeAws_json1_0ImportSummaryList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ImportSummary(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0ImportTableDescription = (output, context) => {
    return {
        ClientToken: expectString(output.ClientToken),
        CloudWatchLogGroupArn: expectString(output.CloudWatchLogGroupArn),
        EndTime: output.EndTime != null ? expectNonNull(parseEpochTimestamp(expectNumber(output.EndTime))) : undefined,
        ErrorCount: expectLong(output.ErrorCount),
        FailureCode: expectString(output.FailureCode),
        FailureMessage: expectString(output.FailureMessage),
        ImportArn: expectString(output.ImportArn),
        ImportStatus: expectString(output.ImportStatus),
        ImportedItemCount: expectLong(output.ImportedItemCount),
        InputCompressionType: expectString(output.InputCompressionType),
        InputFormat: expectString(output.InputFormat),
        InputFormatOptions: output.InputFormatOptions != null
            ? deserializeAws_json1_0InputFormatOptions(output.InputFormatOptions, context)
            : undefined,
        ProcessedItemCount: expectLong(output.ProcessedItemCount),
        ProcessedSizeBytes: expectLong(output.ProcessedSizeBytes),
        S3BucketSource: output.S3BucketSource != null ? deserializeAws_json1_0S3BucketSource(output.S3BucketSource, context) : undefined,
        StartTime: output.StartTime != null ? expectNonNull(parseEpochTimestamp(expectNumber(output.StartTime))) : undefined,
        TableArn: expectString(output.TableArn),
        TableCreationParameters: output.TableCreationParameters != null
            ? deserializeAws_json1_0TableCreationParameters(output.TableCreationParameters, context)
            : undefined,
        TableId: expectString(output.TableId),
    };
};
const deserializeAws_json1_0ImportTableOutput = (output, context) => {
    return {
        ImportTableDescription: output.ImportTableDescription != null
            ? deserializeAws_json1_0ImportTableDescription(output.ImportTableDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0IndexNotFoundException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0InputFormatOptions = (output, context) => {
    return {
        Csv: output.Csv != null ? deserializeAws_json1_0CsvOptions(output.Csv, context) : undefined,
    };
};
const deserializeAws_json1_0InternalServerError = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0InvalidEndpointException = (output, context) => {
    return {
        Message: expectString(output.Message),
    };
};
const deserializeAws_json1_0InvalidExportTimeException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0InvalidRestoreTimeException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0ItemCollectionKeyAttributeMap = (output, context) => {
    return Object.entries(output).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: deserializeAws_json1_0AttributeValue(expectUnion(value), context),
        };
    }, {});
};
const deserializeAws_json1_0ItemCollectionMetrics = (output, context) => {
    return {
        ItemCollectionKey: output.ItemCollectionKey != null
            ? deserializeAws_json1_0ItemCollectionKeyAttributeMap(output.ItemCollectionKey, context)
            : undefined,
        SizeEstimateRangeGB: output.SizeEstimateRangeGB != null
            ? deserializeAws_json1_0ItemCollectionSizeEstimateRange(output.SizeEstimateRangeGB, context)
            : undefined,
    };
};
const deserializeAws_json1_0ItemCollectionMetricsMultiple = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ItemCollectionMetrics(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0ItemCollectionMetricsPerTable = (output, context) => {
    return Object.entries(output).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: deserializeAws_json1_0ItemCollectionMetricsMultiple(value, context),
        };
    }, {});
};
const deserializeAws_json1_0ItemCollectionSizeEstimateRange = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return limitedParseDouble(entry);
    });
    return retVal;
};
const deserializeAws_json1_0ItemCollectionSizeLimitExceededException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0ItemList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0AttributeMap(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0ItemResponse = (output, context) => {
    return {
        Item: output.Item != null ? deserializeAws_json1_0AttributeMap(output.Item, context) : undefined,
    };
};
const deserializeAws_json1_0ItemResponseList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ItemResponse(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0Key = (output, context) => {
    return Object.entries(output).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: deserializeAws_json1_0AttributeValue(expectUnion(value), context),
        };
    }, {});
};
const deserializeAws_json1_0KeyList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0Key(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0KeysAndAttributes = (output, context) => {
    return {
        AttributesToGet: output.AttributesToGet != null
            ? deserializeAws_json1_0AttributeNameList(output.AttributesToGet, context)
            : undefined,
        ConsistentRead: expectBoolean(output.ConsistentRead),
        ExpressionAttributeNames: output.ExpressionAttributeNames != null
            ? deserializeAws_json1_0ExpressionAttributeNameMap(output.ExpressionAttributeNames, context)
            : undefined,
        Keys: output.Keys != null ? deserializeAws_json1_0KeyList(output.Keys, context) : undefined,
        ProjectionExpression: expectString(output.ProjectionExpression),
    };
};
const deserializeAws_json1_0KeySchema = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0KeySchemaElement(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0KeySchemaElement = (output, context) => {
    return {
        AttributeName: expectString(output.AttributeName),
        KeyType: expectString(output.KeyType),
    };
};
const deserializeAws_json1_0KinesisDataStreamDestination = (output, context) => {
    return {
        DestinationStatus: expectString(output.DestinationStatus),
        DestinationStatusDescription: expectString(output.DestinationStatusDescription),
        StreamArn: expectString(output.StreamArn),
    };
};
const deserializeAws_json1_0KinesisDataStreamDestinations = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0KinesisDataStreamDestination(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0KinesisStreamingDestinationOutput = (output, context) => {
    return {
        DestinationStatus: expectString(output.DestinationStatus),
        StreamArn: expectString(output.StreamArn),
        TableName: expectString(output.TableName),
    };
};
const deserializeAws_json1_0LimitExceededException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0ListAttributeValue = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0AttributeValue(expectUnion(entry), context);
    });
    return retVal;
};
const deserializeAws_json1_0ListBackupsOutput = (output, context) => {
    return {
        BackupSummaries: output.BackupSummaries != null
            ? deserializeAws_json1_0BackupSummaries(output.BackupSummaries, context)
            : undefined,
        LastEvaluatedBackupArn: expectString(output.LastEvaluatedBackupArn),
    };
};
const deserializeAws_json1_0ListContributorInsightsOutput = (output, context) => {
    return {
        ContributorInsightsSummaries: output.ContributorInsightsSummaries != null
            ? deserializeAws_json1_0ContributorInsightsSummaries(output.ContributorInsightsSummaries, context)
            : undefined,
        NextToken: expectString(output.NextToken),
    };
};
const deserializeAws_json1_0ListExportsOutput = (output, context) => {
    return {
        ExportSummaries: output.ExportSummaries != null
            ? deserializeAws_json1_0ExportSummaries(output.ExportSummaries, context)
            : undefined,
        NextToken: expectString(output.NextToken),
    };
};
const deserializeAws_json1_0ListGlobalTablesOutput = (output, context) => {
    return {
        GlobalTables: output.GlobalTables != null ? deserializeAws_json1_0GlobalTableList(output.GlobalTables, context) : undefined,
        LastEvaluatedGlobalTableName: expectString(output.LastEvaluatedGlobalTableName),
    };
};
const deserializeAws_json1_0ListImportsOutput = (output, context) => {
    return {
        ImportSummaryList: output.ImportSummaryList != null
            ? deserializeAws_json1_0ImportSummaryList(output.ImportSummaryList, context)
            : undefined,
        NextToken: expectString(output.NextToken),
    };
};
const deserializeAws_json1_0ListTablesOutput = (output, context) => {
    return {
        LastEvaluatedTableName: expectString(output.LastEvaluatedTableName),
        TableNames: output.TableNames != null ? deserializeAws_json1_0TableNameList(output.TableNames, context) : undefined,
    };
};
const deserializeAws_json1_0ListTagsOfResourceOutput = (output, context) => {
    return {
        NextToken: expectString(output.NextToken),
        Tags: output.Tags != null ? deserializeAws_json1_0TagList(output.Tags, context) : undefined,
    };
};
const deserializeAws_json1_0LocalSecondaryIndexDescription = (output, context) => {
    return {
        IndexArn: expectString(output.IndexArn),
        IndexName: expectString(output.IndexName),
        IndexSizeBytes: expectLong(output.IndexSizeBytes),
        ItemCount: expectLong(output.ItemCount),
        KeySchema: output.KeySchema != null ? deserializeAws_json1_0KeySchema(output.KeySchema, context) : undefined,
        Projection: output.Projection != null ? deserializeAws_json1_0Projection(output.Projection, context) : undefined,
    };
};
const deserializeAws_json1_0LocalSecondaryIndexDescriptionList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0LocalSecondaryIndexDescription(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0LocalSecondaryIndexes = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0LocalSecondaryIndexInfo(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0LocalSecondaryIndexInfo = (output, context) => {
    return {
        IndexName: expectString(output.IndexName),
        KeySchema: output.KeySchema != null ? deserializeAws_json1_0KeySchema(output.KeySchema, context) : undefined,
        Projection: output.Projection != null ? deserializeAws_json1_0Projection(output.Projection, context) : undefined,
    };
};
const deserializeAws_json1_0MapAttributeValue = (output, context) => {
    return Object.entries(output).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: deserializeAws_json1_0AttributeValue(expectUnion(value), context),
        };
    }, {});
};
const deserializeAws_json1_0NonKeyAttributeNameList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return expectString(entry);
    });
    return retVal;
};
const deserializeAws_json1_0NumberSetAttributeValue = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return expectString(entry);
    });
    return retVal;
};
const deserializeAws_json1_0PartiQLBatchResponse = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0BatchStatementResponse(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0PointInTimeRecoveryDescription = (output, context) => {
    return {
        EarliestRestorableDateTime: output.EarliestRestorableDateTime != null
            ? expectNonNull(parseEpochTimestamp(expectNumber(output.EarliestRestorableDateTime)))
            : undefined,
        LatestRestorableDateTime: output.LatestRestorableDateTime != null
            ? expectNonNull(parseEpochTimestamp(expectNumber(output.LatestRestorableDateTime)))
            : undefined,
        PointInTimeRecoveryStatus: expectString(output.PointInTimeRecoveryStatus),
    };
};
const deserializeAws_json1_0PointInTimeRecoveryUnavailableException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0Projection = (output, context) => {
    return {
        NonKeyAttributes: output.NonKeyAttributes != null
            ? deserializeAws_json1_0NonKeyAttributeNameList(output.NonKeyAttributes, context)
            : undefined,
        ProjectionType: expectString(output.ProjectionType),
    };
};
const deserializeAws_json1_0ProvisionedThroughput = (output, context) => {
    return {
        ReadCapacityUnits: expectLong(output.ReadCapacityUnits),
        WriteCapacityUnits: expectLong(output.WriteCapacityUnits),
    };
};
const deserializeAws_json1_0ProvisionedThroughputDescription = (output, context) => {
    return {
        LastDecreaseDateTime: output.LastDecreaseDateTime != null
            ? expectNonNull(parseEpochTimestamp(expectNumber(output.LastDecreaseDateTime)))
            : undefined,
        LastIncreaseDateTime: output.LastIncreaseDateTime != null
            ? expectNonNull(parseEpochTimestamp(expectNumber(output.LastIncreaseDateTime)))
            : undefined,
        NumberOfDecreasesToday: expectLong(output.NumberOfDecreasesToday),
        ReadCapacityUnits: expectLong(output.ReadCapacityUnits),
        WriteCapacityUnits: expectLong(output.WriteCapacityUnits),
    };
};
const deserializeAws_json1_0ProvisionedThroughputExceededException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0ProvisionedThroughputOverride = (output, context) => {
    return {
        ReadCapacityUnits: expectLong(output.ReadCapacityUnits),
    };
};
const deserializeAws_json1_0PutItemInputAttributeMap = (output, context) => {
    return Object.entries(output).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: deserializeAws_json1_0AttributeValue(expectUnion(value), context),
        };
    }, {});
};
const deserializeAws_json1_0PutItemOutput = (output, context) => {
    return {
        Attributes: output.Attributes != null ? deserializeAws_json1_0AttributeMap(output.Attributes, context) : undefined,
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacity(output.ConsumedCapacity, context)
            : undefined,
        ItemCollectionMetrics: output.ItemCollectionMetrics != null
            ? deserializeAws_json1_0ItemCollectionMetrics(output.ItemCollectionMetrics, context)
            : undefined,
    };
};
const deserializeAws_json1_0PutRequest = (output, context) => {
    return {
        Item: output.Item != null ? deserializeAws_json1_0PutItemInputAttributeMap(output.Item, context) : undefined,
    };
};
const deserializeAws_json1_0QueryOutput = (output, context) => {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacity(output.ConsumedCapacity, context)
            : undefined,
        Count: expectInt32(output.Count),
        Items: output.Items != null ? deserializeAws_json1_0ItemList(output.Items, context) : undefined,
        LastEvaluatedKey: output.LastEvaluatedKey != null ? deserializeAws_json1_0Key(output.LastEvaluatedKey, context) : undefined,
        ScannedCount: expectInt32(output.ScannedCount),
    };
};
const deserializeAws_json1_0Replica = (output, context) => {
    return {
        RegionName: expectString(output.RegionName),
    };
};
const deserializeAws_json1_0ReplicaAlreadyExistsException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0ReplicaAutoScalingDescription = (output, context) => {
    return {
        GlobalSecondaryIndexes: output.GlobalSecondaryIndexes != null
            ? deserializeAws_json1_0ReplicaGlobalSecondaryIndexAutoScalingDescriptionList(output.GlobalSecondaryIndexes, context)
            : undefined,
        RegionName: expectString(output.RegionName),
        ReplicaProvisionedReadCapacityAutoScalingSettings: output.ReplicaProvisionedReadCapacityAutoScalingSettings != null
            ? deserializeAws_json1_0AutoScalingSettingsDescription(output.ReplicaProvisionedReadCapacityAutoScalingSettings, context)
            : undefined,
        ReplicaProvisionedWriteCapacityAutoScalingSettings: output.ReplicaProvisionedWriteCapacityAutoScalingSettings != null
            ? deserializeAws_json1_0AutoScalingSettingsDescription(output.ReplicaProvisionedWriteCapacityAutoScalingSettings, context)
            : undefined,
        ReplicaStatus: expectString(output.ReplicaStatus),
    };
};
const deserializeAws_json1_0ReplicaAutoScalingDescriptionList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ReplicaAutoScalingDescription(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0ReplicaDescription = (output, context) => {
    return {
        GlobalSecondaryIndexes: output.GlobalSecondaryIndexes != null
            ? deserializeAws_json1_0ReplicaGlobalSecondaryIndexDescriptionList(output.GlobalSecondaryIndexes, context)
            : undefined,
        KMSMasterKeyId: expectString(output.KMSMasterKeyId),
        ProvisionedThroughputOverride: output.ProvisionedThroughputOverride != null
            ? deserializeAws_json1_0ProvisionedThroughputOverride(output.ProvisionedThroughputOverride, context)
            : undefined,
        RegionName: expectString(output.RegionName),
        ReplicaInaccessibleDateTime: output.ReplicaInaccessibleDateTime != null
            ? expectNonNull(parseEpochTimestamp(expectNumber(output.ReplicaInaccessibleDateTime)))
            : undefined,
        ReplicaStatus: expectString(output.ReplicaStatus),
        ReplicaStatusDescription: expectString(output.ReplicaStatusDescription),
        ReplicaStatusPercentProgress: expectString(output.ReplicaStatusPercentProgress),
        ReplicaTableClassSummary: output.ReplicaTableClassSummary != null
            ? deserializeAws_json1_0TableClassSummary(output.ReplicaTableClassSummary, context)
            : undefined,
    };
};
const deserializeAws_json1_0ReplicaDescriptionList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ReplicaDescription(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0ReplicaGlobalSecondaryIndexAutoScalingDescription = (output, context) => {
    return {
        IndexName: expectString(output.IndexName),
        IndexStatus: expectString(output.IndexStatus),
        ProvisionedReadCapacityAutoScalingSettings: output.ProvisionedReadCapacityAutoScalingSettings != null
            ? deserializeAws_json1_0AutoScalingSettingsDescription(output.ProvisionedReadCapacityAutoScalingSettings, context)
            : undefined,
        ProvisionedWriteCapacityAutoScalingSettings: output.ProvisionedWriteCapacityAutoScalingSettings != null
            ? deserializeAws_json1_0AutoScalingSettingsDescription(output.ProvisionedWriteCapacityAutoScalingSettings, context)
            : undefined,
    };
};
const deserializeAws_json1_0ReplicaGlobalSecondaryIndexAutoScalingDescriptionList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ReplicaGlobalSecondaryIndexAutoScalingDescription(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0ReplicaGlobalSecondaryIndexDescription = (output, context) => {
    return {
        IndexName: expectString(output.IndexName),
        ProvisionedThroughputOverride: output.ProvisionedThroughputOverride != null
            ? deserializeAws_json1_0ProvisionedThroughputOverride(output.ProvisionedThroughputOverride, context)
            : undefined,
    };
};
const deserializeAws_json1_0ReplicaGlobalSecondaryIndexDescriptionList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ReplicaGlobalSecondaryIndexDescription(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0ReplicaGlobalSecondaryIndexSettingsDescription = (output, context) => {
    return {
        IndexName: expectString(output.IndexName),
        IndexStatus: expectString(output.IndexStatus),
        ProvisionedReadCapacityAutoScalingSettings: output.ProvisionedReadCapacityAutoScalingSettings != null
            ? deserializeAws_json1_0AutoScalingSettingsDescription(output.ProvisionedReadCapacityAutoScalingSettings, context)
            : undefined,
        ProvisionedReadCapacityUnits: expectLong(output.ProvisionedReadCapacityUnits),
        ProvisionedWriteCapacityAutoScalingSettings: output.ProvisionedWriteCapacityAutoScalingSettings != null
            ? deserializeAws_json1_0AutoScalingSettingsDescription(output.ProvisionedWriteCapacityAutoScalingSettings, context)
            : undefined,
        ProvisionedWriteCapacityUnits: expectLong(output.ProvisionedWriteCapacityUnits),
    };
};
const deserializeAws_json1_0ReplicaGlobalSecondaryIndexSettingsDescriptionList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ReplicaGlobalSecondaryIndexSettingsDescription(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0ReplicaList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0Replica(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0ReplicaNotFoundException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0ReplicaSettingsDescription = (output, context) => {
    return {
        RegionName: expectString(output.RegionName),
        ReplicaBillingModeSummary: output.ReplicaBillingModeSummary != null
            ? deserializeAws_json1_0BillingModeSummary(output.ReplicaBillingModeSummary, context)
            : undefined,
        ReplicaGlobalSecondaryIndexSettings: output.ReplicaGlobalSecondaryIndexSettings != null
            ? deserializeAws_json1_0ReplicaGlobalSecondaryIndexSettingsDescriptionList(output.ReplicaGlobalSecondaryIndexSettings, context)
            : undefined,
        ReplicaProvisionedReadCapacityAutoScalingSettings: output.ReplicaProvisionedReadCapacityAutoScalingSettings != null
            ? deserializeAws_json1_0AutoScalingSettingsDescription(output.ReplicaProvisionedReadCapacityAutoScalingSettings, context)
            : undefined,
        ReplicaProvisionedReadCapacityUnits: expectLong(output.ReplicaProvisionedReadCapacityUnits),
        ReplicaProvisionedWriteCapacityAutoScalingSettings: output.ReplicaProvisionedWriteCapacityAutoScalingSettings != null
            ? deserializeAws_json1_0AutoScalingSettingsDescription(output.ReplicaProvisionedWriteCapacityAutoScalingSettings, context)
            : undefined,
        ReplicaProvisionedWriteCapacityUnits: expectLong(output.ReplicaProvisionedWriteCapacityUnits),
        ReplicaStatus: expectString(output.ReplicaStatus),
        ReplicaTableClassSummary: output.ReplicaTableClassSummary != null
            ? deserializeAws_json1_0TableClassSummary(output.ReplicaTableClassSummary, context)
            : undefined,
    };
};
const deserializeAws_json1_0ReplicaSettingsDescriptionList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ReplicaSettingsDescription(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0RequestLimitExceeded = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0ResourceInUseException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0ResourceNotFoundException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0RestoreSummary = (output, context) => {
    return {
        RestoreDateTime: output.RestoreDateTime != null
            ? expectNonNull(parseEpochTimestamp(expectNumber(output.RestoreDateTime)))
            : undefined,
        RestoreInProgress: expectBoolean(output.RestoreInProgress),
        SourceBackupArn: expectString(output.SourceBackupArn),
        SourceTableArn: expectString(output.SourceTableArn),
    };
};
const deserializeAws_json1_0RestoreTableFromBackupOutput = (output, context) => {
    return {
        TableDescription: output.TableDescription != null
            ? deserializeAws_json1_0TableDescription(output.TableDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0RestoreTableToPointInTimeOutput = (output, context) => {
    return {
        TableDescription: output.TableDescription != null
            ? deserializeAws_json1_0TableDescription(output.TableDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0S3BucketSource = (output, context) => {
    return {
        S3Bucket: expectString(output.S3Bucket),
        S3BucketOwner: expectString(output.S3BucketOwner),
        S3KeyPrefix: expectString(output.S3KeyPrefix),
    };
};
const deserializeAws_json1_0ScanOutput = (output, context) => {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacity(output.ConsumedCapacity, context)
            : undefined,
        Count: expectInt32(output.Count),
        Items: output.Items != null ? deserializeAws_json1_0ItemList(output.Items, context) : undefined,
        LastEvaluatedKey: output.LastEvaluatedKey != null ? deserializeAws_json1_0Key(output.LastEvaluatedKey, context) : undefined,
        ScannedCount: expectInt32(output.ScannedCount),
    };
};
const deserializeAws_json1_0SecondaryIndexesCapacityMap = (output, context) => {
    return Object.entries(output).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        return {
            ...acc,
            [key]: deserializeAws_json1_0Capacity(value, context),
        };
    }, {});
};
const deserializeAws_json1_0SourceTableDetails = (output, context) => {
    return {
        BillingMode: expectString(output.BillingMode),
        ItemCount: expectLong(output.ItemCount),
        KeySchema: output.KeySchema != null ? deserializeAws_json1_0KeySchema(output.KeySchema, context) : undefined,
        ProvisionedThroughput: output.ProvisionedThroughput != null
            ? deserializeAws_json1_0ProvisionedThroughput(output.ProvisionedThroughput, context)
            : undefined,
        TableArn: expectString(output.TableArn),
        TableCreationDateTime: output.TableCreationDateTime != null
            ? expectNonNull(parseEpochTimestamp(expectNumber(output.TableCreationDateTime)))
            : undefined,
        TableId: expectString(output.TableId),
        TableName: expectString(output.TableName),
        TableSizeBytes: expectLong(output.TableSizeBytes),
    };
};
const deserializeAws_json1_0SourceTableFeatureDetails = (output, context) => {
    return {
        GlobalSecondaryIndexes: output.GlobalSecondaryIndexes != null
            ? deserializeAws_json1_0GlobalSecondaryIndexes(output.GlobalSecondaryIndexes, context)
            : undefined,
        LocalSecondaryIndexes: output.LocalSecondaryIndexes != null
            ? deserializeAws_json1_0LocalSecondaryIndexes(output.LocalSecondaryIndexes, context)
            : undefined,
        SSEDescription: output.SSEDescription != null ? deserializeAws_json1_0SSEDescription(output.SSEDescription, context) : undefined,
        StreamDescription: output.StreamDescription != null
            ? deserializeAws_json1_0StreamSpecification(output.StreamDescription, context)
            : undefined,
        TimeToLiveDescription: output.TimeToLiveDescription != null
            ? deserializeAws_json1_0TimeToLiveDescription(output.TimeToLiveDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0SSEDescription = (output, context) => {
    return {
        InaccessibleEncryptionDateTime: output.InaccessibleEncryptionDateTime != null
            ? expectNonNull(parseEpochTimestamp(expectNumber(output.InaccessibleEncryptionDateTime)))
            : undefined,
        KMSMasterKeyArn: expectString(output.KMSMasterKeyArn),
        SSEType: expectString(output.SSEType),
        Status: expectString(output.Status),
    };
};
const deserializeAws_json1_0SSESpecification = (output, context) => {
    return {
        Enabled: expectBoolean(output.Enabled),
        KMSMasterKeyId: expectString(output.KMSMasterKeyId),
        SSEType: expectString(output.SSEType),
    };
};
const deserializeAws_json1_0StreamSpecification = (output, context) => {
    return {
        StreamEnabled: expectBoolean(output.StreamEnabled),
        StreamViewType: expectString(output.StreamViewType),
    };
};
const deserializeAws_json1_0StringSetAttributeValue = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return expectString(entry);
    });
    return retVal;
};
const deserializeAws_json1_0TableAlreadyExistsException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0TableAutoScalingDescription = (output, context) => {
    return {
        Replicas: output.Replicas != null
            ? deserializeAws_json1_0ReplicaAutoScalingDescriptionList(output.Replicas, context)
            : undefined,
        TableName: expectString(output.TableName),
        TableStatus: expectString(output.TableStatus),
    };
};
const deserializeAws_json1_0TableClassSummary = (output, context) => {
    return {
        LastUpdateDateTime: output.LastUpdateDateTime != null
            ? expectNonNull(parseEpochTimestamp(expectNumber(output.LastUpdateDateTime)))
            : undefined,
        TableClass: expectString(output.TableClass),
    };
};
const deserializeAws_json1_0TableCreationParameters = (output, context) => {
    return {
        AttributeDefinitions: output.AttributeDefinitions != null
            ? deserializeAws_json1_0AttributeDefinitions(output.AttributeDefinitions, context)
            : undefined,
        BillingMode: expectString(output.BillingMode),
        GlobalSecondaryIndexes: output.GlobalSecondaryIndexes != null
            ? deserializeAws_json1_0GlobalSecondaryIndexList(output.GlobalSecondaryIndexes, context)
            : undefined,
        KeySchema: output.KeySchema != null ? deserializeAws_json1_0KeySchema(output.KeySchema, context) : undefined,
        ProvisionedThroughput: output.ProvisionedThroughput != null
            ? deserializeAws_json1_0ProvisionedThroughput(output.ProvisionedThroughput, context)
            : undefined,
        SSESpecification: output.SSESpecification != null
            ? deserializeAws_json1_0SSESpecification(output.SSESpecification, context)
            : undefined,
        TableName: expectString(output.TableName),
    };
};
const deserializeAws_json1_0TableDescription = (output, context) => {
    return {
        ArchivalSummary: output.ArchivalSummary != null
            ? deserializeAws_json1_0ArchivalSummary(output.ArchivalSummary, context)
            : undefined,
        AttributeDefinitions: output.AttributeDefinitions != null
            ? deserializeAws_json1_0AttributeDefinitions(output.AttributeDefinitions, context)
            : undefined,
        BillingModeSummary: output.BillingModeSummary != null
            ? deserializeAws_json1_0BillingModeSummary(output.BillingModeSummary, context)
            : undefined,
        CreationDateTime: output.CreationDateTime != null
            ? expectNonNull(parseEpochTimestamp(expectNumber(output.CreationDateTime)))
            : undefined,
        GlobalSecondaryIndexes: output.GlobalSecondaryIndexes != null
            ? deserializeAws_json1_0GlobalSecondaryIndexDescriptionList(output.GlobalSecondaryIndexes, context)
            : undefined,
        GlobalTableVersion: expectString(output.GlobalTableVersion),
        ItemCount: expectLong(output.ItemCount),
        KeySchema: output.KeySchema != null ? deserializeAws_json1_0KeySchema(output.KeySchema, context) : undefined,
        LatestStreamArn: expectString(output.LatestStreamArn),
        LatestStreamLabel: expectString(output.LatestStreamLabel),
        LocalSecondaryIndexes: output.LocalSecondaryIndexes != null
            ? deserializeAws_json1_0LocalSecondaryIndexDescriptionList(output.LocalSecondaryIndexes, context)
            : undefined,
        ProvisionedThroughput: output.ProvisionedThroughput != null
            ? deserializeAws_json1_0ProvisionedThroughputDescription(output.ProvisionedThroughput, context)
            : undefined,
        Replicas: output.Replicas != null ? deserializeAws_json1_0ReplicaDescriptionList(output.Replicas, context) : undefined,
        RestoreSummary: output.RestoreSummary != null ? deserializeAws_json1_0RestoreSummary(output.RestoreSummary, context) : undefined,
        SSEDescription: output.SSEDescription != null ? deserializeAws_json1_0SSEDescription(output.SSEDescription, context) : undefined,
        StreamSpecification: output.StreamSpecification != null
            ? deserializeAws_json1_0StreamSpecification(output.StreamSpecification, context)
            : undefined,
        TableArn: expectString(output.TableArn),
        TableClassSummary: output.TableClassSummary != null
            ? deserializeAws_json1_0TableClassSummary(output.TableClassSummary, context)
            : undefined,
        TableId: expectString(output.TableId),
        TableName: expectString(output.TableName),
        TableSizeBytes: expectLong(output.TableSizeBytes),
        TableStatus: expectString(output.TableStatus),
    };
};
const deserializeAws_json1_0TableInUseException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0TableNameList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return expectString(entry);
    });
    return retVal;
};
const deserializeAws_json1_0TableNotFoundException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0Tag = (output, context) => {
    return {
        Key: expectString(output.Key),
        Value: expectString(output.Value),
    };
};
const deserializeAws_json1_0TagList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0Tag(entry, context);
    });
    return retVal;
};
const deserializeAws_json1_0TimeToLiveDescription = (output, context) => {
    return {
        AttributeName: expectString(output.AttributeName),
        TimeToLiveStatus: expectString(output.TimeToLiveStatus),
    };
};
const deserializeAws_json1_0TimeToLiveSpecification = (output, context) => {
    return {
        AttributeName: expectString(output.AttributeName),
        Enabled: expectBoolean(output.Enabled),
    };
};
const deserializeAws_json1_0TransactGetItemsOutput = (output, context) => {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacityMultiple(output.ConsumedCapacity, context)
            : undefined,
        Responses: output.Responses != null ? deserializeAws_json1_0ItemResponseList(output.Responses, context) : undefined,
    };
};
const deserializeAws_json1_0TransactionCanceledException = (output, context) => {
    return {
        CancellationReasons: output.CancellationReasons != null
            ? deserializeAws_json1_0CancellationReasonList(output.CancellationReasons, context)
            : undefined,
        Message: expectString(output.Message),
    };
};
const deserializeAws_json1_0TransactionConflictException = (output, context) => {
    return {
        message: expectString(output.message),
    };
};
const deserializeAws_json1_0TransactionInProgressException = (output, context) => {
    return {
        Message: expectString(output.Message),
    };
};
const deserializeAws_json1_0TransactWriteItemsOutput = (output, context) => {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacityMultiple(output.ConsumedCapacity, context)
            : undefined,
        ItemCollectionMetrics: output.ItemCollectionMetrics != null
            ? deserializeAws_json1_0ItemCollectionMetricsPerTable(output.ItemCollectionMetrics, context)
            : undefined,
    };
};
const deserializeAws_json1_0UpdateContinuousBackupsOutput = (output, context) => {
    return {
        ContinuousBackupsDescription: output.ContinuousBackupsDescription != null
            ? deserializeAws_json1_0ContinuousBackupsDescription(output.ContinuousBackupsDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0UpdateContributorInsightsOutput = (output, context) => {
    return {
        ContributorInsightsStatus: expectString(output.ContributorInsightsStatus),
        IndexName: expectString(output.IndexName),
        TableName: expectString(output.TableName),
    };
};
const deserializeAws_json1_0UpdateGlobalTableOutput = (output, context) => {
    return {
        GlobalTableDescription: output.GlobalTableDescription != null
            ? deserializeAws_json1_0GlobalTableDescription(output.GlobalTableDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0UpdateGlobalTableSettingsOutput = (output, context) => {
    return {
        GlobalTableName: expectString(output.GlobalTableName),
        ReplicaSettings: output.ReplicaSettings != null
            ? deserializeAws_json1_0ReplicaSettingsDescriptionList(output.ReplicaSettings, context)
            : undefined,
    };
};
const deserializeAws_json1_0UpdateItemOutput = (output, context) => {
    return {
        Attributes: output.Attributes != null ? deserializeAws_json1_0AttributeMap(output.Attributes, context) : undefined,
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacity(output.ConsumedCapacity, context)
            : undefined,
        ItemCollectionMetrics: output.ItemCollectionMetrics != null
            ? deserializeAws_json1_0ItemCollectionMetrics(output.ItemCollectionMetrics, context)
            : undefined,
    };
};
const deserializeAws_json1_0UpdateTableOutput = (output, context) => {
    return {
        TableDescription: output.TableDescription != null
            ? deserializeAws_json1_0TableDescription(output.TableDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0UpdateTableReplicaAutoScalingOutput = (output, context) => {
    return {
        TableAutoScalingDescription: output.TableAutoScalingDescription != null
            ? deserializeAws_json1_0TableAutoScalingDescription(output.TableAutoScalingDescription, context)
            : undefined,
    };
};
const deserializeAws_json1_0UpdateTimeToLiveOutput = (output, context) => {
    return {
        TimeToLiveSpecification: output.TimeToLiveSpecification != null
            ? deserializeAws_json1_0TimeToLiveSpecification(output.TimeToLiveSpecification, context)
            : undefined,
    };
};
const deserializeAws_json1_0WriteRequest = (output, context) => {
    return {
        DeleteRequest: output.DeleteRequest != null ? deserializeAws_json1_0DeleteRequest(output.DeleteRequest, context) : undefined,
        PutRequest: output.PutRequest != null ? deserializeAws_json1_0PutRequest(output.PutRequest, context) : undefined,
    };
};
const deserializeAws_json1_0WriteRequests = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0WriteRequest(entry, context);
    });
    return retVal;
};
const Aws_json1_0_deserializeMetadata = (output) => ({
    httpStatusCode: output.statusCode,
    requestId: output.headers["x-amzn-requestid"] ?? output.headers["x-amzn-request-id"] ?? output.headers["x-amz-request-id"],
    extendedRequestId: output.headers["x-amz-id-2"],
    cfId: output.headers["x-amz-cf-id"],
});
const collectBody = (streamBody = new Uint8Array(), context) => {
    if (streamBody instanceof Uint8Array) {
        return Promise.resolve(streamBody);
    }
    return context.streamCollector(streamBody) || Promise.resolve(new Uint8Array());
};
const collectBodyString = (streamBody, context) => collectBody(streamBody, context).then((body) => context.utf8Encoder(body));
const buildHttpRpcRequest = async (context, headers, path, resolvedHostname, body) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const contents = {
        protocol,
        hostname,
        port,
        method: "POST",
        path: basePath.endsWith("/") ? basePath.slice(0, -1) + path : basePath + path,
        headers,
    };
    if (resolvedHostname !== undefined) {
        contents.hostname = resolvedHostname;
    }
    if (body !== undefined) {
        contents.body = body;
    }
    return new httpRequest_HttpRequest(contents);
};
const parseBody = (streamBody, context) => collectBodyString(streamBody, context).then((encoded) => {
    if (encoded.length) {
        return JSON.parse(encoded);
    }
    return {};
});
const parseErrorBody = async (errorBody, context) => {
    const value = await parseBody(errorBody, context);
    value.message = value.message ?? value.Message;
    return value;
};
const loadRestJsonErrorCode = (output, data) => {
    const findKey = (object, key) => Object.keys(object).find((k) => k.toLowerCase() === key.toLowerCase());
    const sanitizeErrorCode = (rawValue) => {
        let cleanValue = rawValue;
        if (typeof cleanValue === "number") {
            cleanValue = cleanValue.toString();
        }
        if (cleanValue.indexOf(",") >= 0) {
            cleanValue = cleanValue.split(",")[0];
        }
        if (cleanValue.indexOf(":") >= 0) {
            cleanValue = cleanValue.split(":")[0];
        }
        if (cleanValue.indexOf("#") >= 0) {
            cleanValue = cleanValue.split("#")[1];
        }
        return cleanValue;
    };
    const headerKey = findKey(output.headers, "x-amzn-errortype");
    if (headerKey !== undefined) {
        return sanitizeErrorCode(output.headers[headerKey]);
    }
    if (data.code !== undefined) {
        return sanitizeErrorCode(data.code);
    }
    if (data["__type"] !== undefined) {
        return sanitizeErrorCode(data["__type"]);
    }
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/BatchExecuteStatementCommand.js




class BatchExecuteStatementCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "BatchExecuteStatementCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: BatchExecuteStatementInputFilterSensitiveLog,
            outputFilterSensitiveLog: BatchExecuteStatementOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0BatchExecuteStatementCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0BatchExecuteStatementCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/BatchGetItemCommand.js




class BatchGetItemCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "BatchGetItemCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: BatchGetItemInputFilterSensitiveLog,
            outputFilterSensitiveLog: BatchGetItemOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0BatchGetItemCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0BatchGetItemCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/BatchWriteItemCommand.js




class BatchWriteItemCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "BatchWriteItemCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: BatchWriteItemInputFilterSensitiveLog,
            outputFilterSensitiveLog: BatchWriteItemOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0BatchWriteItemCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0BatchWriteItemCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/CreateBackupCommand.js




class CreateBackupCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "CreateBackupCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: CreateBackupInputFilterSensitiveLog,
            outputFilterSensitiveLog: CreateBackupOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0CreateBackupCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0CreateBackupCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/CreateGlobalTableCommand.js




class CreateGlobalTableCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "CreateGlobalTableCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: CreateGlobalTableInputFilterSensitiveLog,
            outputFilterSensitiveLog: CreateGlobalTableOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0CreateGlobalTableCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0CreateGlobalTableCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/CreateTableCommand.js




class CreateTableCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "CreateTableCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: CreateTableInputFilterSensitiveLog,
            outputFilterSensitiveLog: CreateTableOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0CreateTableCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0CreateTableCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DeleteBackupCommand.js




class DeleteBackupCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "DeleteBackupCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: DeleteBackupInputFilterSensitiveLog,
            outputFilterSensitiveLog: DeleteBackupOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0DeleteBackupCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0DeleteBackupCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DeleteItemCommand.js




class DeleteItemCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "DeleteItemCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: DeleteItemInputFilterSensitiveLog,
            outputFilterSensitiveLog: DeleteItemOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0DeleteItemCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0DeleteItemCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DeleteTableCommand.js




class DeleteTableCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "DeleteTableCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: DeleteTableInputFilterSensitiveLog,
            outputFilterSensitiveLog: DeleteTableOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0DeleteTableCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0DeleteTableCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DescribeBackupCommand.js




class DescribeBackupCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "DescribeBackupCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: DescribeBackupInputFilterSensitiveLog,
            outputFilterSensitiveLog: DescribeBackupOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0DescribeBackupCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0DescribeBackupCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DescribeContinuousBackupsCommand.js




class DescribeContinuousBackupsCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "DescribeContinuousBackupsCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: DescribeContinuousBackupsInputFilterSensitiveLog,
            outputFilterSensitiveLog: DescribeContinuousBackupsOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0DescribeContinuousBackupsCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0DescribeContinuousBackupsCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DescribeContributorInsightsCommand.js




class DescribeContributorInsightsCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "DescribeContributorInsightsCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: DescribeContributorInsightsInputFilterSensitiveLog,
            outputFilterSensitiveLog: DescribeContributorInsightsOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0DescribeContributorInsightsCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0DescribeContributorInsightsCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DescribeEndpointsCommand.js




class DescribeEndpointsCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "DescribeEndpointsCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: DescribeEndpointsRequestFilterSensitiveLog,
            outputFilterSensitiveLog: DescribeEndpointsResponseFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0DescribeEndpointsCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0DescribeEndpointsCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DescribeExportCommand.js




class DescribeExportCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "DescribeExportCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: DescribeExportInputFilterSensitiveLog,
            outputFilterSensitiveLog: DescribeExportOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0DescribeExportCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0DescribeExportCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DescribeGlobalTableCommand.js




class DescribeGlobalTableCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "DescribeGlobalTableCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: DescribeGlobalTableInputFilterSensitiveLog,
            outputFilterSensitiveLog: DescribeGlobalTableOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0DescribeGlobalTableCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0DescribeGlobalTableCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DescribeGlobalTableSettingsCommand.js




class DescribeGlobalTableSettingsCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "DescribeGlobalTableSettingsCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: DescribeGlobalTableSettingsInputFilterSensitiveLog,
            outputFilterSensitiveLog: DescribeGlobalTableSettingsOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0DescribeGlobalTableSettingsCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0DescribeGlobalTableSettingsCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DescribeImportCommand.js




class DescribeImportCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "DescribeImportCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: DescribeImportInputFilterSensitiveLog,
            outputFilterSensitiveLog: DescribeImportOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0DescribeImportCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0DescribeImportCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DescribeKinesisStreamingDestinationCommand.js




class DescribeKinesisStreamingDestinationCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "DescribeKinesisStreamingDestinationCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: DescribeKinesisStreamingDestinationInputFilterSensitiveLog,
            outputFilterSensitiveLog: DescribeKinesisStreamingDestinationOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0DescribeKinesisStreamingDestinationCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0DescribeKinesisStreamingDestinationCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DescribeLimitsCommand.js




class DescribeLimitsCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "DescribeLimitsCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: DescribeLimitsInputFilterSensitiveLog,
            outputFilterSensitiveLog: DescribeLimitsOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0DescribeLimitsCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0DescribeLimitsCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DescribeTableCommand.js




class DescribeTableCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "DescribeTableCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: DescribeTableInputFilterSensitiveLog,
            outputFilterSensitiveLog: DescribeTableOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0DescribeTableCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0DescribeTableCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DescribeTableReplicaAutoScalingCommand.js




class DescribeTableReplicaAutoScalingCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "DescribeTableReplicaAutoScalingCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: DescribeTableReplicaAutoScalingInputFilterSensitiveLog,
            outputFilterSensitiveLog: DescribeTableReplicaAutoScalingOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0DescribeTableReplicaAutoScalingCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0DescribeTableReplicaAutoScalingCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DescribeTimeToLiveCommand.js




class DescribeTimeToLiveCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "DescribeTimeToLiveCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: DescribeTimeToLiveInputFilterSensitiveLog,
            outputFilterSensitiveLog: DescribeTimeToLiveOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0DescribeTimeToLiveCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0DescribeTimeToLiveCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DisableKinesisStreamingDestinationCommand.js




class DisableKinesisStreamingDestinationCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "DisableKinesisStreamingDestinationCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: KinesisStreamingDestinationInputFilterSensitiveLog,
            outputFilterSensitiveLog: KinesisStreamingDestinationOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0DisableKinesisStreamingDestinationCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0DisableKinesisStreamingDestinationCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/EnableKinesisStreamingDestinationCommand.js




class EnableKinesisStreamingDestinationCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "EnableKinesisStreamingDestinationCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: KinesisStreamingDestinationInputFilterSensitiveLog,
            outputFilterSensitiveLog: KinesisStreamingDestinationOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0EnableKinesisStreamingDestinationCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0EnableKinesisStreamingDestinationCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ExecuteStatementCommand.js




class ExecuteStatementCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "ExecuteStatementCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: ExecuteStatementInputFilterSensitiveLog,
            outputFilterSensitiveLog: ExecuteStatementOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0ExecuteStatementCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0ExecuteStatementCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ExecuteTransactionCommand.js




class ExecuteTransactionCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "ExecuteTransactionCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: ExecuteTransactionInputFilterSensitiveLog,
            outputFilterSensitiveLog: ExecuteTransactionOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0ExecuteTransactionCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0ExecuteTransactionCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ExportTableToPointInTimeCommand.js




class ExportTableToPointInTimeCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "ExportTableToPointInTimeCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: ExportTableToPointInTimeInputFilterSensitiveLog,
            outputFilterSensitiveLog: ExportTableToPointInTimeOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0ExportTableToPointInTimeCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0ExportTableToPointInTimeCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/GetItemCommand.js




class GetItemCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "GetItemCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: GetItemInputFilterSensitiveLog,
            outputFilterSensitiveLog: GetItemOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0GetItemCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0GetItemCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ImportTableCommand.js




class ImportTableCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "ImportTableCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: ImportTableInputFilterSensitiveLog,
            outputFilterSensitiveLog: ImportTableOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0ImportTableCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0ImportTableCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ListBackupsCommand.js




class ListBackupsCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "ListBackupsCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: ListBackupsInputFilterSensitiveLog,
            outputFilterSensitiveLog: ListBackupsOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0ListBackupsCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0ListBackupsCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ListContributorInsightsCommand.js




class ListContributorInsightsCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "ListContributorInsightsCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: ListContributorInsightsInputFilterSensitiveLog,
            outputFilterSensitiveLog: ListContributorInsightsOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0ListContributorInsightsCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0ListContributorInsightsCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ListExportsCommand.js




class ListExportsCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "ListExportsCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: ListExportsInputFilterSensitiveLog,
            outputFilterSensitiveLog: ListExportsOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0ListExportsCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0ListExportsCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ListGlobalTablesCommand.js




class ListGlobalTablesCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "ListGlobalTablesCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: ListGlobalTablesInputFilterSensitiveLog,
            outputFilterSensitiveLog: ListGlobalTablesOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0ListGlobalTablesCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0ListGlobalTablesCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ListImportsCommand.js




class ListImportsCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "ListImportsCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: ListImportsInputFilterSensitiveLog,
            outputFilterSensitiveLog: ListImportsOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0ListImportsCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0ListImportsCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ListTablesCommand.js




class ListTablesCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "ListTablesCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: ListTablesInputFilterSensitiveLog,
            outputFilterSensitiveLog: ListTablesOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0ListTablesCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0ListTablesCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ListTagsOfResourceCommand.js




class ListTagsOfResourceCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "ListTagsOfResourceCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: ListTagsOfResourceInputFilterSensitiveLog,
            outputFilterSensitiveLog: ListTagsOfResourceOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0ListTagsOfResourceCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0ListTagsOfResourceCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/PutItemCommand.js




class PutItemCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "PutItemCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: PutItemInputFilterSensitiveLog,
            outputFilterSensitiveLog: PutItemOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0PutItemCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0PutItemCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/QueryCommand.js




class QueryCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "QueryCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: QueryInputFilterSensitiveLog,
            outputFilterSensitiveLog: QueryOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0QueryCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0QueryCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/RestoreTableFromBackupCommand.js




class RestoreTableFromBackupCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "RestoreTableFromBackupCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: RestoreTableFromBackupInputFilterSensitiveLog,
            outputFilterSensitiveLog: RestoreTableFromBackupOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0RestoreTableFromBackupCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0RestoreTableFromBackupCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/RestoreTableToPointInTimeCommand.js




class RestoreTableToPointInTimeCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "RestoreTableToPointInTimeCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: RestoreTableToPointInTimeInputFilterSensitiveLog,
            outputFilterSensitiveLog: RestoreTableToPointInTimeOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0RestoreTableToPointInTimeCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0RestoreTableToPointInTimeCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ScanCommand.js




class ScanCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "ScanCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: ScanInputFilterSensitiveLog,
            outputFilterSensitiveLog: ScanOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0ScanCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0ScanCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/TagResourceCommand.js




class TagResourceCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "TagResourceCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: TagResourceInputFilterSensitiveLog,
            outputFilterSensitiveLog: (output) => output,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0TagResourceCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0TagResourceCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/TransactGetItemsCommand.js




class TransactGetItemsCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "TransactGetItemsCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: TransactGetItemsInputFilterSensitiveLog,
            outputFilterSensitiveLog: TransactGetItemsOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0TransactGetItemsCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0TransactGetItemsCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/TransactWriteItemsCommand.js




class TransactWriteItemsCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "TransactWriteItemsCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: TransactWriteItemsInputFilterSensitiveLog,
            outputFilterSensitiveLog: TransactWriteItemsOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0TransactWriteItemsCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0TransactWriteItemsCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/UntagResourceCommand.js




class UntagResourceCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "UntagResourceCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: UntagResourceInputFilterSensitiveLog,
            outputFilterSensitiveLog: (output) => output,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0UntagResourceCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0UntagResourceCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/UpdateContinuousBackupsCommand.js




class UpdateContinuousBackupsCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "UpdateContinuousBackupsCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: UpdateContinuousBackupsInputFilterSensitiveLog,
            outputFilterSensitiveLog: UpdateContinuousBackupsOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0UpdateContinuousBackupsCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0UpdateContinuousBackupsCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/UpdateContributorInsightsCommand.js




class UpdateContributorInsightsCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "UpdateContributorInsightsCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: UpdateContributorInsightsInputFilterSensitiveLog,
            outputFilterSensitiveLog: UpdateContributorInsightsOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0UpdateContributorInsightsCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0UpdateContributorInsightsCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/UpdateGlobalTableCommand.js




class UpdateGlobalTableCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "UpdateGlobalTableCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: UpdateGlobalTableInputFilterSensitiveLog,
            outputFilterSensitiveLog: UpdateGlobalTableOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0UpdateGlobalTableCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0UpdateGlobalTableCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/UpdateGlobalTableSettingsCommand.js




class UpdateGlobalTableSettingsCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "UpdateGlobalTableSettingsCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: UpdateGlobalTableSettingsInputFilterSensitiveLog,
            outputFilterSensitiveLog: UpdateGlobalTableSettingsOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0UpdateGlobalTableSettingsCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0UpdateGlobalTableSettingsCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/UpdateItemCommand.js




class UpdateItemCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "UpdateItemCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: UpdateItemInputFilterSensitiveLog,
            outputFilterSensitiveLog: UpdateItemOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0UpdateItemCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0UpdateItemCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/UpdateTableCommand.js




class UpdateTableCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "UpdateTableCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: UpdateTableInputFilterSensitiveLog,
            outputFilterSensitiveLog: UpdateTableOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0UpdateTableCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0UpdateTableCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/UpdateTableReplicaAutoScalingCommand.js




class UpdateTableReplicaAutoScalingCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "UpdateTableReplicaAutoScalingCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: UpdateTableReplicaAutoScalingInputFilterSensitiveLog,
            outputFilterSensitiveLog: UpdateTableReplicaAutoScalingOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0UpdateTableReplicaAutoScalingCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0UpdateTableReplicaAutoScalingCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/UpdateTimeToLiveCommand.js




class UpdateTimeToLiveCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "DynamoDBClient";
        const commandName = "UpdateTimeToLiveCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: UpdateTimeToLiveInputFilterSensitiveLog,
            outputFilterSensitiveLog: UpdateTimeToLiveOutputFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_json1_0UpdateTimeToLiveCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_json1_0UpdateTimeToLiveCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-config-provider/dist-es/booleanSelector.js
var SelectorType;
(function (SelectorType) {
    SelectorType["ENV"] = "env";
    SelectorType["CONFIG"] = "shared config entry";
})(SelectorType || (SelectorType = {}));
const booleanSelector = (obj, key, type) => {
    if (!(key in obj))
        return undefined;
    if (obj[key] === "true")
        return true;
    if (obj[key] === "false")
        return false;
    throw new Error(`Cannot load ${type} "${key}". Expected "true" or "false", got ${obj[key]}.`);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-config-provider/dist-es/index.js


;// CONCATENATED MODULE: ../node_modules/@aws-sdk/config-resolver/dist-es/endpointsConfig/NodeUseDualstackEndpointConfigOptions.js

const ENV_USE_DUALSTACK_ENDPOINT = "AWS_USE_DUALSTACK_ENDPOINT";
const CONFIG_USE_DUALSTACK_ENDPOINT = "use_dualstack_endpoint";
const DEFAULT_USE_DUALSTACK_ENDPOINT = false;
const NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS = {
    environmentVariableSelector: (env) => booleanSelector(env, ENV_USE_DUALSTACK_ENDPOINT, SelectorType.ENV),
    configFileSelector: (profile) => booleanSelector(profile, CONFIG_USE_DUALSTACK_ENDPOINT, SelectorType.CONFIG),
    default: false,
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/config-resolver/dist-es/endpointsConfig/NodeUseFipsEndpointConfigOptions.js

const ENV_USE_FIPS_ENDPOINT = "AWS_USE_FIPS_ENDPOINT";
const CONFIG_USE_FIPS_ENDPOINT = "use_fips_endpoint";
const DEFAULT_USE_FIPS_ENDPOINT = false;
const NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS = {
    environmentVariableSelector: (env) => booleanSelector(env, ENV_USE_FIPS_ENDPOINT, SelectorType.ENV),
    configFileSelector: (profile) => booleanSelector(profile, CONFIG_USE_FIPS_ENDPOINT, SelectorType.CONFIG),
    default: false,
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-middleware/dist-es/normalizeProvider.js
const normalizeProvider_normalizeProvider = (input) => {
    if (typeof input === "function")
        return input;
    const promisified = Promise.resolve(input);
    return () => promisified;
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/config-resolver/dist-es/endpointsConfig/utils/getEndpointFromRegion.js
const getEndpointFromRegion = async (input) => {
    const { tls = true } = input;
    const region = await input.region();
    const dnsHostRegex = new RegExp(/^([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9])$/);
    if (!dnsHostRegex.test(region)) {
        throw new Error("Invalid region in client config");
    }
    const useDualstackEndpoint = await input.useDualstackEndpoint();
    const useFipsEndpoint = await input.useFipsEndpoint();
    const { hostname } = (await input.regionInfoProvider(region, { useDualstackEndpoint, useFipsEndpoint })) ?? {};
    if (!hostname) {
        throw new Error("Cannot resolve hostname from client config");
    }
    return input.urlParser(`${tls ? "https:" : "http:"}//${hostname}`);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/config-resolver/dist-es/endpointsConfig/resolveEndpointsConfig.js


const resolveEndpointsConfig = (input) => {
    const useDualstackEndpoint = normalizeProvider_normalizeProvider(input.useDualstackEndpoint);
    const { endpoint, useFipsEndpoint, urlParser } = input;
    return {
        ...input,
        tls: input.tls ?? true,
        endpoint: endpoint
            ? normalizeProvider_normalizeProvider(typeof endpoint === "string" ? urlParser(endpoint) : endpoint)
            : () => getEndpointFromRegion({ ...input, useDualstackEndpoint, useFipsEndpoint }),
        isCustomEndpoint: !!endpoint,
        useDualstackEndpoint,
    };
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/config-resolver/dist-es/endpointsConfig/index.js





;// CONCATENATED MODULE: ../node_modules/@aws-sdk/config-resolver/dist-es/regionConfig/config.js
const REGION_ENV_NAME = "AWS_REGION";
const REGION_INI_NAME = "region";
const NODE_REGION_CONFIG_OPTIONS = {
    environmentVariableSelector: (env) => env[REGION_ENV_NAME],
    configFileSelector: (profile) => profile[REGION_INI_NAME],
    default: () => {
        throw new Error("Region is missing");
    },
};
const NODE_REGION_CONFIG_FILE_OPTIONS = {
    preferredFile: "credentials",
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/config-resolver/dist-es/regionConfig/isFipsRegion.js
const isFipsRegion = (region) => typeof region === "string" && (region.startsWith("fips-") || region.endsWith("-fips"));

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/config-resolver/dist-es/regionConfig/getRealRegion.js

const getRealRegion = (region) => isFipsRegion(region)
    ? ["fips-aws-global", "aws-fips"].includes(region)
        ? "us-east-1"
        : region.replace(/fips-(dkr-|prod-)?|-fips/, "")
    : region;

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/config-resolver/dist-es/regionConfig/resolveRegionConfig.js


const resolveRegionConfig = (input) => {
    const { region, useFipsEndpoint } = input;
    if (!region) {
        throw new Error("Region is missing");
    }
    return {
        ...input,
        region: async () => {
            if (typeof region === "string") {
                return getRealRegion(region);
            }
            const providedRegion = await region();
            return getRealRegion(providedRegion);
        },
        useFipsEndpoint: async () => {
            const providedRegion = typeof region === "string" ? region : await region();
            if (isFipsRegion(providedRegion)) {
                return true;
            }
            return typeof useFipsEndpoint === "boolean" ? Promise.resolve(useFipsEndpoint) : useFipsEndpoint();
        },
    };
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/config-resolver/dist-es/regionConfig/index.js



;// CONCATENATED MODULE: ../node_modules/@aws-sdk/config-resolver/dist-es/regionInfo/getHostnameFromVariants.js
const getHostnameFromVariants = (variants = [], { useFipsEndpoint, useDualstackEndpoint }) => variants.find(({ tags }) => useFipsEndpoint === tags.includes("fips") && useDualstackEndpoint === tags.includes("dualstack"))?.hostname;

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/config-resolver/dist-es/regionInfo/getResolvedHostname.js
const getResolvedHostname = (resolvedRegion, { regionHostname, partitionHostname }) => regionHostname
    ? regionHostname
    : partitionHostname
        ? partitionHostname.replace("{region}", resolvedRegion)
        : undefined;

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/config-resolver/dist-es/regionInfo/getResolvedPartition.js
const getResolvedPartition = (region, { partitionHash }) => Object.keys(partitionHash || {}).find((key) => partitionHash[key].regions.includes(region)) ?? "aws";

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/config-resolver/dist-es/regionInfo/getResolvedSigningRegion.js
const getResolvedSigningRegion = (hostname, { signingRegion, regionRegex, useFipsEndpoint }) => {
    if (signingRegion) {
        return signingRegion;
    }
    else if (useFipsEndpoint) {
        const regionRegexJs = regionRegex.replace("\\\\", "\\").replace(/^\^/g, "\\.").replace(/\$$/g, "\\.");
        const regionRegexmatchArray = hostname.match(regionRegexJs);
        if (regionRegexmatchArray) {
            return regionRegexmatchArray[0].slice(1, -1);
        }
    }
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/config-resolver/dist-es/regionInfo/getRegionInfo.js




const getRegionInfo = (region, { useFipsEndpoint = false, useDualstackEndpoint = false, signingService, regionHash, partitionHash, }) => {
    const partition = getResolvedPartition(region, { partitionHash });
    const resolvedRegion = region in regionHash ? region : partitionHash[partition]?.endpoint ?? region;
    const hostnameOptions = { useFipsEndpoint, useDualstackEndpoint };
    const regionHostname = getHostnameFromVariants(regionHash[resolvedRegion]?.variants, hostnameOptions);
    const partitionHostname = getHostnameFromVariants(partitionHash[partition]?.variants, hostnameOptions);
    const hostname = getResolvedHostname(resolvedRegion, { regionHostname, partitionHostname });
    if (hostname === undefined) {
        throw new Error(`Endpoint resolution failed for: ${{ resolvedRegion, useFipsEndpoint, useDualstackEndpoint }}`);
    }
    const signingRegion = getResolvedSigningRegion(hostname, {
        signingRegion: regionHash[resolvedRegion]?.signingRegion,
        regionRegex: partitionHash[partition].regionRegex,
        useFipsEndpoint,
    });
    return {
        partition,
        signingService,
        hostname,
        ...(signingRegion && { signingRegion }),
        ...(regionHash[resolvedRegion]?.signingService && {
            signingService: regionHash[resolvedRegion].signingService,
        }),
    };
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/config-resolver/dist-es/regionInfo/index.js




;// CONCATENATED MODULE: ../node_modules/@aws-sdk/config-resolver/dist-es/index.js




;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-content-length/dist-es/index.js

const CONTENT_LENGTH_HEADER = "content-length";
function contentLengthMiddleware(bodyLengthChecker) {
    return (next) => async (args) => {
        const request = args.request;
        if (httpRequest_HttpRequest.isInstance(request)) {
            const { body, headers } = request;
            if (body &&
                Object.keys(headers)
                    .map((str) => str.toLowerCase())
                    .indexOf(CONTENT_LENGTH_HEADER) === -1) {
                try {
                    const length = bodyLengthChecker(body);
                    request.headers = {
                        ...request.headers,
                        [CONTENT_LENGTH_HEADER]: String(length),
                    };
                }
                catch (error) {
                }
            }
        }
        return next({
            ...args,
            request,
        });
    };
}
const contentLengthMiddlewareOptions = {
    step: "build",
    tags: ["SET_CONTENT_LENGTH", "CONTENT_LENGTH"],
    name: "contentLengthMiddleware",
    override: true,
};
const getContentLengthPlugin = (options) => ({
    applyToStack: (clientStack) => {
        clientStack.add(contentLengthMiddleware(options.bodyLengthChecker), contentLengthMiddlewareOptions);
    },
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-endpoint-discovery/dist-es/configurations.js
const ENV_ENDPOINT_DISCOVERY = ["AWS_ENABLE_ENDPOINT_DISCOVERY", "AWS_ENDPOINT_DISCOVERY_ENABLED"];
const CONFIG_ENDPOINT_DISCOVERY = "endpoint_discovery_enabled";
const isFalsy = (value) => ["false", "0"].indexOf(value) >= 0;
const NODE_ENDPOINT_DISCOVERY_CONFIG_OPTIONS = {
    environmentVariableSelector: (env) => {
        for (let i = 0; i < ENV_ENDPOINT_DISCOVERY.length; i++) {
            const envKey = ENV_ENDPOINT_DISCOVERY[i];
            if (envKey in env) {
                const value = env[envKey];
                if (value === "") {
                    throw Error(`Environment variable ${envKey} can't be empty of undefined, got "${value}"`);
                }
                return !isFalsy(value);
            }
        }
    },
    configFileSelector: (profile) => {
        if (CONFIG_ENDPOINT_DISCOVERY in profile) {
            const value = profile[CONFIG_ENDPOINT_DISCOVERY];
            if (value === undefined) {
                throw Error(`Shared config entry ${CONFIG_ENDPOINT_DISCOVERY} can't be undefined, got "${value}"`);
            }
            return !isFalsy(value);
        }
    },
    default: undefined,
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-endpoint-discovery/dist-es/updateDiscoveredEndpointInCache.js
const requestQueue = {};
const updateDiscoveredEndpointInCache_updateDiscoveredEndpointInCache = async (config, options) => new Promise((resolve, reject) => {
    const { endpointCache } = config;
    const { cacheKey, commandName, identifiers } = options;
    const endpoints = endpointCache.get(cacheKey);
    if (endpoints && endpoints.length === 1 && endpoints[0].Address === "") {
        if (options.isDiscoveredEndpointRequired) {
            if (!requestQueue[cacheKey])
                requestQueue[cacheKey] = [];
            requestQueue[cacheKey].push({ resolve, reject });
        }
        else {
            resolve();
        }
    }
    else if (endpoints && endpoints.length > 0) {
        resolve();
    }
    else {
        const placeholderEndpoints = [{ Address: "", CachePeriodInMinutes: 1 }];
        endpointCache.set(cacheKey, placeholderEndpoints);
        const command = new options.endpointDiscoveryCommandCtor({
            Operation: commandName.slice(0, -7),
            Identifiers: identifiers,
        });
        const handler = command.resolveMiddleware(options.clientStack, config, options.options);
        handler(command)
            .then((result) => {
            endpointCache.set(cacheKey, result.output.Endpoints);
            if (requestQueue[cacheKey]) {
                requestQueue[cacheKey].forEach(({ resolve }) => {
                    resolve();
                });
                delete requestQueue[cacheKey];
            }
            resolve();
        })
            .catch((error) => {
            endpointCache.delete(cacheKey);
            const errorToThrow = Object.assign(new Error(`The operation to discover endpoint failed.` +
                ` Please retry, or provide a custom endpoint and disable endpoint discovery to proceed.`), { reason: error });
            if (requestQueue[cacheKey]) {
                requestQueue[cacheKey].forEach(({ reject }) => {
                    reject(errorToThrow);
                });
                delete requestQueue[cacheKey];
            }
            if (options.isDiscoveredEndpointRequired) {
                reject(errorToThrow);
            }
            else {
                endpointCache.set(cacheKey, placeholderEndpoints);
                resolve();
            }
        });
    }
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-endpoint-discovery/dist-es/endpointDiscoveryMiddleware.js



const endpointDiscoveryMiddleware_endpointDiscoveryMiddleware = (config, middlewareConfig) => (next, context) => async (args) => {
    if (config.isCustomEndpoint) {
        if (config.isClientEndpointDiscoveryEnabled) {
            throw new Error(`Custom endpoint is supplied; endpointDiscoveryEnabled must not be true.`);
        }
        return next(args);
    }
    const { endpointDiscoveryCommandCtor } = config;
    const { isDiscoveredEndpointRequired, identifiers } = middlewareConfig;
    const { clientName, commandName } = context;
    const isEndpointDiscoveryEnabled = await config.endpointDiscoveryEnabled();
    const cacheKey = await getCacheKey(commandName, config, { identifiers });
    if (isDiscoveredEndpointRequired) {
        if (isEndpointDiscoveryEnabled === false) {
            throw new Error(`Endpoint Discovery is disabled but ${commandName} on ${clientName} requires it.` +
                ` Please check your configurations.`);
        }
        await updateDiscoveredEndpointInCache(config, {
            ...middlewareConfig,
            commandName,
            cacheKey,
            endpointDiscoveryCommandCtor,
        });
    }
    else if (isEndpointDiscoveryEnabled) {
        updateDiscoveredEndpointInCache(config, {
            ...middlewareConfig,
            commandName,
            cacheKey,
            endpointDiscoveryCommandCtor,
        });
    }
    const { request } = args;
    if (cacheKey && HttpRequest.isInstance(request)) {
        const endpoint = config.endpointCache.getEndpoint(cacheKey);
        if (endpoint) {
            request.hostname = endpoint;
        }
    }
    return next(args);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-endpoint-discovery/dist-es/getEndpointDiscoveryPlugin.js

const endpointDiscoveryMiddlewareOptions = {
    name: "endpointDiscoveryMiddleware",
    step: "build",
    tags: ["ENDPOINT_DISCOVERY"],
    override: true,
};
const getEndpointDiscoveryPlugin = (pluginConfig, middlewareConfig) => ({
    applyToStack: (commandStack) => {
        commandStack.add(endpointDiscoveryMiddleware(pluginConfig, middlewareConfig), endpointDiscoveryMiddlewareOptions);
    },
});
const getEndpointDiscoveryRequiredPlugin = (pluginConfig, middlewareConfig) => ({
    applyToStack: (commandStack) => {
        commandStack.add(endpointDiscoveryMiddleware(pluginConfig, { ...middlewareConfig, isDiscoveredEndpointRequired: true }), endpointDiscoveryMiddlewareOptions);
    },
});
const getEndpointDiscoveryOptionalPlugin = (pluginConfig, middlewareConfig) => ({
    applyToStack: (commandStack) => {
        commandStack.add(endpointDiscoveryMiddleware(pluginConfig, { ...middlewareConfig, isDiscoveredEndpointRequired: false }), endpointDiscoveryMiddlewareOptions);
    },
});

// EXTERNAL MODULE: ../node_modules/mnemonist/lru-cache.js
var lru_cache = __webpack_require__(187);
var lru_cache_default = /*#__PURE__*/__webpack_require__.n(lru_cache);
;// CONCATENATED MODULE: ../node_modules/@aws-sdk/endpoint-cache/dist-es/EndpointCache.js

class EndpointCache {
    constructor(capacity) {
        this.cache = new (lru_cache_default())(capacity);
    }
    getEndpoint(key) {
        const endpointsWithExpiry = this.get(key);
        if (!endpointsWithExpiry || endpointsWithExpiry.length === 0) {
            return undefined;
        }
        const endpoints = endpointsWithExpiry.map((endpoint) => endpoint.Address);
        return endpoints[Math.floor(Math.random() * endpoints.length)];
    }
    get(key) {
        if (!this.has(key)) {
            return;
        }
        const value = this.cache.get(key);
        if (!value) {
            return;
        }
        const now = Date.now();
        const endpointsWithExpiry = value.filter((endpoint) => now < endpoint.Expires);
        if (endpointsWithExpiry.length === 0) {
            this.delete(key);
            return undefined;
        }
        return endpointsWithExpiry;
    }
    set(key, endpoints) {
        const now = Date.now();
        this.cache.set(key, endpoints.map(({ Address, CachePeriodInMinutes }) => ({
            Address,
            Expires: now + CachePeriodInMinutes * 60 * 1000,
        })));
    }
    delete(key) {
        this.cache.set(key, []);
    }
    has(key) {
        if (!this.cache.has(key)) {
            return false;
        }
        const endpoints = this.cache.peek(key);
        if (!endpoints) {
            return false;
        }
        return endpoints.length > 0;
    }
    clear() {
        this.cache.clear();
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/endpoint-cache/dist-es/index.js



;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-endpoint-discovery/dist-es/resolveEndpointDiscoveryConfig.js

const resolveEndpointDiscoveryConfig = (input, { endpointDiscoveryCommandCtor }) => ({
    ...input,
    endpointDiscoveryCommandCtor,
    endpointCache: new EndpointCache(input.endpointCacheSize ?? 1000),
    endpointDiscoveryEnabled: input.endpointDiscoveryEnabled !== undefined
        ? () => Promise.resolve(input.endpointDiscoveryEnabled)
        : input.endpointDiscoveryEnabledProvider,
    isClientEndpointDiscoveryEnabled: input.endpointDiscoveryEnabled !== undefined,
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-endpoint-discovery/dist-es/index.js




;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-host-header/dist-es/index.js

function resolveHostHeaderConfig(input) {
    return input;
}
const hostHeaderMiddleware = (options) => (next) => async (args) => {
    if (!httpRequest_HttpRequest.isInstance(args.request))
        return next(args);
    const { request } = args;
    const { handlerProtocol = "" } = options.requestHandler.metadata || {};
    if (handlerProtocol.indexOf("h2") >= 0 && !request.headers[":authority"]) {
        delete request.headers["host"];
        request.headers[":authority"] = "";
    }
    else if (!request.headers["host"]) {
        request.headers["host"] = request.hostname;
    }
    return next(args);
};
const hostHeaderMiddlewareOptions = {
    name: "hostHeaderMiddleware",
    step: "build",
    priority: "low",
    tags: ["HOST"],
    override: true,
};
const getHostHeaderPlugin = (options) => ({
    applyToStack: (clientStack) => {
        clientStack.add(hostHeaderMiddleware(options), hostHeaderMiddlewareOptions);
    },
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-logger/dist-es/loggerMiddleware.js
const loggerMiddleware = () => (next, context) => async (args) => {
    const { clientName, commandName, inputFilterSensitiveLog, logger, outputFilterSensitiveLog } = context;
    const response = await next(args);
    if (!logger) {
        return response;
    }
    if (typeof logger.info === "function") {
        const { $metadata, ...outputWithoutMetadata } = response.output;
        logger.info({
            clientName,
            commandName,
            input: inputFilterSensitiveLog(args.input),
            output: outputFilterSensitiveLog(outputWithoutMetadata),
            metadata: $metadata,
        });
    }
    return response;
};
const loggerMiddlewareOptions = {
    name: "loggerMiddleware",
    tags: ["LOGGER"],
    step: "initialize",
    override: true,
};
const getLoggerPlugin = (options) => ({
    applyToStack: (clientStack) => {
        clientStack.add(loggerMiddleware(), loggerMiddlewareOptions);
    },
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-logger/dist-es/index.js


;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-recursion-detection/dist-es/index.js

const TRACE_ID_HEADER_NAME = "X-Amzn-Trace-Id";
const ENV_LAMBDA_FUNCTION_NAME = "AWS_LAMBDA_FUNCTION_NAME";
const ENV_TRACE_ID = "_X_AMZN_TRACE_ID";
const recursionDetectionMiddleware = (options) => (next) => async (args) => {
    const { request } = args;
    if (!httpRequest_HttpRequest.isInstance(request) ||
        options.runtime !== "node" ||
        request.headers.hasOwnProperty(TRACE_ID_HEADER_NAME)) {
        return next(args);
    }
    const functionName = process.env[ENV_LAMBDA_FUNCTION_NAME];
    const traceId = process.env[ENV_TRACE_ID];
    const nonEmptyString = (str) => typeof str === "string" && str.length > 0;
    if (nonEmptyString(functionName) && nonEmptyString(traceId)) {
        request.headers[TRACE_ID_HEADER_NAME] = traceId;
    }
    return next({
        ...args,
        request,
    });
};
const addRecursionDetectionMiddlewareOptions = {
    step: "build",
    tags: ["RECURSION_DETECTION"],
    name: "recursionDetectionMiddleware",
    override: true,
    priority: "low",
};
const getRecursionDetectionPlugin = (options) => ({
    applyToStack: (clientStack) => {
        clientStack.add(recursionDetectionMiddleware(options), addRecursionDetectionMiddlewareOptions);
    },
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-retry/dist-es/config.js
var RETRY_MODES;
(function (RETRY_MODES) {
    RETRY_MODES["STANDARD"] = "standard";
    RETRY_MODES["ADAPTIVE"] = "adaptive";
})(RETRY_MODES || (RETRY_MODES = {}));
const DEFAULT_MAX_ATTEMPTS = 3;
const DEFAULT_RETRY_MODE = RETRY_MODES.STANDARD;

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/service-error-classification/dist-es/constants.js
const CLOCK_SKEW_ERROR_CODES = [
    "AuthFailure",
    "InvalidSignatureException",
    "RequestExpired",
    "RequestInTheFuture",
    "RequestTimeTooSkewed",
    "SignatureDoesNotMatch",
];
const THROTTLING_ERROR_CODES = [
    "BandwidthLimitExceeded",
    "EC2ThrottledException",
    "LimitExceededException",
    "PriorRequestNotComplete",
    "ProvisionedThroughputExceededException",
    "RequestLimitExceeded",
    "RequestThrottled",
    "RequestThrottledException",
    "SlowDown",
    "ThrottledException",
    "Throttling",
    "ThrottlingException",
    "TooManyRequestsException",
    "TransactionInProgressException",
];
const TRANSIENT_ERROR_CODES = ["AbortError", "TimeoutError", "RequestTimeout", "RequestTimeoutException"];
const TRANSIENT_ERROR_STATUS_CODES = [500, 502, 503, 504];
const NODEJS_TIMEOUT_ERROR_CODES = ["ECONNRESET", "EPIPE", "ETIMEDOUT"];

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/service-error-classification/dist-es/index.js

const isRetryableByTrait = (error) => error.$retryable !== undefined;
const isClockSkewError = (error) => CLOCK_SKEW_ERROR_CODES.includes(error.name);
const isThrottlingError = (error) => error.$metadata?.httpStatusCode === 429 ||
    THROTTLING_ERROR_CODES.includes(error.name) ||
    error.$retryable?.throttling == true;
const isTransientError = (error) => TRANSIENT_ERROR_CODES.includes(error.name) ||
    NODEJS_TIMEOUT_ERROR_CODES.includes(error?.code || "") ||
    TRANSIENT_ERROR_STATUS_CODES.includes(error.$metadata?.httpStatusCode || 0);

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-retry/dist-es/DefaultRateLimiter.js

class DefaultRateLimiter {
    constructor(options) {
        this.currentCapacity = 0;
        this.enabled = false;
        this.lastMaxRate = 0;
        this.measuredTxRate = 0;
        this.requestCount = 0;
        this.lastTimestamp = 0;
        this.timeWindow = 0;
        this.beta = options?.beta ?? 0.7;
        this.minCapacity = options?.minCapacity ?? 1;
        this.minFillRate = options?.minFillRate ?? 0.5;
        this.scaleConstant = options?.scaleConstant ?? 0.4;
        this.smooth = options?.smooth ?? 0.8;
        const currentTimeInSeconds = this.getCurrentTimeInSeconds();
        this.lastThrottleTime = currentTimeInSeconds;
        this.lastTxRateBucket = Math.floor(this.getCurrentTimeInSeconds());
        this.fillRate = this.minFillRate;
        this.maxCapacity = this.minCapacity;
    }
    getCurrentTimeInSeconds() {
        return Date.now() / 1000;
    }
    async getSendToken() {
        return this.acquireTokenBucket(1);
    }
    async acquireTokenBucket(amount) {
        if (!this.enabled) {
            return;
        }
        this.refillTokenBucket();
        if (amount > this.currentCapacity) {
            const delay = ((amount - this.currentCapacity) / this.fillRate) * 1000;
            await new Promise((resolve) => setTimeout(resolve, delay));
        }
        this.currentCapacity = this.currentCapacity - amount;
    }
    refillTokenBucket() {
        const timestamp = this.getCurrentTimeInSeconds();
        if (!this.lastTimestamp) {
            this.lastTimestamp = timestamp;
            return;
        }
        const fillAmount = (timestamp - this.lastTimestamp) * this.fillRate;
        this.currentCapacity = Math.min(this.maxCapacity, this.currentCapacity + fillAmount);
        this.lastTimestamp = timestamp;
    }
    updateClientSendingRate(response) {
        let calculatedRate;
        this.updateMeasuredRate();
        if (isThrottlingError(response)) {
            const rateToUse = !this.enabled ? this.measuredTxRate : Math.min(this.measuredTxRate, this.fillRate);
            this.lastMaxRate = rateToUse;
            this.calculateTimeWindow();
            this.lastThrottleTime = this.getCurrentTimeInSeconds();
            calculatedRate = this.cubicThrottle(rateToUse);
            this.enableTokenBucket();
        }
        else {
            this.calculateTimeWindow();
            calculatedRate = this.cubicSuccess(this.getCurrentTimeInSeconds());
        }
        const newRate = Math.min(calculatedRate, 2 * this.measuredTxRate);
        this.updateTokenBucketRate(newRate);
    }
    calculateTimeWindow() {
        this.timeWindow = this.getPrecise(Math.pow((this.lastMaxRate * (1 - this.beta)) / this.scaleConstant, 1 / 3));
    }
    cubicThrottle(rateToUse) {
        return this.getPrecise(rateToUse * this.beta);
    }
    cubicSuccess(timestamp) {
        return this.getPrecise(this.scaleConstant * Math.pow(timestamp - this.lastThrottleTime - this.timeWindow, 3) + this.lastMaxRate);
    }
    enableTokenBucket() {
        this.enabled = true;
    }
    updateTokenBucketRate(newRate) {
        this.refillTokenBucket();
        this.fillRate = Math.max(newRate, this.minFillRate);
        this.maxCapacity = Math.max(newRate, this.minCapacity);
        this.currentCapacity = Math.min(this.currentCapacity, this.maxCapacity);
    }
    updateMeasuredRate() {
        const t = this.getCurrentTimeInSeconds();
        const timeBucket = Math.floor(t * 2) / 2;
        this.requestCount++;
        if (timeBucket > this.lastTxRateBucket) {
            const currentRate = this.requestCount / (timeBucket - this.lastTxRateBucket);
            this.measuredTxRate = this.getPrecise(currentRate * this.smooth + this.measuredTxRate * (1 - this.smooth));
            this.requestCount = 0;
            this.lastTxRateBucket = timeBucket;
        }
    }
    getPrecise(num) {
        return parseFloat(num.toFixed(8));
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/protocol-http/dist-es/httpResponse.js
class httpResponse_HttpResponse {
    constructor(options) {
        this.statusCode = options.statusCode;
        this.headers = options.headers || {};
        this.body = options.body;
    }
    static isInstance(response) {
        if (!response)
            return false;
        const resp = response;
        return typeof resp.statusCode === "number" && typeof resp.headers === "object";
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-retry/dist-es/constants.js
const DEFAULT_RETRY_DELAY_BASE = 100;
const MAXIMUM_RETRY_DELAY = 20 * 1000;
const THROTTLING_RETRY_DELAY_BASE = 500;
const INITIAL_RETRY_TOKENS = 500;
const RETRY_COST = 5;
const TIMEOUT_RETRY_COST = 10;
const NO_RETRY_INCREMENT = 1;
const constants_INVOCATION_ID_HEADER = "amz-sdk-invocation-id";
const constants_REQUEST_HEADER = "amz-sdk-request";

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-retry/dist-es/defaultRetryQuota.js

const getDefaultRetryQuota = (initialRetryTokens, options) => {
    const MAX_CAPACITY = initialRetryTokens;
    const noRetryIncrement = options?.noRetryIncrement ?? NO_RETRY_INCREMENT;
    const retryCost = options?.retryCost ?? RETRY_COST;
    const timeoutRetryCost = options?.timeoutRetryCost ?? TIMEOUT_RETRY_COST;
    let availableCapacity = initialRetryTokens;
    const getCapacityAmount = (error) => (error.name === "TimeoutError" ? timeoutRetryCost : retryCost);
    const hasRetryTokens = (error) => getCapacityAmount(error) <= availableCapacity;
    const retrieveRetryTokens = (error) => {
        if (!hasRetryTokens(error)) {
            throw new Error("No retry token available");
        }
        const capacityAmount = getCapacityAmount(error);
        availableCapacity -= capacityAmount;
        return capacityAmount;
    };
    const releaseRetryTokens = (capacityReleaseAmount) => {
        availableCapacity += capacityReleaseAmount ?? noRetryIncrement;
        availableCapacity = Math.min(availableCapacity, MAX_CAPACITY);
    };
    return Object.freeze({
        hasRetryTokens,
        retrieveRetryTokens,
        releaseRetryTokens,
    });
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-retry/dist-es/delayDecider.js

const defaultDelayDecider = (delayBase, attempts) => Math.floor(Math.min(MAXIMUM_RETRY_DELAY, Math.random() * 2 ** attempts * delayBase));

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-retry/dist-es/retryDecider.js

const defaultRetryDecider = (error) => {
    if (!error) {
        return false;
    }
    return isRetryableByTrait(error) || isClockSkewError(error) || isThrottlingError(error) || isTransientError(error);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-retry/dist-es/StandardRetryStrategy.js








class StandardRetryStrategy {
    constructor(maxAttemptsProvider, options) {
        this.maxAttemptsProvider = maxAttemptsProvider;
        this.mode = RETRY_MODES.STANDARD;
        this.retryDecider = options?.retryDecider ?? defaultRetryDecider;
        this.delayDecider = options?.delayDecider ?? defaultDelayDecider;
        this.retryQuota = options?.retryQuota ?? getDefaultRetryQuota(INITIAL_RETRY_TOKENS);
    }
    shouldRetry(error, attempts, maxAttempts) {
        return attempts < maxAttempts && this.retryDecider(error) && this.retryQuota.hasRetryTokens(error);
    }
    async getMaxAttempts() {
        let maxAttempts;
        try {
            maxAttempts = await this.maxAttemptsProvider();
        }
        catch (error) {
            maxAttempts = DEFAULT_MAX_ATTEMPTS;
        }
        return maxAttempts;
    }
    async retry(next, args, options) {
        let retryTokenAmount;
        let attempts = 0;
        let totalDelay = 0;
        const maxAttempts = await this.getMaxAttempts();
        const { request } = args;
        if (httpRequest_HttpRequest.isInstance(request)) {
            request.headers[constants_INVOCATION_ID_HEADER] = esm_node_v4();
        }
        while (true) {
            try {
                if (httpRequest_HttpRequest.isInstance(request)) {
                    request.headers[constants_REQUEST_HEADER] = `attempt=${attempts + 1}; max=${maxAttempts}`;
                }
                if (options?.beforeRequest) {
                    await options.beforeRequest();
                }
                const { response, output } = await next(args);
                if (options?.afterRequest) {
                    options.afterRequest(response);
                }
                this.retryQuota.releaseRetryTokens(retryTokenAmount);
                output.$metadata.attempts = attempts + 1;
                output.$metadata.totalRetryDelay = totalDelay;
                return { response, output };
            }
            catch (e) {
                const err = asSdkError(e);
                attempts++;
                if (this.shouldRetry(err, attempts, maxAttempts)) {
                    retryTokenAmount = this.retryQuota.retrieveRetryTokens(err);
                    const delayFromDecider = this.delayDecider(isThrottlingError(err) ? THROTTLING_RETRY_DELAY_BASE : DEFAULT_RETRY_DELAY_BASE, attempts);
                    const delayFromResponse = getDelayFromRetryAfterHeader(err.$response);
                    const delay = Math.max(delayFromResponse || 0, delayFromDecider);
                    totalDelay += delay;
                    await new Promise((resolve) => setTimeout(resolve, delay));
                    continue;
                }
                if (!err.$metadata) {
                    err.$metadata = {};
                }
                err.$metadata.attempts = attempts;
                err.$metadata.totalRetryDelay = totalDelay;
                throw err;
            }
        }
    }
}
const getDelayFromRetryAfterHeader = (response) => {
    if (!httpResponse_HttpResponse.isInstance(response))
        return;
    const retryAfterHeaderName = Object.keys(response.headers).find((key) => key.toLowerCase() === "retry-after");
    if (!retryAfterHeaderName)
        return;
    const retryAfter = response.headers[retryAfterHeaderName];
    const retryAfterSeconds = Number(retryAfter);
    if (!Number.isNaN(retryAfterSeconds))
        return retryAfterSeconds * 1000;
    const retryAfterDate = new Date(retryAfter);
    return retryAfterDate.getTime() - Date.now();
};
const asSdkError = (error) => {
    if (error instanceof Error)
        return error;
    if (error instanceof Object)
        return Object.assign(new Error(), error);
    if (typeof error === "string")
        return new Error(error);
    return new Error(`AWS SDK error wrapper for ${error}`);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-retry/dist-es/AdaptiveRetryStrategy.js



class AdaptiveRetryStrategy extends StandardRetryStrategy {
    constructor(maxAttemptsProvider, options) {
        const { rateLimiter, ...superOptions } = options ?? {};
        super(maxAttemptsProvider, superOptions);
        this.rateLimiter = rateLimiter ?? new DefaultRateLimiter();
        this.mode = RETRY_MODES.ADAPTIVE;
    }
    async retry(next, args) {
        return super.retry(next, args, {
            beforeRequest: async () => {
                return this.rateLimiter.getSendToken();
            },
            afterRequest: (response) => {
                this.rateLimiter.updateClientSendingRate(response);
            },
        });
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-retry/dist-es/configurations.js




const ENV_MAX_ATTEMPTS = "AWS_MAX_ATTEMPTS";
const CONFIG_MAX_ATTEMPTS = "max_attempts";
const NODE_MAX_ATTEMPT_CONFIG_OPTIONS = {
    environmentVariableSelector: (env) => {
        const value = env[ENV_MAX_ATTEMPTS];
        if (!value)
            return undefined;
        const maxAttempt = parseInt(value);
        if (Number.isNaN(maxAttempt)) {
            throw new Error(`Environment variable ${ENV_MAX_ATTEMPTS} mast be a number, got "${value}"`);
        }
        return maxAttempt;
    },
    configFileSelector: (profile) => {
        const value = profile[CONFIG_MAX_ATTEMPTS];
        if (!value)
            return undefined;
        const maxAttempt = parseInt(value);
        if (Number.isNaN(maxAttempt)) {
            throw new Error(`Shared config file entry ${CONFIG_MAX_ATTEMPTS} mast be a number, got "${value}"`);
        }
        return maxAttempt;
    },
    default: DEFAULT_MAX_ATTEMPTS,
};
const resolveRetryConfig = (input) => {
    const maxAttempts = normalizeProvider_normalizeProvider(input.maxAttempts ?? DEFAULT_MAX_ATTEMPTS);
    return {
        ...input,
        maxAttempts,
        retryStrategy: async () => {
            if (input.retryStrategy) {
                return input.retryStrategy;
            }
            const retryMode = await normalizeProvider_normalizeProvider(input.retryMode)();
            if (retryMode === RETRY_MODES.ADAPTIVE) {
                return new AdaptiveRetryStrategy(maxAttempts);
            }
            return new StandardRetryStrategy(maxAttempts);
        },
    };
};
const ENV_RETRY_MODE = "AWS_RETRY_MODE";
const CONFIG_RETRY_MODE = "retry_mode";
const NODE_RETRY_MODE_CONFIG_OPTIONS = {
    environmentVariableSelector: (env) => env[ENV_RETRY_MODE],
    configFileSelector: (profile) => profile[CONFIG_RETRY_MODE],
    default: DEFAULT_RETRY_MODE,
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-retry/dist-es/omitRetryHeadersMiddleware.js


const omitRetryHeadersMiddleware = () => (next) => async (args) => {
    const { request } = args;
    if (HttpRequest.isInstance(request)) {
        delete request.headers[INVOCATION_ID_HEADER];
        delete request.headers[REQUEST_HEADER];
    }
    return next(args);
};
const omitRetryHeadersMiddlewareOptions = {
    name: "omitRetryHeadersMiddleware",
    tags: ["RETRY", "HEADERS", "OMIT_RETRY_HEADERS"],
    relation: "before",
    toMiddleware: "awsAuthMiddleware",
    override: true,
};
const getOmitRetryHeadersPlugin = (options) => ({
    applyToStack: (clientStack) => {
        clientStack.addRelativeTo(omitRetryHeadersMiddleware(), omitRetryHeadersMiddlewareOptions);
    },
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-retry/dist-es/retryMiddleware.js
const retryMiddleware = (options) => (next, context) => async (args) => {
    const retryStrategy = await options.retryStrategy();
    if (retryStrategy?.mode)
        context.userAgent = [...(context.userAgent || []), ["cfg/retry-mode", retryStrategy.mode]];
    return retryStrategy.retry(next, args);
};
const retryMiddlewareOptions = {
    name: "retryMiddleware",
    tags: ["RETRY"],
    step: "finalizeRequest",
    priority: "high",
    override: true,
};
const getRetryPlugin = (options) => ({
    applyToStack: (clientStack) => {
        clientStack.add(retryMiddleware(options), retryMiddlewareOptions);
    },
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-retry/dist-es/index.js











;// CONCATENATED MODULE: ../node_modules/@aws-sdk/property-provider/dist-es/ProviderError.js
class ProviderError_ProviderError extends Error {
    constructor(message, tryNextLink = true) {
        super(message);
        this.tryNextLink = tryNextLink;
        this.name = "ProviderError";
        Object.setPrototypeOf(this, ProviderError_ProviderError.prototype);
    }
    static from(error, tryNextLink = true) {
        return Object.assign(new this(error.message, tryNextLink), error);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/property-provider/dist-es/CredentialsProviderError.js

class CredentialsProviderError extends ProviderError_ProviderError {
    constructor(message, tryNextLink = true) {
        super(message, tryNextLink);
        this.tryNextLink = tryNextLink;
        this.name = "CredentialsProviderError";
        Object.setPrototypeOf(this, CredentialsProviderError.prototype);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/property-provider/dist-es/TokenProviderError.js

class TokenProviderError extends (/* unused pure expression or super */ null && (ProviderError)) {
    constructor(message, tryNextLink = true) {
        super(message, tryNextLink);
        this.tryNextLink = tryNextLink;
        this.name = "TokenProviderError";
        Object.setPrototypeOf(this, TokenProviderError.prototype);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/property-provider/dist-es/chain.js

function chain(...providers) {
    return () => {
        let promise = Promise.reject(new ProviderError_ProviderError("No providers in chain"));
        for (const provider of providers) {
            promise = promise.catch((err) => {
                if (err?.tryNextLink) {
                    return provider();
                }
                throw err;
            });
        }
        return promise;
    };
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/property-provider/dist-es/fromStatic.js
const fromStatic = (staticValue) => () => Promise.resolve(staticValue);

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/property-provider/dist-es/memoize.js
const memoize = (provider, isExpired, requiresRefresh) => {
    let resolved;
    let pending;
    let hasResult;
    let isConstant = false;
    const coalesceProvider = async () => {
        if (!pending) {
            pending = provider();
        }
        try {
            resolved = await pending;
            hasResult = true;
            isConstant = false;
        }
        finally {
            pending = undefined;
        }
        return resolved;
    };
    if (isExpired === undefined) {
        return async (options) => {
            if (!hasResult || options?.forceRefresh) {
                resolved = await coalesceProvider();
            }
            return resolved;
        };
    }
    return async (options) => {
        if (!hasResult || options?.forceRefresh) {
            resolved = await coalesceProvider();
        }
        if (isConstant) {
            return resolved;
        }
        if (requiresRefresh && !requiresRefresh(resolved)) {
            isConstant = true;
            return resolved;
        }
        if (isExpired(resolved)) {
            await coalesceProvider();
            return resolved;
        }
        return resolved;
    };
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/property-provider/dist-es/index.js







;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-hex-encoding/dist-es/index.js
const SHORT_TO_HEX = {};
const HEX_TO_SHORT = {};
for (let i = 0; i < 256; i++) {
    let encodedByte = i.toString(16).toLowerCase();
    if (encodedByte.length === 1) {
        encodedByte = `0${encodedByte}`;
    }
    SHORT_TO_HEX[i] = encodedByte;
    HEX_TO_SHORT[encodedByte] = i;
}
function fromHex(encoded) {
    if (encoded.length % 2 !== 0) {
        throw new Error("Hex encoded strings must have an even number length");
    }
    const out = new Uint8Array(encoded.length / 2);
    for (let i = 0; i < encoded.length; i += 2) {
        const encodedByte = encoded.slice(i, i + 2).toLowerCase();
        if (encodedByte in HEX_TO_SHORT) {
            out[i / 2] = HEX_TO_SHORT[encodedByte];
        }
        else {
            throw new Error(`Cannot decode unrecognized sequence ${encodedByte} as hexadecimal`);
        }
    }
    return out;
}
function toHex(bytes) {
    let out = "";
    for (let i = 0; i < bytes.byteLength; i++) {
        out += SHORT_TO_HEX[bytes[i]];
    }
    return out;
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/signature-v4/dist-es/constants.js
const ALGORITHM_QUERY_PARAM = "X-Amz-Algorithm";
const CREDENTIAL_QUERY_PARAM = "X-Amz-Credential";
const AMZ_DATE_QUERY_PARAM = "X-Amz-Date";
const SIGNED_HEADERS_QUERY_PARAM = "X-Amz-SignedHeaders";
const EXPIRES_QUERY_PARAM = "X-Amz-Expires";
const SIGNATURE_QUERY_PARAM = "X-Amz-Signature";
const TOKEN_QUERY_PARAM = "X-Amz-Security-Token";
const REGION_SET_PARAM = "X-Amz-Region-Set";
const AUTH_HEADER = "authorization";
const AMZ_DATE_HEADER = AMZ_DATE_QUERY_PARAM.toLowerCase();
const DATE_HEADER = "date";
const GENERATED_HEADERS = [AUTH_HEADER, AMZ_DATE_HEADER, DATE_HEADER];
const SIGNATURE_HEADER = SIGNATURE_QUERY_PARAM.toLowerCase();
const SHA256_HEADER = "x-amz-content-sha256";
const TOKEN_HEADER = TOKEN_QUERY_PARAM.toLowerCase();
const HOST_HEADER = "host";
const ALWAYS_UNSIGNABLE_HEADERS = {
    authorization: true,
    "cache-control": true,
    connection: true,
    expect: true,
    from: true,
    "keep-alive": true,
    "max-forwards": true,
    pragma: true,
    referer: true,
    te: true,
    trailer: true,
    "transfer-encoding": true,
    upgrade: true,
    "user-agent": true,
    "x-amzn-trace-id": true,
};
const PROXY_HEADER_PATTERN = /^proxy-/;
const SEC_HEADER_PATTERN = /^sec-/;
const UNSIGNABLE_PATTERNS = (/* unused pure expression or super */ null && ([/^proxy-/i, /^sec-/i]));
const ALGORITHM_IDENTIFIER = "AWS4-HMAC-SHA256";
const ALGORITHM_IDENTIFIER_V4A = "AWS4-ECDSA-P256-SHA256";
const EVENT_ALGORITHM_IDENTIFIER = "AWS4-HMAC-SHA256-PAYLOAD";
const UNSIGNED_PAYLOAD = "UNSIGNED-PAYLOAD";
const MAX_CACHE_SIZE = 50;
const KEY_TYPE_IDENTIFIER = "aws4_request";
const MAX_PRESIGNED_TTL = 60 * 60 * 24 * 7;

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/signature-v4/dist-es/credentialDerivation.js


const signingKeyCache = {};
const cacheQueue = [];
const createScope = (shortDate, region, service) => `${shortDate}/${region}/${service}/${KEY_TYPE_IDENTIFIER}`;
const getSigningKey = async (sha256Constructor, credentials, shortDate, region, service) => {
    const credsHash = await hmac(sha256Constructor, credentials.secretAccessKey, credentials.accessKeyId);
    const cacheKey = `${shortDate}:${region}:${service}:${toHex(credsHash)}:${credentials.sessionToken}`;
    if (cacheKey in signingKeyCache) {
        return signingKeyCache[cacheKey];
    }
    cacheQueue.push(cacheKey);
    while (cacheQueue.length > MAX_CACHE_SIZE) {
        delete signingKeyCache[cacheQueue.shift()];
    }
    let key = `AWS4${credentials.secretAccessKey}`;
    for (const signable of [shortDate, region, service, KEY_TYPE_IDENTIFIER]) {
        key = await hmac(sha256Constructor, key, signable);
    }
    return (signingKeyCache[cacheKey] = key);
};
const clearCredentialCache = () => {
    cacheQueue.length = 0;
    Object.keys(signingKeyCache).forEach((cacheKey) => {
        delete signingKeyCache[cacheKey];
    });
};
const hmac = (ctor, secret, data) => {
    const hash = new ctor(secret);
    hash.update(data);
    return hash.digest();
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/signature-v4/dist-es/getCanonicalHeaders.js

const getCanonicalHeaders = ({ headers }, unsignableHeaders, signableHeaders) => {
    const canonical = {};
    for (const headerName of Object.keys(headers).sort()) {
        if (headers[headerName] == undefined) {
            continue;
        }
        const canonicalHeaderName = headerName.toLowerCase();
        if (canonicalHeaderName in ALWAYS_UNSIGNABLE_HEADERS ||
            unsignableHeaders?.has(canonicalHeaderName) ||
            PROXY_HEADER_PATTERN.test(canonicalHeaderName) ||
            SEC_HEADER_PATTERN.test(canonicalHeaderName)) {
            if (!signableHeaders || (signableHeaders && !signableHeaders.has(canonicalHeaderName))) {
                continue;
            }
        }
        canonical[canonicalHeaderName] = headers[headerName].trim().replace(/\s+/g, " ");
    }
    return canonical;
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-uri-escape/dist-es/escape-uri.js
const escapeUri = (uri) => encodeURIComponent(uri).replace(/[!'()*]/g, hexEncode);
const hexEncode = (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`;

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/signature-v4/dist-es/getCanonicalQuery.js


const getCanonicalQuery = ({ query = {} }) => {
    const keys = [];
    const serialized = {};
    for (const key of Object.keys(query).sort()) {
        if (key.toLowerCase() === SIGNATURE_HEADER) {
            continue;
        }
        keys.push(key);
        const value = query[key];
        if (typeof value === "string") {
            serialized[key] = `${escapeUri(key)}=${escapeUri(value)}`;
        }
        else if (Array.isArray(value)) {
            serialized[key] = value
                .slice(0)
                .sort()
                .reduce((encoded, value) => encoded.concat([`${escapeUri(key)}=${escapeUri(value)}`]), [])
                .join("&");
        }
    }
    return keys
        .map((key) => serialized[key])
        .filter((serialized) => serialized)
        .join("&");
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/is-array-buffer/dist-es/index.js
const isArrayBuffer = (arg) => (typeof ArrayBuffer === "function" && arg instanceof ArrayBuffer) ||
    Object.prototype.toString.call(arg) === "[object ArrayBuffer]";

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/signature-v4/dist-es/getPayloadHash.js



const getPayloadHash = async ({ headers, body }, hashConstructor) => {
    for (const headerName of Object.keys(headers)) {
        if (headerName.toLowerCase() === SHA256_HEADER) {
            return headers[headerName];
        }
    }
    if (body == undefined) {
        return "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
    }
    else if (typeof body === "string" || ArrayBuffer.isView(body) || isArrayBuffer(body)) {
        const hashCtor = new hashConstructor();
        hashCtor.update(body);
        return toHex(await hashCtor.digest());
    }
    return UNSIGNED_PAYLOAD;
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/signature-v4/dist-es/headerUtil.js
const hasHeader = (soughtHeader, headers) => {
    soughtHeader = soughtHeader.toLowerCase();
    for (const headerName of Object.keys(headers)) {
        if (soughtHeader === headerName.toLowerCase()) {
            return true;
        }
    }
    return false;
};
const getHeaderValue = (soughtHeader, headers) => {
    soughtHeader = soughtHeader.toLowerCase();
    for (const headerName of Object.keys(headers)) {
        if (soughtHeader === headerName.toLowerCase()) {
            return headers[headerName];
        }
    }
    return undefined;
};
const deleteHeader = (soughtHeader, headers) => {
    soughtHeader = soughtHeader.toLowerCase();
    for (const headerName of Object.keys(headers)) {
        if (soughtHeader === headerName.toLowerCase()) {
            delete headers[headerName];
        }
    }
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/signature-v4/dist-es/cloneRequest.js
const cloneRequest = ({ headers, query, ...rest }) => ({
    ...rest,
    headers: { ...headers },
    query: query ? cloneRequest_cloneQuery(query) : undefined,
});
const cloneRequest_cloneQuery = (query) => Object.keys(query).reduce((carry, paramName) => {
    const param = query[paramName];
    return {
        ...carry,
        [paramName]: Array.isArray(param) ? [...param] : param,
    };
}, {});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/signature-v4/dist-es/moveHeadersToQuery.js

const moveHeadersToQuery = (request, options = {}) => {
    const { headers, query = {} } = typeof request.clone === "function" ? request.clone() : cloneRequest(request);
    for (const name of Object.keys(headers)) {
        const lname = name.toLowerCase();
        if (lname.slice(0, 6) === "x-amz-" && !options.unhoistableHeaders?.has(lname)) {
            query[name] = headers[name];
            delete headers[name];
        }
    }
    return {
        ...request,
        headers,
        query,
    };
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/signature-v4/dist-es/prepareRequest.js


const prepareRequest = (request) => {
    request = typeof request.clone === "function" ? request.clone() : cloneRequest(request);
    for (const headerName of Object.keys(request.headers)) {
        if (GENERATED_HEADERS.indexOf(headerName.toLowerCase()) > -1) {
            delete request.headers[headerName];
        }
    }
    return request;
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/signature-v4/dist-es/utilDate.js
const iso8601 = (time) => toDate(time)
    .toISOString()
    .replace(/\.\d{3}Z$/, "Z");
const toDate = (time) => {
    if (typeof time === "number") {
        return new Date(time * 1000);
    }
    if (typeof time === "string") {
        if (Number(time)) {
            return new Date(Number(time) * 1000);
        }
        return new Date(time);
    }
    return time;
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/signature-v4/dist-es/SignatureV4.js











class SignatureV4_SignatureV4 {
    constructor({ applyChecksum, credentials, region, service, sha256, uriEscapePath = true, }) {
        this.service = service;
        this.sha256 = sha256;
        this.uriEscapePath = uriEscapePath;
        this.applyChecksum = typeof applyChecksum === "boolean" ? applyChecksum : true;
        this.regionProvider = normalizeProvider_normalizeProvider(region);
        this.credentialProvider = normalizeProvider_normalizeProvider(credentials);
    }
    async presign(originalRequest, options = {}) {
        const { signingDate = new Date(), expiresIn = 3600, unsignableHeaders, unhoistableHeaders, signableHeaders, signingRegion, signingService, } = options;
        const credentials = await this.credentialProvider();
        this.validateResolvedCredentials(credentials);
        const region = signingRegion ?? (await this.regionProvider());
        const { longDate, shortDate } = formatDate(signingDate);
        if (expiresIn > MAX_PRESIGNED_TTL) {
            return Promise.reject("Signature version 4 presigned URLs" + " must have an expiration date less than one week in" + " the future");
        }
        const scope = createScope(shortDate, region, signingService ?? this.service);
        const request = moveHeadersToQuery(prepareRequest(originalRequest), { unhoistableHeaders });
        if (credentials.sessionToken) {
            request.query[TOKEN_QUERY_PARAM] = credentials.sessionToken;
        }
        request.query[ALGORITHM_QUERY_PARAM] = ALGORITHM_IDENTIFIER;
        request.query[CREDENTIAL_QUERY_PARAM] = `${credentials.accessKeyId}/${scope}`;
        request.query[AMZ_DATE_QUERY_PARAM] = longDate;
        request.query[EXPIRES_QUERY_PARAM] = expiresIn.toString(10);
        const canonicalHeaders = getCanonicalHeaders(request, unsignableHeaders, signableHeaders);
        request.query[SIGNED_HEADERS_QUERY_PARAM] = getCanonicalHeaderList(canonicalHeaders);
        request.query[SIGNATURE_QUERY_PARAM] = await this.getSignature(longDate, scope, this.getSigningKey(credentials, region, shortDate, signingService), this.createCanonicalRequest(request, canonicalHeaders, await getPayloadHash(originalRequest, this.sha256)));
        return request;
    }
    async sign(toSign, options) {
        if (typeof toSign === "string") {
            return this.signString(toSign, options);
        }
        else if (toSign.headers && toSign.payload) {
            return this.signEvent(toSign, options);
        }
        else {
            return this.signRequest(toSign, options);
        }
    }
    async signEvent({ headers, payload }, { signingDate = new Date(), priorSignature, signingRegion, signingService }) {
        const region = signingRegion ?? (await this.regionProvider());
        const { shortDate, longDate } = formatDate(signingDate);
        const scope = createScope(shortDate, region, signingService ?? this.service);
        const hashedPayload = await getPayloadHash({ headers: {}, body: payload }, this.sha256);
        const hash = new this.sha256();
        hash.update(headers);
        const hashedHeaders = toHex(await hash.digest());
        const stringToSign = [
            EVENT_ALGORITHM_IDENTIFIER,
            longDate,
            scope,
            priorSignature,
            hashedHeaders,
            hashedPayload,
        ].join("\n");
        return this.signString(stringToSign, { signingDate, signingRegion: region, signingService });
    }
    async signString(stringToSign, { signingDate = new Date(), signingRegion, signingService } = {}) {
        const credentials = await this.credentialProvider();
        this.validateResolvedCredentials(credentials);
        const region = signingRegion ?? (await this.regionProvider());
        const { shortDate } = formatDate(signingDate);
        const hash = new this.sha256(await this.getSigningKey(credentials, region, shortDate, signingService));
        hash.update(stringToSign);
        return toHex(await hash.digest());
    }
    async signRequest(requestToSign, { signingDate = new Date(), signableHeaders, unsignableHeaders, signingRegion, signingService, } = {}) {
        const credentials = await this.credentialProvider();
        this.validateResolvedCredentials(credentials);
        const region = signingRegion ?? (await this.regionProvider());
        const request = prepareRequest(requestToSign);
        const { longDate, shortDate } = formatDate(signingDate);
        const scope = createScope(shortDate, region, signingService ?? this.service);
        request.headers[AMZ_DATE_HEADER] = longDate;
        if (credentials.sessionToken) {
            request.headers[TOKEN_HEADER] = credentials.sessionToken;
        }
        const payloadHash = await getPayloadHash(request, this.sha256);
        if (!hasHeader(SHA256_HEADER, request.headers) && this.applyChecksum) {
            request.headers[SHA256_HEADER] = payloadHash;
        }
        const canonicalHeaders = getCanonicalHeaders(request, unsignableHeaders, signableHeaders);
        const signature = await this.getSignature(longDate, scope, this.getSigningKey(credentials, region, shortDate, signingService), this.createCanonicalRequest(request, canonicalHeaders, payloadHash));
        request.headers[AUTH_HEADER] =
            `${ALGORITHM_IDENTIFIER} ` +
                `Credential=${credentials.accessKeyId}/${scope}, ` +
                `SignedHeaders=${getCanonicalHeaderList(canonicalHeaders)}, ` +
                `Signature=${signature}`;
        return request;
    }
    createCanonicalRequest(request, canonicalHeaders, payloadHash) {
        const sortedHeaders = Object.keys(canonicalHeaders).sort();
        return `${request.method}
${this.getCanonicalPath(request)}
${getCanonicalQuery(request)}
${sortedHeaders.map((name) => `${name}:${canonicalHeaders[name]}`).join("\n")}

${sortedHeaders.join(";")}
${payloadHash}`;
    }
    async createStringToSign(longDate, credentialScope, canonicalRequest) {
        const hash = new this.sha256();
        hash.update(canonicalRequest);
        const hashedRequest = await hash.digest();
        return `${ALGORITHM_IDENTIFIER}
${longDate}
${credentialScope}
${toHex(hashedRequest)}`;
    }
    getCanonicalPath({ path }) {
        if (this.uriEscapePath) {
            const normalizedPathSegments = [];
            for (const pathSegment of path.split("/")) {
                if (pathSegment?.length === 0)
                    continue;
                if (pathSegment === ".")
                    continue;
                if (pathSegment === "..") {
                    normalizedPathSegments.pop();
                }
                else {
                    normalizedPathSegments.push(pathSegment);
                }
            }
            const normalizedPath = `${path?.startsWith("/") ? "/" : ""}${normalizedPathSegments.join("/")}${normalizedPathSegments.length > 0 && path?.endsWith("/") ? "/" : ""}`;
            const doubleEncoded = encodeURIComponent(normalizedPath);
            return doubleEncoded.replace(/%2F/g, "/");
        }
        return path;
    }
    async getSignature(longDate, credentialScope, keyPromise, canonicalRequest) {
        const stringToSign = await this.createStringToSign(longDate, credentialScope, canonicalRequest);
        const hash = new this.sha256(await keyPromise);
        hash.update(stringToSign);
        return toHex(await hash.digest());
    }
    getSigningKey(credentials, region, shortDate, service) {
        return getSigningKey(this.sha256, credentials, shortDate, region, service || this.service);
    }
    validateResolvedCredentials(credentials) {
        if (typeof credentials !== "object" ||
            typeof credentials.accessKeyId !== "string" ||
            typeof credentials.secretAccessKey !== "string") {
            throw new Error("Resolved credential object is not valid");
        }
    }
}
const formatDate = (now) => {
    const longDate = iso8601(now).replace(/[\-:]/g, "");
    return {
        longDate,
        shortDate: longDate.slice(0, 8),
    };
};
const getCanonicalHeaderList = (headers) => Object.keys(headers).sort().join(";");

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/signature-v4/dist-es/index.js








;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-signing/dist-es/configurations.js



const CREDENTIAL_EXPIRE_WINDOW = 300000;
const resolveAwsAuthConfig = (input) => {
    const normalizedCreds = input.credentials
        ? normalizeCredentialProvider(input.credentials)
        : input.credentialDefaultProvider(input);
    const { signingEscapePath = true, systemClockOffset = input.systemClockOffset || 0, sha256 } = input;
    let signer;
    if (input.signer) {
        signer = normalizeProvider_normalizeProvider(input.signer);
    }
    else if (input.regionInfoProvider) {
        signer = () => normalizeProvider_normalizeProvider(input.region)()
            .then(async (region) => [
            (await input.regionInfoProvider(region, {
                useFipsEndpoint: await input.useFipsEndpoint(),
                useDualstackEndpoint: await input.useDualstackEndpoint(),
            })) || {},
            region,
        ])
            .then(([regionInfo, region]) => {
            const { signingRegion, signingService } = regionInfo;
            input.signingRegion = input.signingRegion || signingRegion || region;
            input.signingName = input.signingName || signingService || input.serviceId;
            const params = {
                ...input,
                credentials: normalizedCreds,
                region: input.signingRegion,
                service: input.signingName,
                sha256,
                uriEscapePath: signingEscapePath,
            };
            const SignerCtor = input.signerConstructor || SignatureV4_SignatureV4;
            return new SignerCtor(params);
        });
    }
    else {
        signer = async (authScheme) => {
            if (!authScheme) {
                throw new Error("Unexpected empty auth scheme config");
            }
            const signingRegion = authScheme.signingScope;
            const signingService = authScheme.signingName;
            input.signingRegion = input.signingRegion || signingRegion;
            input.signingName = input.signingName || signingService || input.serviceId;
            const params = {
                ...input,
                credentials: normalizedCreds,
                region: input.signingRegion,
                service: input.signingName,
                sha256,
                uriEscapePath: signingEscapePath,
            };
            const SignerCtor = input.signerConstructor || SignatureV4_SignatureV4;
            return new SignerCtor(params);
        };
    }
    return {
        ...input,
        systemClockOffset,
        signingEscapePath,
        credentials: normalizedCreds,
        signer,
    };
};
const resolveSigV4AuthConfig = (input) => {
    const normalizedCreds = input.credentials
        ? normalizeCredentialProvider(input.credentials)
        : input.credentialDefaultProvider(input);
    const { signingEscapePath = true, systemClockOffset = input.systemClockOffset || 0, sha256 } = input;
    let signer;
    if (input.signer) {
        signer = normalizeProvider(input.signer);
    }
    else {
        signer = normalizeProvider(new SignatureV4({
            credentials: normalizedCreds,
            region: input.region,
            service: input.signingName,
            sha256,
            uriEscapePath: signingEscapePath,
        }));
    }
    return {
        ...input,
        systemClockOffset,
        signingEscapePath,
        credentials: normalizedCreds,
        signer,
    };
};
const normalizeCredentialProvider = (credentials) => {
    if (typeof credentials === "function") {
        return memoize(credentials, (credentials) => credentials.expiration !== undefined &&
            credentials.expiration.getTime() - Date.now() < CREDENTIAL_EXPIRE_WINDOW, (credentials) => credentials.expiration !== undefined);
    }
    return normalizeProvider_normalizeProvider(credentials);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-signing/dist-es/utils/getSkewCorrectedDate.js
const getSkewCorrectedDate = (systemClockOffset) => new Date(Date.now() + systemClockOffset);

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-signing/dist-es/utils/isClockSkewed.js

const isClockSkewed = (clockTime, systemClockOffset) => Math.abs(getSkewCorrectedDate(systemClockOffset).getTime() - clockTime) >= 300000;

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-signing/dist-es/utils/getUpdatedSystemClockOffset.js

const getUpdatedSystemClockOffset = (clockTime, currentSystemClockOffset) => {
    const clockTimeInMs = Date.parse(clockTime);
    if (isClockSkewed(clockTimeInMs, currentSystemClockOffset)) {
        return clockTimeInMs - Date.now();
    }
    return currentSystemClockOffset;
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-signing/dist-es/middleware.js



const awsAuthMiddleware = (options) => (next, context) => async function (args) {
    if (!httpRequest_HttpRequest.isInstance(args.request))
        return next(args);
    const authScheme = (context.endpointV2)?.properties?.authSchemes?.[0];
    const signer = await options.signer(authScheme);
    const output = await next({
        ...args,
        request: await signer.sign(args.request, {
            signingDate: getSkewCorrectedDate(options.systemClockOffset),
            signingRegion: context["signing_region"],
            signingService: context["signing_service"],
        }),
    }).catch((error) => {
        const serverTime = error.ServerTime ?? getDateHeader(error.$response);
        if (serverTime) {
            options.systemClockOffset = getUpdatedSystemClockOffset(serverTime, options.systemClockOffset);
        }
        throw error;
    });
    const dateHeader = getDateHeader(output.response);
    if (dateHeader) {
        options.systemClockOffset = getUpdatedSystemClockOffset(dateHeader, options.systemClockOffset);
    }
    return output;
};
const getDateHeader = (response) => httpResponse_HttpResponse.isInstance(response) ? response.headers?.date ?? response.headers?.Date : undefined;
const awsAuthMiddlewareOptions = {
    name: "awsAuthMiddleware",
    tags: ["SIGNATURE", "AWSAUTH"],
    relation: "after",
    toMiddleware: "retryMiddleware",
    override: true,
};
const getAwsAuthPlugin = (options) => ({
    applyToStack: (clientStack) => {
        clientStack.addRelativeTo(awsAuthMiddleware(options), awsAuthMiddlewareOptions);
    },
});
const getSigV4AuthPlugin = (/* unused pure expression or super */ null && (getAwsAuthPlugin));

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-signing/dist-es/index.js



;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-user-agent/dist-es/configurations.js
function resolveUserAgentConfig(input) {
    return {
        ...input,
        customUserAgent: typeof input.customUserAgent === "string" ? [[input.customUserAgent]] : input.customUserAgent,
    };
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-user-agent/dist-es/constants.js
const USER_AGENT = "user-agent";
const X_AMZ_USER_AGENT = "x-amz-user-agent";
const SPACE = " ";
const UA_ESCAPE_REGEX = /[^\!\#\$\%\&\'\*\+\-\.\^\_\`\|\~\d\w]/g;

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-user-agent/dist-es/user-agent-middleware.js


const userAgentMiddleware = (options) => (next, context) => async (args) => {
    const { request } = args;
    if (!httpRequest_HttpRequest.isInstance(request))
        return next(args);
    const { headers } = request;
    const userAgent = context?.userAgent?.map(escapeUserAgent) || [];
    const defaultUserAgent = (await options.defaultUserAgentProvider()).map(escapeUserAgent);
    const customUserAgent = options?.customUserAgent?.map(escapeUserAgent) || [];
    const sdkUserAgentValue = [...defaultUserAgent, ...userAgent, ...customUserAgent].join(SPACE);
    const normalUAValue = [
        ...defaultUserAgent.filter((section) => section.startsWith("aws-sdk-")),
        ...customUserAgent,
    ].join(SPACE);
    if (options.runtime !== "browser") {
        if (normalUAValue) {
            headers[X_AMZ_USER_AGENT] = headers[X_AMZ_USER_AGENT]
                ? `${headers[USER_AGENT]} ${normalUAValue}`
                : normalUAValue;
        }
        headers[USER_AGENT] = sdkUserAgentValue;
    }
    else {
        headers[X_AMZ_USER_AGENT] = sdkUserAgentValue;
    }
    return next({
        ...args,
        request,
    });
};
const escapeUserAgent = ([name, version]) => {
    const prefixSeparatorIndex = name.indexOf("/");
    const prefix = name.substring(0, prefixSeparatorIndex);
    let uaName = name.substring(prefixSeparatorIndex + 1);
    if (prefix === "api") {
        uaName = uaName.toLowerCase();
    }
    return [prefix, uaName, version]
        .filter((item) => item && item.length > 0)
        .map((item) => item?.replace(UA_ESCAPE_REGEX, "_"))
        .join("/");
};
const getUserAgentMiddlewareOptions = {
    name: "getUserAgentMiddleware",
    step: "build",
    priority: "low",
    tags: ["SET_USER_AGENT", "USER_AGENT"],
    override: true,
};
const getUserAgentPlugin = (config) => ({
    applyToStack: (clientStack) => {
        clientStack.add(userAgentMiddleware(config), getUserAgentMiddlewareOptions);
    },
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-user-agent/dist-es/index.js



;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/package.json
const package_namespaceObject = {"i8":"3.188.0"};
;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sts/dist-es/models/STSServiceException.js

class STSServiceException extends ServiceException {
    constructor(options) {
        super(options);
        Object.setPrototypeOf(this, STSServiceException.prototype);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sts/dist-es/models/models_0.js

class ExpiredTokenException extends STSServiceException {
    constructor(opts) {
        super({
            name: "ExpiredTokenException",
            $fault: "client",
            ...opts,
        });
        this.name = "ExpiredTokenException";
        this.$fault = "client";
        Object.setPrototypeOf(this, ExpiredTokenException.prototype);
    }
}
class MalformedPolicyDocumentException extends STSServiceException {
    constructor(opts) {
        super({
            name: "MalformedPolicyDocumentException",
            $fault: "client",
            ...opts,
        });
        this.name = "MalformedPolicyDocumentException";
        this.$fault = "client";
        Object.setPrototypeOf(this, MalformedPolicyDocumentException.prototype);
    }
}
class PackedPolicyTooLargeException extends STSServiceException {
    constructor(opts) {
        super({
            name: "PackedPolicyTooLargeException",
            $fault: "client",
            ...opts,
        });
        this.name = "PackedPolicyTooLargeException";
        this.$fault = "client";
        Object.setPrototypeOf(this, PackedPolicyTooLargeException.prototype);
    }
}
class RegionDisabledException extends STSServiceException {
    constructor(opts) {
        super({
            name: "RegionDisabledException",
            $fault: "client",
            ...opts,
        });
        this.name = "RegionDisabledException";
        this.$fault = "client";
        Object.setPrototypeOf(this, RegionDisabledException.prototype);
    }
}
class IDPRejectedClaimException extends STSServiceException {
    constructor(opts) {
        super({
            name: "IDPRejectedClaimException",
            $fault: "client",
            ...opts,
        });
        this.name = "IDPRejectedClaimException";
        this.$fault = "client";
        Object.setPrototypeOf(this, IDPRejectedClaimException.prototype);
    }
}
class InvalidIdentityTokenException extends STSServiceException {
    constructor(opts) {
        super({
            name: "InvalidIdentityTokenException",
            $fault: "client",
            ...opts,
        });
        this.name = "InvalidIdentityTokenException";
        this.$fault = "client";
        Object.setPrototypeOf(this, InvalidIdentityTokenException.prototype);
    }
}
class IDPCommunicationErrorException extends STSServiceException {
    constructor(opts) {
        super({
            name: "IDPCommunicationErrorException",
            $fault: "client",
            ...opts,
        });
        this.name = "IDPCommunicationErrorException";
        this.$fault = "client";
        Object.setPrototypeOf(this, IDPCommunicationErrorException.prototype);
    }
}
class models_0_InvalidAuthorizationMessageException extends (/* unused pure expression or super */ null && (__BaseException)) {
    constructor(opts) {
        super({
            name: "InvalidAuthorizationMessageException",
            $fault: "client",
            ...opts,
        });
        this.name = "InvalidAuthorizationMessageException";
        this.$fault = "client";
        Object.setPrototypeOf(this, models_0_InvalidAuthorizationMessageException.prototype);
    }
}
const AssumedRoleUserFilterSensitiveLog = (obj) => ({
    ...obj,
});
const PolicyDescriptorTypeFilterSensitiveLog = (obj) => ({
    ...obj,
});
const models_0_TagFilterSensitiveLog = (obj) => ({
    ...obj,
});
const AssumeRoleRequestFilterSensitiveLog = (obj) => ({
    ...obj,
});
const CredentialsFilterSensitiveLog = (obj) => ({
    ...obj,
});
const AssumeRoleResponseFilterSensitiveLog = (obj) => ({
    ...obj,
});
const AssumeRoleWithSAMLRequestFilterSensitiveLog = (obj) => ({
    ...obj,
});
const AssumeRoleWithSAMLResponseFilterSensitiveLog = (obj) => ({
    ...obj,
});
const AssumeRoleWithWebIdentityRequestFilterSensitiveLog = (obj) => ({
    ...obj,
});
const AssumeRoleWithWebIdentityResponseFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DecodeAuthorizationMessageRequestFilterSensitiveLog = (obj) => ({
    ...obj,
});
const DecodeAuthorizationMessageResponseFilterSensitiveLog = (obj) => ({
    ...obj,
});
const GetAccessKeyInfoRequestFilterSensitiveLog = (obj) => ({
    ...obj,
});
const GetAccessKeyInfoResponseFilterSensitiveLog = (obj) => ({
    ...obj,
});
const GetCallerIdentityRequestFilterSensitiveLog = (obj) => ({
    ...obj,
});
const GetCallerIdentityResponseFilterSensitiveLog = (obj) => ({
    ...obj,
});
const GetFederationTokenRequestFilterSensitiveLog = (obj) => ({
    ...obj,
});
const FederatedUserFilterSensitiveLog = (obj) => ({
    ...obj,
});
const GetFederationTokenResponseFilterSensitiveLog = (obj) => ({
    ...obj,
});
const GetSessionTokenRequestFilterSensitiveLog = (obj) => ({
    ...obj,
});
const GetSessionTokenResponseFilterSensitiveLog = (obj) => ({
    ...obj,
});

// EXTERNAL MODULE: ../node_modules/fast-xml-parser/src/fxp.js
var fxp = __webpack_require__(368);
;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sts/dist-es/protocols/Aws_query.js





const serializeAws_queryAssumeRoleCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-www-form-urlencoded",
    };
    let body;
    body = buildFormUrlencodedString({
        ...serializeAws_queryAssumeRoleRequest(input, context),
        Action: "AssumeRole",
        Version: "2011-06-15",
    });
    return Aws_query_buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_queryAssumeRoleWithSAMLCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-www-form-urlencoded",
    };
    let body;
    body = buildFormUrlencodedString({
        ...serializeAws_queryAssumeRoleWithSAMLRequest(input, context),
        Action: "AssumeRoleWithSAML",
        Version: "2011-06-15",
    });
    return Aws_query_buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_queryAssumeRoleWithWebIdentityCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-www-form-urlencoded",
    };
    let body;
    body = buildFormUrlencodedString({
        ...serializeAws_queryAssumeRoleWithWebIdentityRequest(input, context),
        Action: "AssumeRoleWithWebIdentity",
        Version: "2011-06-15",
    });
    return Aws_query_buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_queryDecodeAuthorizationMessageCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-www-form-urlencoded",
    };
    let body;
    body = buildFormUrlencodedString({
        ...serializeAws_queryDecodeAuthorizationMessageRequest(input, context),
        Action: "DecodeAuthorizationMessage",
        Version: "2011-06-15",
    });
    return Aws_query_buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_queryGetAccessKeyInfoCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-www-form-urlencoded",
    };
    let body;
    body = buildFormUrlencodedString({
        ...serializeAws_queryGetAccessKeyInfoRequest(input, context),
        Action: "GetAccessKeyInfo",
        Version: "2011-06-15",
    });
    return Aws_query_buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_queryGetCallerIdentityCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-www-form-urlencoded",
    };
    let body;
    body = buildFormUrlencodedString({
        ...serializeAws_queryGetCallerIdentityRequest(input, context),
        Action: "GetCallerIdentity",
        Version: "2011-06-15",
    });
    return Aws_query_buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_queryGetFederationTokenCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-www-form-urlencoded",
    };
    let body;
    body = buildFormUrlencodedString({
        ...serializeAws_queryGetFederationTokenRequest(input, context),
        Action: "GetFederationToken",
        Version: "2011-06-15",
    });
    return Aws_query_buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const serializeAws_queryGetSessionTokenCommand = async (input, context) => {
    const headers = {
        "content-type": "application/x-www-form-urlencoded",
    };
    let body;
    body = buildFormUrlencodedString({
        ...serializeAws_queryGetSessionTokenRequest(input, context),
        Action: "GetSessionToken",
        Version: "2011-06-15",
    });
    return Aws_query_buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const deserializeAws_queryAssumeRoleCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_queryAssumeRoleCommandError(output, context);
    }
    const data = await Aws_query_parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_queryAssumeRoleResponse(data.AssumeRoleResult, context);
    const response = {
        $metadata: Aws_query_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_queryAssumeRoleCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await Aws_query_parseErrorBody(output.body, context),
    };
    const errorCode = loadQueryErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "ExpiredTokenException":
        case "com.amazonaws.sts#ExpiredTokenException":
            throw await deserializeAws_queryExpiredTokenExceptionResponse(parsedOutput, context);
        case "MalformedPolicyDocument":
        case "com.amazonaws.sts#MalformedPolicyDocumentException":
            throw await deserializeAws_queryMalformedPolicyDocumentExceptionResponse(parsedOutput, context);
        case "PackedPolicyTooLarge":
        case "com.amazonaws.sts#PackedPolicyTooLargeException":
            throw await deserializeAws_queryPackedPolicyTooLargeExceptionResponse(parsedOutput, context);
        case "RegionDisabledException":
        case "com.amazonaws.sts#RegionDisabledException":
            throw await deserializeAws_queryRegionDisabledExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody: parsedBody.Error,
                exceptionCtor: STSServiceException,
                errorCode,
            });
    }
};
const deserializeAws_queryAssumeRoleWithSAMLCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_queryAssumeRoleWithSAMLCommandError(output, context);
    }
    const data = await Aws_query_parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_queryAssumeRoleWithSAMLResponse(data.AssumeRoleWithSAMLResult, context);
    const response = {
        $metadata: Aws_query_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_queryAssumeRoleWithSAMLCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await Aws_query_parseErrorBody(output.body, context),
    };
    const errorCode = loadQueryErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "ExpiredTokenException":
        case "com.amazonaws.sts#ExpiredTokenException":
            throw await deserializeAws_queryExpiredTokenExceptionResponse(parsedOutput, context);
        case "IDPRejectedClaim":
        case "com.amazonaws.sts#IDPRejectedClaimException":
            throw await deserializeAws_queryIDPRejectedClaimExceptionResponse(parsedOutput, context);
        case "InvalidIdentityToken":
        case "com.amazonaws.sts#InvalidIdentityTokenException":
            throw await deserializeAws_queryInvalidIdentityTokenExceptionResponse(parsedOutput, context);
        case "MalformedPolicyDocument":
        case "com.amazonaws.sts#MalformedPolicyDocumentException":
            throw await deserializeAws_queryMalformedPolicyDocumentExceptionResponse(parsedOutput, context);
        case "PackedPolicyTooLarge":
        case "com.amazonaws.sts#PackedPolicyTooLargeException":
            throw await deserializeAws_queryPackedPolicyTooLargeExceptionResponse(parsedOutput, context);
        case "RegionDisabledException":
        case "com.amazonaws.sts#RegionDisabledException":
            throw await deserializeAws_queryRegionDisabledExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            throwDefaultError({
                output,
                parsedBody: parsedBody.Error,
                exceptionCtor: __BaseException,
                errorCode,
            });
    }
};
const deserializeAws_queryAssumeRoleWithWebIdentityCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_queryAssumeRoleWithWebIdentityCommandError(output, context);
    }
    const data = await Aws_query_parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_queryAssumeRoleWithWebIdentityResponse(data.AssumeRoleWithWebIdentityResult, context);
    const response = {
        $metadata: Aws_query_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_queryAssumeRoleWithWebIdentityCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await Aws_query_parseErrorBody(output.body, context),
    };
    const errorCode = loadQueryErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "ExpiredTokenException":
        case "com.amazonaws.sts#ExpiredTokenException":
            throw await deserializeAws_queryExpiredTokenExceptionResponse(parsedOutput, context);
        case "IDPCommunicationError":
        case "com.amazonaws.sts#IDPCommunicationErrorException":
            throw await deserializeAws_queryIDPCommunicationErrorExceptionResponse(parsedOutput, context);
        case "IDPRejectedClaim":
        case "com.amazonaws.sts#IDPRejectedClaimException":
            throw await deserializeAws_queryIDPRejectedClaimExceptionResponse(parsedOutput, context);
        case "InvalidIdentityToken":
        case "com.amazonaws.sts#InvalidIdentityTokenException":
            throw await deserializeAws_queryInvalidIdentityTokenExceptionResponse(parsedOutput, context);
        case "MalformedPolicyDocument":
        case "com.amazonaws.sts#MalformedPolicyDocumentException":
            throw await deserializeAws_queryMalformedPolicyDocumentExceptionResponse(parsedOutput, context);
        case "PackedPolicyTooLarge":
        case "com.amazonaws.sts#PackedPolicyTooLargeException":
            throw await deserializeAws_queryPackedPolicyTooLargeExceptionResponse(parsedOutput, context);
        case "RegionDisabledException":
        case "com.amazonaws.sts#RegionDisabledException":
            throw await deserializeAws_queryRegionDisabledExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody: parsedBody.Error,
                exceptionCtor: STSServiceException,
                errorCode,
            });
    }
};
const deserializeAws_queryDecodeAuthorizationMessageCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_queryDecodeAuthorizationMessageCommandError(output, context);
    }
    const data = await Aws_query_parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_queryDecodeAuthorizationMessageResponse(data.DecodeAuthorizationMessageResult, context);
    const response = {
        $metadata: Aws_query_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_queryDecodeAuthorizationMessageCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await Aws_query_parseErrorBody(output.body, context),
    };
    const errorCode = loadQueryErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InvalidAuthorizationMessageException":
        case "com.amazonaws.sts#InvalidAuthorizationMessageException":
            throw await deserializeAws_queryInvalidAuthorizationMessageExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            throwDefaultError({
                output,
                parsedBody: parsedBody.Error,
                exceptionCtor: __BaseException,
                errorCode,
            });
    }
};
const deserializeAws_queryGetAccessKeyInfoCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_queryGetAccessKeyInfoCommandError(output, context);
    }
    const data = await Aws_query_parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_queryGetAccessKeyInfoResponse(data.GetAccessKeyInfoResult, context);
    const response = {
        $metadata: Aws_query_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_queryGetAccessKeyInfoCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await Aws_query_parseErrorBody(output.body, context),
    };
    const errorCode = loadQueryErrorCode(output, parsedOutput.body);
    const parsedBody = parsedOutput.body;
    throwDefaultError({
        output,
        parsedBody: parsedBody.Error,
        exceptionCtor: __BaseException,
        errorCode,
    });
};
const deserializeAws_queryGetCallerIdentityCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_queryGetCallerIdentityCommandError(output, context);
    }
    const data = await Aws_query_parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_queryGetCallerIdentityResponse(data.GetCallerIdentityResult, context);
    const response = {
        $metadata: Aws_query_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_queryGetCallerIdentityCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await Aws_query_parseErrorBody(output.body, context),
    };
    const errorCode = loadQueryErrorCode(output, parsedOutput.body);
    const parsedBody = parsedOutput.body;
    throwDefaultError({
        output,
        parsedBody: parsedBody.Error,
        exceptionCtor: __BaseException,
        errorCode,
    });
};
const deserializeAws_queryGetFederationTokenCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_queryGetFederationTokenCommandError(output, context);
    }
    const data = await Aws_query_parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_queryGetFederationTokenResponse(data.GetFederationTokenResult, context);
    const response = {
        $metadata: Aws_query_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_queryGetFederationTokenCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await Aws_query_parseErrorBody(output.body, context),
    };
    const errorCode = loadQueryErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "MalformedPolicyDocument":
        case "com.amazonaws.sts#MalformedPolicyDocumentException":
            throw await deserializeAws_queryMalformedPolicyDocumentExceptionResponse(parsedOutput, context);
        case "PackedPolicyTooLarge":
        case "com.amazonaws.sts#PackedPolicyTooLargeException":
            throw await deserializeAws_queryPackedPolicyTooLargeExceptionResponse(parsedOutput, context);
        case "RegionDisabledException":
        case "com.amazonaws.sts#RegionDisabledException":
            throw await deserializeAws_queryRegionDisabledExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            throwDefaultError({
                output,
                parsedBody: parsedBody.Error,
                exceptionCtor: __BaseException,
                errorCode,
            });
    }
};
const deserializeAws_queryGetSessionTokenCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return deserializeAws_queryGetSessionTokenCommandError(output, context);
    }
    const data = await Aws_query_parseBody(output.body, context);
    let contents = {};
    contents = deserializeAws_queryGetSessionTokenResponse(data.GetSessionTokenResult, context);
    const response = {
        $metadata: Aws_query_deserializeMetadata(output),
        ...contents,
    };
    return Promise.resolve(response);
};
const deserializeAws_queryGetSessionTokenCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await Aws_query_parseErrorBody(output.body, context),
    };
    const errorCode = loadQueryErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "RegionDisabledException":
        case "com.amazonaws.sts#RegionDisabledException":
            throw await deserializeAws_queryRegionDisabledExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            throwDefaultError({
                output,
                parsedBody: parsedBody.Error,
                exceptionCtor: __BaseException,
                errorCode,
            });
    }
};
const deserializeAws_queryExpiredTokenExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_queryExpiredTokenException(body.Error, context);
    const exception = new ExpiredTokenException({
        $metadata: Aws_query_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_queryIDPCommunicationErrorExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_queryIDPCommunicationErrorException(body.Error, context);
    const exception = new IDPCommunicationErrorException({
        $metadata: Aws_query_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_queryIDPRejectedClaimExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_queryIDPRejectedClaimException(body.Error, context);
    const exception = new IDPRejectedClaimException({
        $metadata: Aws_query_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_queryInvalidAuthorizationMessageExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_queryInvalidAuthorizationMessageException(body.Error, context);
    const exception = new InvalidAuthorizationMessageException({
        $metadata: Aws_query_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return __decorateServiceException(exception, body);
};
const deserializeAws_queryInvalidIdentityTokenExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_queryInvalidIdentityTokenException(body.Error, context);
    const exception = new InvalidIdentityTokenException({
        $metadata: Aws_query_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_queryMalformedPolicyDocumentExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_queryMalformedPolicyDocumentException(body.Error, context);
    const exception = new MalformedPolicyDocumentException({
        $metadata: Aws_query_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_queryPackedPolicyTooLargeExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_queryPackedPolicyTooLargeException(body.Error, context);
    const exception = new PackedPolicyTooLargeException({
        $metadata: Aws_query_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const deserializeAws_queryRegionDisabledExceptionResponse = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = deserializeAws_queryRegionDisabledException(body.Error, context);
    const exception = new RegionDisabledException({
        $metadata: Aws_query_deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return decorateServiceException(exception, body);
};
const serializeAws_queryAssumeRoleRequest = (input, context) => {
    const entries = {};
    if (input.RoleArn != null) {
        entries["RoleArn"] = input.RoleArn;
    }
    if (input.RoleSessionName != null) {
        entries["RoleSessionName"] = input.RoleSessionName;
    }
    if (input.PolicyArns != null) {
        const memberEntries = serializeAws_querypolicyDescriptorListType(input.PolicyArns, context);
        Object.entries(memberEntries).forEach(([key, value]) => {
            const loc = `PolicyArns.${key}`;
            entries[loc] = value;
        });
    }
    if (input.Policy != null) {
        entries["Policy"] = input.Policy;
    }
    if (input.DurationSeconds != null) {
        entries["DurationSeconds"] = input.DurationSeconds;
    }
    if (input.Tags != null) {
        const memberEntries = serializeAws_querytagListType(input.Tags, context);
        Object.entries(memberEntries).forEach(([key, value]) => {
            const loc = `Tags.${key}`;
            entries[loc] = value;
        });
    }
    if (input.TransitiveTagKeys != null) {
        const memberEntries = serializeAws_querytagKeyListType(input.TransitiveTagKeys, context);
        Object.entries(memberEntries).forEach(([key, value]) => {
            const loc = `TransitiveTagKeys.${key}`;
            entries[loc] = value;
        });
    }
    if (input.ExternalId != null) {
        entries["ExternalId"] = input.ExternalId;
    }
    if (input.SerialNumber != null) {
        entries["SerialNumber"] = input.SerialNumber;
    }
    if (input.TokenCode != null) {
        entries["TokenCode"] = input.TokenCode;
    }
    if (input.SourceIdentity != null) {
        entries["SourceIdentity"] = input.SourceIdentity;
    }
    return entries;
};
const serializeAws_queryAssumeRoleWithSAMLRequest = (input, context) => {
    const entries = {};
    if (input.RoleArn != null) {
        entries["RoleArn"] = input.RoleArn;
    }
    if (input.PrincipalArn != null) {
        entries["PrincipalArn"] = input.PrincipalArn;
    }
    if (input.SAMLAssertion != null) {
        entries["SAMLAssertion"] = input.SAMLAssertion;
    }
    if (input.PolicyArns != null) {
        const memberEntries = serializeAws_querypolicyDescriptorListType(input.PolicyArns, context);
        Object.entries(memberEntries).forEach(([key, value]) => {
            const loc = `PolicyArns.${key}`;
            entries[loc] = value;
        });
    }
    if (input.Policy != null) {
        entries["Policy"] = input.Policy;
    }
    if (input.DurationSeconds != null) {
        entries["DurationSeconds"] = input.DurationSeconds;
    }
    return entries;
};
const serializeAws_queryAssumeRoleWithWebIdentityRequest = (input, context) => {
    const entries = {};
    if (input.RoleArn != null) {
        entries["RoleArn"] = input.RoleArn;
    }
    if (input.RoleSessionName != null) {
        entries["RoleSessionName"] = input.RoleSessionName;
    }
    if (input.WebIdentityToken != null) {
        entries["WebIdentityToken"] = input.WebIdentityToken;
    }
    if (input.ProviderId != null) {
        entries["ProviderId"] = input.ProviderId;
    }
    if (input.PolicyArns != null) {
        const memberEntries = serializeAws_querypolicyDescriptorListType(input.PolicyArns, context);
        Object.entries(memberEntries).forEach(([key, value]) => {
            const loc = `PolicyArns.${key}`;
            entries[loc] = value;
        });
    }
    if (input.Policy != null) {
        entries["Policy"] = input.Policy;
    }
    if (input.DurationSeconds != null) {
        entries["DurationSeconds"] = input.DurationSeconds;
    }
    return entries;
};
const serializeAws_queryDecodeAuthorizationMessageRequest = (input, context) => {
    const entries = {};
    if (input.EncodedMessage != null) {
        entries["EncodedMessage"] = input.EncodedMessage;
    }
    return entries;
};
const serializeAws_queryGetAccessKeyInfoRequest = (input, context) => {
    const entries = {};
    if (input.AccessKeyId != null) {
        entries["AccessKeyId"] = input.AccessKeyId;
    }
    return entries;
};
const serializeAws_queryGetCallerIdentityRequest = (input, context) => {
    const entries = {};
    return entries;
};
const serializeAws_queryGetFederationTokenRequest = (input, context) => {
    const entries = {};
    if (input.Name != null) {
        entries["Name"] = input.Name;
    }
    if (input.Policy != null) {
        entries["Policy"] = input.Policy;
    }
    if (input.PolicyArns != null) {
        const memberEntries = serializeAws_querypolicyDescriptorListType(input.PolicyArns, context);
        Object.entries(memberEntries).forEach(([key, value]) => {
            const loc = `PolicyArns.${key}`;
            entries[loc] = value;
        });
    }
    if (input.DurationSeconds != null) {
        entries["DurationSeconds"] = input.DurationSeconds;
    }
    if (input.Tags != null) {
        const memberEntries = serializeAws_querytagListType(input.Tags, context);
        Object.entries(memberEntries).forEach(([key, value]) => {
            const loc = `Tags.${key}`;
            entries[loc] = value;
        });
    }
    return entries;
};
const serializeAws_queryGetSessionTokenRequest = (input, context) => {
    const entries = {};
    if (input.DurationSeconds != null) {
        entries["DurationSeconds"] = input.DurationSeconds;
    }
    if (input.SerialNumber != null) {
        entries["SerialNumber"] = input.SerialNumber;
    }
    if (input.TokenCode != null) {
        entries["TokenCode"] = input.TokenCode;
    }
    return entries;
};
const serializeAws_querypolicyDescriptorListType = (input, context) => {
    const entries = {};
    let counter = 1;
    for (const entry of input) {
        if (entry === null) {
            continue;
        }
        const memberEntries = serializeAws_queryPolicyDescriptorType(entry, context);
        Object.entries(memberEntries).forEach(([key, value]) => {
            entries[`member.${counter}.${key}`] = value;
        });
        counter++;
    }
    return entries;
};
const serializeAws_queryPolicyDescriptorType = (input, context) => {
    const entries = {};
    if (input.arn != null) {
        entries["arn"] = input.arn;
    }
    return entries;
};
const serializeAws_queryTag = (input, context) => {
    const entries = {};
    if (input.Key != null) {
        entries["Key"] = input.Key;
    }
    if (input.Value != null) {
        entries["Value"] = input.Value;
    }
    return entries;
};
const serializeAws_querytagKeyListType = (input, context) => {
    const entries = {};
    let counter = 1;
    for (const entry of input) {
        if (entry === null) {
            continue;
        }
        entries[`member.${counter}`] = entry;
        counter++;
    }
    return entries;
};
const serializeAws_querytagListType = (input, context) => {
    const entries = {};
    let counter = 1;
    for (const entry of input) {
        if (entry === null) {
            continue;
        }
        const memberEntries = serializeAws_queryTag(entry, context);
        Object.entries(memberEntries).forEach(([key, value]) => {
            entries[`member.${counter}.${key}`] = value;
        });
        counter++;
    }
    return entries;
};
const deserializeAws_queryAssumedRoleUser = (output, context) => {
    const contents = {
        AssumedRoleId: undefined,
        Arn: undefined,
    };
    if (output["AssumedRoleId"] !== undefined) {
        contents.AssumedRoleId = expectString(output["AssumedRoleId"]);
    }
    if (output["Arn"] !== undefined) {
        contents.Arn = expectString(output["Arn"]);
    }
    return contents;
};
const deserializeAws_queryAssumeRoleResponse = (output, context) => {
    const contents = {
        Credentials: undefined,
        AssumedRoleUser: undefined,
        PackedPolicySize: undefined,
        SourceIdentity: undefined,
    };
    if (output["Credentials"] !== undefined) {
        contents.Credentials = deserializeAws_queryCredentials(output["Credentials"], context);
    }
    if (output["AssumedRoleUser"] !== undefined) {
        contents.AssumedRoleUser = deserializeAws_queryAssumedRoleUser(output["AssumedRoleUser"], context);
    }
    if (output["PackedPolicySize"] !== undefined) {
        contents.PackedPolicySize = strictParseInt32(output["PackedPolicySize"]);
    }
    if (output["SourceIdentity"] !== undefined) {
        contents.SourceIdentity = expectString(output["SourceIdentity"]);
    }
    return contents;
};
const deserializeAws_queryAssumeRoleWithSAMLResponse = (output, context) => {
    const contents = {
        Credentials: undefined,
        AssumedRoleUser: undefined,
        PackedPolicySize: undefined,
        Subject: undefined,
        SubjectType: undefined,
        Issuer: undefined,
        Audience: undefined,
        NameQualifier: undefined,
        SourceIdentity: undefined,
    };
    if (output["Credentials"] !== undefined) {
        contents.Credentials = deserializeAws_queryCredentials(output["Credentials"], context);
    }
    if (output["AssumedRoleUser"] !== undefined) {
        contents.AssumedRoleUser = deserializeAws_queryAssumedRoleUser(output["AssumedRoleUser"], context);
    }
    if (output["PackedPolicySize"] !== undefined) {
        contents.PackedPolicySize = __strictParseInt32(output["PackedPolicySize"]);
    }
    if (output["Subject"] !== undefined) {
        contents.Subject = __expectString(output["Subject"]);
    }
    if (output["SubjectType"] !== undefined) {
        contents.SubjectType = __expectString(output["SubjectType"]);
    }
    if (output["Issuer"] !== undefined) {
        contents.Issuer = __expectString(output["Issuer"]);
    }
    if (output["Audience"] !== undefined) {
        contents.Audience = __expectString(output["Audience"]);
    }
    if (output["NameQualifier"] !== undefined) {
        contents.NameQualifier = __expectString(output["NameQualifier"]);
    }
    if (output["SourceIdentity"] !== undefined) {
        contents.SourceIdentity = __expectString(output["SourceIdentity"]);
    }
    return contents;
};
const deserializeAws_queryAssumeRoleWithWebIdentityResponse = (output, context) => {
    const contents = {
        Credentials: undefined,
        SubjectFromWebIdentityToken: undefined,
        AssumedRoleUser: undefined,
        PackedPolicySize: undefined,
        Provider: undefined,
        Audience: undefined,
        SourceIdentity: undefined,
    };
    if (output["Credentials"] !== undefined) {
        contents.Credentials = deserializeAws_queryCredentials(output["Credentials"], context);
    }
    if (output["SubjectFromWebIdentityToken"] !== undefined) {
        contents.SubjectFromWebIdentityToken = expectString(output["SubjectFromWebIdentityToken"]);
    }
    if (output["AssumedRoleUser"] !== undefined) {
        contents.AssumedRoleUser = deserializeAws_queryAssumedRoleUser(output["AssumedRoleUser"], context);
    }
    if (output["PackedPolicySize"] !== undefined) {
        contents.PackedPolicySize = strictParseInt32(output["PackedPolicySize"]);
    }
    if (output["Provider"] !== undefined) {
        contents.Provider = expectString(output["Provider"]);
    }
    if (output["Audience"] !== undefined) {
        contents.Audience = expectString(output["Audience"]);
    }
    if (output["SourceIdentity"] !== undefined) {
        contents.SourceIdentity = expectString(output["SourceIdentity"]);
    }
    return contents;
};
const deserializeAws_queryCredentials = (output, context) => {
    const contents = {
        AccessKeyId: undefined,
        SecretAccessKey: undefined,
        SessionToken: undefined,
        Expiration: undefined,
    };
    if (output["AccessKeyId"] !== undefined) {
        contents.AccessKeyId = expectString(output["AccessKeyId"]);
    }
    if (output["SecretAccessKey"] !== undefined) {
        contents.SecretAccessKey = expectString(output["SecretAccessKey"]);
    }
    if (output["SessionToken"] !== undefined) {
        contents.SessionToken = expectString(output["SessionToken"]);
    }
    if (output["Expiration"] !== undefined) {
        contents.Expiration = expectNonNull(parseRfc3339DateTime(output["Expiration"]));
    }
    return contents;
};
const deserializeAws_queryDecodeAuthorizationMessageResponse = (output, context) => {
    const contents = {
        DecodedMessage: undefined,
    };
    if (output["DecodedMessage"] !== undefined) {
        contents.DecodedMessage = __expectString(output["DecodedMessage"]);
    }
    return contents;
};
const deserializeAws_queryExpiredTokenException = (output, context) => {
    const contents = {
        message: undefined,
    };
    if (output["message"] !== undefined) {
        contents.message = expectString(output["message"]);
    }
    return contents;
};
const deserializeAws_queryFederatedUser = (output, context) => {
    const contents = {
        FederatedUserId: undefined,
        Arn: undefined,
    };
    if (output["FederatedUserId"] !== undefined) {
        contents.FederatedUserId = __expectString(output["FederatedUserId"]);
    }
    if (output["Arn"] !== undefined) {
        contents.Arn = __expectString(output["Arn"]);
    }
    return contents;
};
const deserializeAws_queryGetAccessKeyInfoResponse = (output, context) => {
    const contents = {
        Account: undefined,
    };
    if (output["Account"] !== undefined) {
        contents.Account = __expectString(output["Account"]);
    }
    return contents;
};
const deserializeAws_queryGetCallerIdentityResponse = (output, context) => {
    const contents = {
        UserId: undefined,
        Account: undefined,
        Arn: undefined,
    };
    if (output["UserId"] !== undefined) {
        contents.UserId = __expectString(output["UserId"]);
    }
    if (output["Account"] !== undefined) {
        contents.Account = __expectString(output["Account"]);
    }
    if (output["Arn"] !== undefined) {
        contents.Arn = __expectString(output["Arn"]);
    }
    return contents;
};
const deserializeAws_queryGetFederationTokenResponse = (output, context) => {
    const contents = {
        Credentials: undefined,
        FederatedUser: undefined,
        PackedPolicySize: undefined,
    };
    if (output["Credentials"] !== undefined) {
        contents.Credentials = deserializeAws_queryCredentials(output["Credentials"], context);
    }
    if (output["FederatedUser"] !== undefined) {
        contents.FederatedUser = deserializeAws_queryFederatedUser(output["FederatedUser"], context);
    }
    if (output["PackedPolicySize"] !== undefined) {
        contents.PackedPolicySize = __strictParseInt32(output["PackedPolicySize"]);
    }
    return contents;
};
const deserializeAws_queryGetSessionTokenResponse = (output, context) => {
    const contents = {
        Credentials: undefined,
    };
    if (output["Credentials"] !== undefined) {
        contents.Credentials = deserializeAws_queryCredentials(output["Credentials"], context);
    }
    return contents;
};
const deserializeAws_queryIDPCommunicationErrorException = (output, context) => {
    const contents = {
        message: undefined,
    };
    if (output["message"] !== undefined) {
        contents.message = expectString(output["message"]);
    }
    return contents;
};
const deserializeAws_queryIDPRejectedClaimException = (output, context) => {
    const contents = {
        message: undefined,
    };
    if (output["message"] !== undefined) {
        contents.message = expectString(output["message"]);
    }
    return contents;
};
const deserializeAws_queryInvalidAuthorizationMessageException = (output, context) => {
    const contents = {
        message: undefined,
    };
    if (output["message"] !== undefined) {
        contents.message = __expectString(output["message"]);
    }
    return contents;
};
const deserializeAws_queryInvalidIdentityTokenException = (output, context) => {
    const contents = {
        message: undefined,
    };
    if (output["message"] !== undefined) {
        contents.message = expectString(output["message"]);
    }
    return contents;
};
const deserializeAws_queryMalformedPolicyDocumentException = (output, context) => {
    const contents = {
        message: undefined,
    };
    if (output["message"] !== undefined) {
        contents.message = expectString(output["message"]);
    }
    return contents;
};
const deserializeAws_queryPackedPolicyTooLargeException = (output, context) => {
    const contents = {
        message: undefined,
    };
    if (output["message"] !== undefined) {
        contents.message = expectString(output["message"]);
    }
    return contents;
};
const deserializeAws_queryRegionDisabledException = (output, context) => {
    const contents = {
        message: undefined,
    };
    if (output["message"] !== undefined) {
        contents.message = expectString(output["message"]);
    }
    return contents;
};
const Aws_query_deserializeMetadata = (output) => ({
    httpStatusCode: output.statusCode,
    requestId: output.headers["x-amzn-requestid"] ?? output.headers["x-amzn-request-id"] ?? output.headers["x-amz-request-id"],
    extendedRequestId: output.headers["x-amz-id-2"],
    cfId: output.headers["x-amz-cf-id"],
});
const Aws_query_collectBody = (streamBody = new Uint8Array(), context) => {
    if (streamBody instanceof Uint8Array) {
        return Promise.resolve(streamBody);
    }
    return context.streamCollector(streamBody) || Promise.resolve(new Uint8Array());
};
const Aws_query_collectBodyString = (streamBody, context) => Aws_query_collectBody(streamBody, context).then((body) => context.utf8Encoder(body));
const Aws_query_buildHttpRpcRequest = async (context, headers, path, resolvedHostname, body) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const contents = {
        protocol,
        hostname,
        port,
        method: "POST",
        path: basePath.endsWith("/") ? basePath.slice(0, -1) + path : basePath + path,
        headers,
    };
    if (resolvedHostname !== undefined) {
        contents.hostname = resolvedHostname;
    }
    if (body !== undefined) {
        contents.body = body;
    }
    return new httpRequest_HttpRequest(contents);
};
const Aws_query_parseBody = (streamBody, context) => Aws_query_collectBodyString(streamBody, context).then((encoded) => {
    if (encoded.length) {
        const parser = new fxp.XMLParser({
            attributeNamePrefix: "",
            htmlEntities: true,
            ignoreAttributes: false,
            ignoreDeclaration: true,
            parseTagValue: false,
            trimValues: false,
            tagValueProcessor: (_, val) => (val.trim() === "" && val.includes("\n") ? "" : undefined),
        });
        parser.addEntity("#xD", "\r");
        parser.addEntity("#10", "\n");
        const parsedObj = parser.parse(encoded);
        const textNodeName = "#text";
        const key = Object.keys(parsedObj)[0];
        const parsedObjToReturn = parsedObj[key];
        if (parsedObjToReturn[textNodeName]) {
            parsedObjToReturn[key] = parsedObjToReturn[textNodeName];
            delete parsedObjToReturn[textNodeName];
        }
        return getValueFromTextNode(parsedObjToReturn);
    }
    return {};
});
const Aws_query_parseErrorBody = async (errorBody, context) => {
    const value = await Aws_query_parseBody(errorBody, context);
    if (value.Error) {
        value.Error.message = value.Error.message ?? value.Error.Message;
    }
    return value;
};
const buildFormUrlencodedString = (formEntries) => Object.entries(formEntries)
    .map(([key, value]) => extendedEncodeURIComponent(key) + "=" + extendedEncodeURIComponent(value))
    .join("&");
const loadQueryErrorCode = (output, data) => {
    if (data.Error.Code !== undefined) {
        return data.Error.Code;
    }
    if (output.statusCode == 404) {
        return "NotFound";
    }
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sts/dist-es/commands/AssumeRoleCommand.js





class AssumeRoleCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        this.middlewareStack.use(getAwsAuthPlugin(configuration));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "STSClient";
        const commandName = "AssumeRoleCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: AssumeRoleRequestFilterSensitiveLog,
            outputFilterSensitiveLog: AssumeRoleResponseFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_queryAssumeRoleCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_queryAssumeRoleCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sts/dist-es/commands/AssumeRoleWithWebIdentityCommand.js




class AssumeRoleWithWebIdentityCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "STSClient";
        const commandName = "AssumeRoleWithWebIdentityCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: AssumeRoleWithWebIdentityRequestFilterSensitiveLog,
            outputFilterSensitiveLog: AssumeRoleWithWebIdentityResponseFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_queryAssumeRoleWithWebIdentityCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_queryAssumeRoleWithWebIdentityCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sts/dist-es/defaultStsRoleAssumers.js


const ASSUME_ROLE_DEFAULT_REGION = "us-east-1";
const decorateDefaultRegion = (region) => {
    if (typeof region !== "function") {
        return region === undefined ? ASSUME_ROLE_DEFAULT_REGION : region;
    }
    return async () => {
        try {
            return await region();
        }
        catch (e) {
            return ASSUME_ROLE_DEFAULT_REGION;
        }
    };
};
const getDefaultRoleAssumer = (stsOptions, stsClientCtor) => {
    let stsClient;
    let closureSourceCreds;
    return async (sourceCreds, params) => {
        closureSourceCreds = sourceCreds;
        if (!stsClient) {
            const { logger, region, requestHandler } = stsOptions;
            stsClient = new stsClientCtor({
                logger,
                credentialDefaultProvider: () => async () => closureSourceCreds,
                region: decorateDefaultRegion(region || stsOptions.region),
                ...(requestHandler ? { requestHandler } : {}),
            });
        }
        const { Credentials } = await stsClient.send(new AssumeRoleCommand(params));
        if (!Credentials || !Credentials.AccessKeyId || !Credentials.SecretAccessKey) {
            throw new Error(`Invalid response from STS.assumeRole call with role ${params.RoleArn}`);
        }
        return {
            accessKeyId: Credentials.AccessKeyId,
            secretAccessKey: Credentials.SecretAccessKey,
            sessionToken: Credentials.SessionToken,
            expiration: Credentials.Expiration,
        };
    };
};
const getDefaultRoleAssumerWithWebIdentity = (stsOptions, stsClientCtor) => {
    let stsClient;
    return async (params) => {
        if (!stsClient) {
            const { logger, region, requestHandler } = stsOptions;
            stsClient = new stsClientCtor({
                logger,
                region: decorateDefaultRegion(region || stsOptions.region),
                ...(requestHandler ? { requestHandler } : {}),
            });
        }
        const { Credentials } = await stsClient.send(new AssumeRoleWithWebIdentityCommand(params));
        if (!Credentials || !Credentials.AccessKeyId || !Credentials.SecretAccessKey) {
            throw new Error(`Invalid response from STS.assumeRoleWithWebIdentity call with role ${params.RoleArn}`);
        }
        return {
            accessKeyId: Credentials.AccessKeyId,
            secretAccessKey: Credentials.SecretAccessKey,
            sessionToken: Credentials.SessionToken,
            expiration: Credentials.Expiration,
        };
    };
};
const decorateDefaultCredentialProvider = (provider) => (input) => provider({
    roleAssumer: getDefaultRoleAssumer(input, input.stsClientCtor),
    roleAssumerWithWebIdentity: getDefaultRoleAssumerWithWebIdentity(input, input.stsClientCtor),
    ...input,
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/middleware-sdk-sts/dist-es/index.js

const resolveStsAuthConfig = (input, { stsClientCtor }) => resolveAwsAuthConfig({
    ...input,
    stsClientCtor,
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sts/package.json
const client_sts_package_namespaceObject = {"i8":"3.188.0"};
;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-env/dist-es/fromEnv.js

const ENV_KEY = "AWS_ACCESS_KEY_ID";
const ENV_SECRET = "AWS_SECRET_ACCESS_KEY";
const ENV_SESSION = "AWS_SESSION_TOKEN";
const ENV_EXPIRATION = "AWS_CREDENTIAL_EXPIRATION";
const fromEnv = () => async () => {
    const accessKeyId = process.env[ENV_KEY];
    const secretAccessKey = process.env[ENV_SECRET];
    const sessionToken = process.env[ENV_SESSION];
    const expiry = process.env[ENV_EXPIRATION];
    if (accessKeyId && secretAccessKey) {
        return {
            accessKeyId,
            secretAccessKey,
            ...(sessionToken && { sessionToken }),
            ...(expiry && { expiration: new Date(expiry) }),
        };
    }
    throw new CredentialsProviderError("Unable to find environment variable credentials.");
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-env/dist-es/index.js


;// CONCATENATED MODULE: external "os"
const external_os_namespaceObject = require("os");
;// CONCATENATED MODULE: external "path"
const external_path_namespaceObject = require("path");
;// CONCATENATED MODULE: ../node_modules/@aws-sdk/shared-ini-file-loader/dist-es/getHomeDir.js


const getHomeDir = () => {
    const { HOME, USERPROFILE, HOMEPATH, HOMEDRIVE = `C:${external_path_namespaceObject.sep}` } = process.env;
    if (HOME)
        return HOME;
    if (USERPROFILE)
        return USERPROFILE;
    if (HOMEPATH)
        return `${HOMEDRIVE}${HOMEPATH}`;
    return (0,external_os_namespaceObject.homedir)();
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/shared-ini-file-loader/dist-es/getProfileName.js
const ENV_PROFILE = "AWS_PROFILE";
const DEFAULT_PROFILE = "default";
const getProfileName = (init) => init.profile || process.env[ENV_PROFILE] || DEFAULT_PROFILE;

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/shared-ini-file-loader/dist-es/getSSOTokenFilepath.js



const getSSOTokenFilepath = (ssoStartUrl) => {
    const hasher = (0,external_crypto_namespaceObject.createHash)("sha1");
    const cacheName = hasher.update(ssoStartUrl).digest("hex");
    return (0,external_path_namespaceObject.join)(getHomeDir(), ".aws", "sso", "cache", `${cacheName}.json`);
};

;// CONCATENATED MODULE: external "fs"
const external_fs_namespaceObject = require("fs");
;// CONCATENATED MODULE: ../node_modules/@aws-sdk/shared-ini-file-loader/dist-es/getSSOTokenFromFile.js


const { readFile } = external_fs_namespaceObject.promises;
const getSSOTokenFromFile = async (ssoStartUrl) => {
    const ssoTokenFilepath = getSSOTokenFilepath(ssoStartUrl);
    const ssoTokenText = await readFile(ssoTokenFilepath, "utf8");
    return JSON.parse(ssoTokenText);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/shared-ini-file-loader/dist-es/getConfigFilepath.js


const ENV_CONFIG_PATH = "AWS_CONFIG_FILE";
const getConfigFilepath_getConfigFilepath = () => process.env[ENV_CONFIG_PATH] || (0,external_path_namespaceObject.join)(getHomeDir(), ".aws", "config");

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/shared-ini-file-loader/dist-es/getCredentialsFilepath.js


const ENV_CREDENTIALS_PATH = "AWS_SHARED_CREDENTIALS_FILE";
const getCredentialsFilepath = () => process.env[ENV_CREDENTIALS_PATH] || (0,external_path_namespaceObject.join)(getHomeDir(), ".aws", "credentials");

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/shared-ini-file-loader/dist-es/getProfileData.js
const profileKeyRegex = /^profile\s(["'])?([^\1]+)\1$/;
const getProfileData = (data) => Object.entries(data)
    .filter(([key]) => profileKeyRegex.test(key))
    .reduce((acc, [key, value]) => ({ ...acc, [profileKeyRegex.exec(key)[2]]: value }), {
    ...(data.default && { default: data.default }),
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/shared-ini-file-loader/dist-es/parseIni.js
const profileNameBlockList = ["__proto__", "profile __proto__"];
const parseIni_parseIni = (iniData) => {
    const map = {};
    let currentSection;
    for (let line of iniData.split(/\r?\n/)) {
        line = line.split(/(^|\s)[;#]/)[0].trim();
        const isSection = line[0] === "[" && line[line.length - 1] === "]";
        if (isSection) {
            currentSection = line.substring(1, line.length - 1);
            if (profileNameBlockList.includes(currentSection)) {
                throw new Error(`Found invalid profile name "${currentSection}"`);
            }
        }
        else if (currentSection) {
            const indexOfEqualsSign = line.indexOf("=");
            const start = 0;
            const end = line.length - 1;
            const isAssignment = indexOfEqualsSign !== -1 && indexOfEqualsSign !== start && indexOfEqualsSign !== end;
            if (isAssignment) {
                const [name, value] = [
                    line.substring(0, indexOfEqualsSign).trim(),
                    line.substring(indexOfEqualsSign + 1).trim(),
                ];
                map[currentSection] = map[currentSection] || {};
                map[currentSection][name] = value;
            }
        }
    }
    return map;
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/shared-ini-file-loader/dist-es/slurpFile.js

const { readFile: slurpFile_readFile } = external_fs_namespaceObject.promises;
const filePromisesHash = {};
const slurpFile_slurpFile = (path) => {
    if (!filePromisesHash[path]) {
        filePromisesHash[path] = slurpFile_readFile(path, "utf8");
    }
    return filePromisesHash[path];
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/shared-ini-file-loader/dist-es/loadSharedConfigFiles.js





const swallowError = () => ({});
const loadSharedConfigFiles = async (init = {}) => {
    const { filepath = getCredentialsFilepath(), configFilepath = getConfigFilepath_getConfigFilepath() } = init;
    const parsedFiles = await Promise.all([
        slurpFile_slurpFile(configFilepath).then(parseIni_parseIni).then(getProfileData).catch(swallowError),
        slurpFile_slurpFile(filepath).then(parseIni_parseIni).catch(swallowError),
    ]);
    return {
        configFile: parsedFiles[0],
        credentialsFile: parsedFiles[1],
    };
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/shared-ini-file-loader/dist-es/loadSsoSessionData.js




const loadSsoSessionData_swallowError = () => ({});
const loadSsoSessionData = async (init = {}) => slurpFile(init.configFilepath ?? getConfigFilepath())
    .then(parseIni)
    .then(getSsoSessionData)
    .catch(loadSsoSessionData_swallowError);

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/shared-ini-file-loader/dist-es/parseKnownFiles.js

const parseKnownFiles = async (init) => {
    const parsedFiles = await loadSharedConfigFiles(init);
    return {
        ...parsedFiles.configFile,
        ...parsedFiles.credentialsFile,
    };
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/shared-ini-file-loader/dist-es/index.js









;// CONCATENATED MODULE: external "url"
const external_url_namespaceObject = require("url");
;// CONCATENATED MODULE: external "buffer"
const external_buffer_namespaceObject = require("buffer");
;// CONCATENATED MODULE: external "http"
const external_http_namespaceObject = require("http");
;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-imds/dist-es/remoteProvider/httpRequest.js



function httpRequest(options) {
    return new Promise((resolve, reject) => {
        const req = (0,external_http_namespaceObject.request)({
            method: "GET",
            ...options,
            hostname: options.hostname?.replace(/^\[(.+)\]$/, "$1"),
        });
        req.on("error", (err) => {
            reject(Object.assign(new ProviderError_ProviderError("Unable to connect to instance metadata service"), err));
            req.destroy();
        });
        req.on("timeout", () => {
            reject(new ProviderError_ProviderError("TimeoutError from instance metadata service"));
            req.destroy();
        });
        req.on("response", (res) => {
            const { statusCode = 400 } = res;
            if (statusCode < 200 || 300 <= statusCode) {
                reject(Object.assign(new ProviderError_ProviderError("Error response received from instance metadata service"), { statusCode }));
                req.destroy();
            }
            const chunks = [];
            res.on("data", (chunk) => {
                chunks.push(chunk);
            });
            res.on("end", () => {
                resolve(external_buffer_namespaceObject.Buffer.concat(chunks));
                req.destroy();
            });
        });
        req.end();
    });
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-imds/dist-es/remoteProvider/ImdsCredentials.js
const isImdsCredentials = (arg) => Boolean(arg) &&
    typeof arg === "object" &&
    typeof arg.AccessKeyId === "string" &&
    typeof arg.SecretAccessKey === "string" &&
    typeof arg.Token === "string" &&
    typeof arg.Expiration === "string";
const fromImdsCredentials = (creds) => ({
    accessKeyId: creds.AccessKeyId,
    secretAccessKey: creds.SecretAccessKey,
    sessionToken: creds.Token,
    expiration: new Date(creds.Expiration),
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-imds/dist-es/remoteProvider/RemoteProviderInit.js
const DEFAULT_TIMEOUT = 1000;
const DEFAULT_MAX_RETRIES = 0;
const providerConfigFromInit = ({ maxRetries = DEFAULT_MAX_RETRIES, timeout = DEFAULT_TIMEOUT, }) => ({ maxRetries, timeout });

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-imds/dist-es/remoteProvider/retry.js
const retry = (toRetry, maxRetries) => {
    let promise = toRetry();
    for (let i = 0; i < maxRetries; i++) {
        promise = promise.catch(toRetry);
    }
    return promise;
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-imds/dist-es/fromContainerMetadata.js






const ENV_CMDS_FULL_URI = "AWS_CONTAINER_CREDENTIALS_FULL_URI";
const ENV_CMDS_RELATIVE_URI = "AWS_CONTAINER_CREDENTIALS_RELATIVE_URI";
const ENV_CMDS_AUTH_TOKEN = "AWS_CONTAINER_AUTHORIZATION_TOKEN";
const fromContainerMetadata = (init = {}) => {
    const { timeout, maxRetries } = providerConfigFromInit(init);
    return () => retry(async () => {
        const requestOptions = await getCmdsUri();
        const credsResponse = JSON.parse(await requestFromEcsImds(timeout, requestOptions));
        if (!isImdsCredentials(credsResponse)) {
            throw new CredentialsProviderError("Invalid response received from instance metadata service.");
        }
        return fromImdsCredentials(credsResponse);
    }, maxRetries);
};
const requestFromEcsImds = async (timeout, options) => {
    if (process.env[ENV_CMDS_AUTH_TOKEN]) {
        options.headers = {
            ...options.headers,
            Authorization: process.env[ENV_CMDS_AUTH_TOKEN],
        };
    }
    const buffer = await httpRequest({
        ...options,
        timeout,
    });
    return buffer.toString();
};
const CMDS_IP = "169.254.170.2";
const GREENGRASS_HOSTS = {
    localhost: true,
    "127.0.0.1": true,
};
const GREENGRASS_PROTOCOLS = {
    "http:": true,
    "https:": true,
};
const getCmdsUri = async () => {
    if (process.env[ENV_CMDS_RELATIVE_URI]) {
        return {
            hostname: CMDS_IP,
            path: process.env[ENV_CMDS_RELATIVE_URI],
        };
    }
    if (process.env[ENV_CMDS_FULL_URI]) {
        const parsed = (0,external_url_namespaceObject.parse)(process.env[ENV_CMDS_FULL_URI]);
        if (!parsed.hostname || !(parsed.hostname in GREENGRASS_HOSTS)) {
            throw new CredentialsProviderError(`${parsed.hostname} is not a valid container metadata service hostname`, false);
        }
        if (!parsed.protocol || !(parsed.protocol in GREENGRASS_PROTOCOLS)) {
            throw new CredentialsProviderError(`${parsed.protocol} is not a valid container metadata service protocol`, false);
        }
        return {
            ...parsed,
            port: parsed.port ? parseInt(parsed.port, 10) : undefined,
        };
    }
    throw new CredentialsProviderError("The container metadata credential provider cannot be used unless" +
        ` the ${ENV_CMDS_RELATIVE_URI} or ${ENV_CMDS_FULL_URI} environment` +
        " variable is set", false);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/node-config-provider/dist-es/fromEnv.js

const fromEnv_fromEnv = (envVarSelector) => async () => {
    try {
        const config = envVarSelector(process.env);
        if (config === undefined) {
            throw new Error();
        }
        return config;
    }
    catch (e) {
        throw new CredentialsProviderError(e.message || `Cannot load config from environment variables with getter: ${envVarSelector}`);
    }
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/node-config-provider/dist-es/fromSharedConfigFiles.js


const fromSharedConfigFiles = (configSelector, { preferredFile = "config", ...init } = {}) => async () => {
    const profile = getProfileName(init);
    const { configFile, credentialsFile } = await loadSharedConfigFiles(init);
    const profileFromCredentials = credentialsFile[profile] || {};
    const profileFromConfig = configFile[profile] || {};
    const mergedProfile = preferredFile === "config"
        ? { ...profileFromCredentials, ...profileFromConfig }
        : { ...profileFromConfig, ...profileFromCredentials };
    try {
        const configValue = configSelector(mergedProfile);
        if (configValue === undefined) {
            throw new Error();
        }
        return configValue;
    }
    catch (e) {
        throw new CredentialsProviderError(e.message ||
            `Cannot load config for profile ${profile} in SDK configuration files with getter: ${configSelector}`);
    }
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/node-config-provider/dist-es/fromStatic.js

const isFunction = (func) => typeof func === "function";
const fromStatic_fromStatic = (defaultValue) => isFunction(defaultValue) ? async () => await defaultValue() : fromStatic(defaultValue);

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/node-config-provider/dist-es/configLoader.js




const loadConfig = ({ environmentVariableSelector, configFileSelector, default: defaultValue }, configuration = {}) => memoize(chain(fromEnv_fromEnv(environmentVariableSelector), fromSharedConfigFiles(configFileSelector, configuration), fromStatic_fromStatic(defaultValue)));

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/node-config-provider/dist-es/index.js


;// CONCATENATED MODULE: ../node_modules/@aws-sdk/querystring-parser/dist-es/index.js
function parseQueryString(querystring) {
    const query = {};
    querystring = querystring.replace(/^\?/, "");
    if (querystring) {
        for (const pair of querystring.split("&")) {
            let [key, value = null] = pair.split("=");
            key = decodeURIComponent(key);
            if (value) {
                value = decodeURIComponent(value);
            }
            if (!(key in query)) {
                query[key] = value;
            }
            else if (Array.isArray(query[key])) {
                query[key].push(value);
            }
            else {
                query[key] = [query[key], value];
            }
        }
    }
    return query;
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/url-parser/dist-es/index.js

const parseUrl = (url) => {
    if (typeof url === 'string') {
        return parseUrl(new URL(url));
    }
    const { hostname, pathname, port, protocol, search } = url;
    let query;
    if (search) {
        query = parseQueryString(search);
    }
    return {
        hostname,
        port: port ? parseInt(port) : undefined,
        protocol,
        path: pathname,
        query,
    };
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-imds/dist-es/config/Endpoint.js
var Endpoint;
(function (Endpoint) {
    Endpoint["IPv4"] = "http://169.254.169.254";
    Endpoint["IPv6"] = "http://[fd00:ec2::254]";
})(Endpoint || (Endpoint = {}));

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-imds/dist-es/config/EndpointConfigOptions.js
const ENV_ENDPOINT_NAME = "AWS_EC2_METADATA_SERVICE_ENDPOINT";
const CONFIG_ENDPOINT_NAME = "ec2_metadata_service_endpoint";
const ENDPOINT_CONFIG_OPTIONS = {
    environmentVariableSelector: (env) => env[ENV_ENDPOINT_NAME],
    configFileSelector: (profile) => profile[CONFIG_ENDPOINT_NAME],
    default: undefined,
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-imds/dist-es/config/EndpointMode.js
var EndpointMode;
(function (EndpointMode) {
    EndpointMode["IPv4"] = "IPv4";
    EndpointMode["IPv6"] = "IPv6";
})(EndpointMode || (EndpointMode = {}));

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-imds/dist-es/config/EndpointModeConfigOptions.js

const ENV_ENDPOINT_MODE_NAME = "AWS_EC2_METADATA_SERVICE_ENDPOINT_MODE";
const CONFIG_ENDPOINT_MODE_NAME = "ec2_metadata_service_endpoint_mode";
const ENDPOINT_MODE_CONFIG_OPTIONS = {
    environmentVariableSelector: (env) => env[ENV_ENDPOINT_MODE_NAME],
    configFileSelector: (profile) => profile[CONFIG_ENDPOINT_MODE_NAME],
    default: EndpointMode.IPv4,
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-imds/dist-es/utils/getInstanceMetadataEndpoint.js






const getInstanceMetadataEndpoint = async () => parseUrl((await getFromEndpointConfig()) || (await getFromEndpointModeConfig()));
const getFromEndpointConfig = async () => loadConfig(ENDPOINT_CONFIG_OPTIONS)();
const getFromEndpointModeConfig = async () => {
    const endpointMode = await loadConfig(ENDPOINT_MODE_CONFIG_OPTIONS)();
    switch (endpointMode) {
        case EndpointMode.IPv4:
            return Endpoint.IPv4;
        case EndpointMode.IPv6:
            return Endpoint.IPv6;
        default:
            throw new Error(`Unsupported endpoint mode: ${endpointMode}.` + ` Select from ${Object.values(EndpointMode)}`);
    }
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-imds/dist-es/utils/getExtendedInstanceMetadataCredentials.js
const STATIC_STABILITY_REFRESH_INTERVAL_SECONDS = 5 * 60;
const STATIC_STABILITY_REFRESH_INTERVAL_JITTER_WINDOW_SECONDS = 5 * 60;
const STATIC_STABILITY_DOC_URL = "https://docs.aws.amazon.com/sdkref/latest/guide/feature-static-credentials.html";
const getExtendedInstanceMetadataCredentials = (credentials, logger) => {
    const refreshInterval = STATIC_STABILITY_REFRESH_INTERVAL_SECONDS +
        Math.floor(Math.random() * STATIC_STABILITY_REFRESH_INTERVAL_JITTER_WINDOW_SECONDS);
    const newExpiration = new Date(Date.now() + refreshInterval * 1000);
    logger.warn("Attempting credential expiration extension due to a credential service availability issue. A refresh of these " +
        "credentials will be attempted after ${new Date(newExpiration)}.\nFor more information, please visit: " +
        STATIC_STABILITY_DOC_URL);
    const originalExpiration = credentials.originalExpiration ?? credentials.expiration;
    return {
        ...credentials,
        ...(originalExpiration ? { originalExpiration } : {}),
        expiration: newExpiration,
    };
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-imds/dist-es/utils/staticStabilityProvider.js

const staticStabilityProvider = (provider, options = {}) => {
    const logger = options?.logger || console;
    let pastCredentials;
    return async () => {
        let credentials;
        try {
            credentials = await provider();
            if (credentials.expiration && credentials.expiration.getTime() < Date.now()) {
                credentials = getExtendedInstanceMetadataCredentials(credentials, logger);
            }
        }
        catch (e) {
            if (pastCredentials) {
                logger.warn("Credential renew failed: ", e);
                credentials = getExtendedInstanceMetadataCredentials(pastCredentials, logger);
            }
            else {
                throw e;
            }
        }
        pastCredentials = credentials;
        return credentials;
    };
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-imds/dist-es/fromInstanceMetadata.js







const IMDS_PATH = "/latest/meta-data/iam/security-credentials/";
const IMDS_TOKEN_PATH = "/latest/api/token";
const fromInstanceMetadata = (init = {}) => staticStabilityProvider(getInstanceImdsProvider(init), { logger: init.logger });
const getInstanceImdsProvider = (init) => {
    let disableFetchToken = false;
    const { timeout, maxRetries } = providerConfigFromInit(init);
    const getCredentials = async (maxRetries, options) => {
        const profile = (await retry(async () => {
            let profile;
            try {
                profile = await getProfile(options);
            }
            catch (err) {
                if (err.statusCode === 401) {
                    disableFetchToken = false;
                }
                throw err;
            }
            return profile;
        }, maxRetries)).trim();
        return retry(async () => {
            let creds;
            try {
                creds = await getCredentialsFromProfile(profile, options);
            }
            catch (err) {
                if (err.statusCode === 401) {
                    disableFetchToken = false;
                }
                throw err;
            }
            return creds;
        }, maxRetries);
    };
    return async () => {
        const endpoint = await getInstanceMetadataEndpoint();
        if (disableFetchToken) {
            return getCredentials(maxRetries, { ...endpoint, timeout });
        }
        else {
            let token;
            try {
                token = (await getMetadataToken({ ...endpoint, timeout })).toString();
            }
            catch (error) {
                if (error?.statusCode === 400) {
                    throw Object.assign(error, {
                        message: "EC2 Metadata token request returned error",
                    });
                }
                else if (error.message === "TimeoutError" || [403, 404, 405].includes(error.statusCode)) {
                    disableFetchToken = true;
                }
                return getCredentials(maxRetries, { ...endpoint, timeout });
            }
            return getCredentials(maxRetries, {
                ...endpoint,
                headers: {
                    "x-aws-ec2-metadata-token": token,
                },
                timeout,
            });
        }
    };
};
const getMetadataToken = async (options) => httpRequest({
    ...options,
    path: IMDS_TOKEN_PATH,
    method: "PUT",
    headers: {
        "x-aws-ec2-metadata-token-ttl-seconds": "21600",
    },
});
const getProfile = async (options) => (await httpRequest({ ...options, path: IMDS_PATH })).toString();
const getCredentialsFromProfile = async (profile, options) => {
    const credsResponse = JSON.parse((await httpRequest({
        ...options,
        path: IMDS_PATH + profile,
    })).toString());
    if (!isImdsCredentials(credsResponse)) {
        throw new CredentialsProviderError("Invalid response received from instance metadata service.");
    }
    return fromImdsCredentials(credsResponse);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-imds/dist-es/index.js







;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-ini/dist-es/resolveCredentialSource.js



const resolveCredentialSource = (credentialSource, profileName) => {
    const sourceProvidersMap = {
        EcsContainer: fromContainerMetadata,
        Ec2InstanceMetadata: fromInstanceMetadata,
        Environment: fromEnv,
    };
    if (credentialSource in sourceProvidersMap) {
        return sourceProvidersMap[credentialSource]();
    }
    else {
        throw new CredentialsProviderError(`Unsupported credential source in profile ${profileName}. Got ${credentialSource}, ` +
            `expected EcsContainer or Ec2InstanceMetadata or Environment.`);
    }
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-ini/dist-es/resolveAssumeRoleCredentials.js




const isAssumeRoleProfile = (arg) => Boolean(arg) &&
    typeof arg === "object" &&
    typeof arg.role_arn === "string" &&
    ["undefined", "string"].indexOf(typeof arg.role_session_name) > -1 &&
    ["undefined", "string"].indexOf(typeof arg.external_id) > -1 &&
    ["undefined", "string"].indexOf(typeof arg.mfa_serial) > -1 &&
    (isAssumeRoleWithSourceProfile(arg) || isAssumeRoleWithProviderProfile(arg));
const isAssumeRoleWithSourceProfile = (arg) => typeof arg.source_profile === "string" && typeof arg.credential_source === "undefined";
const isAssumeRoleWithProviderProfile = (arg) => typeof arg.credential_source === "string" && typeof arg.source_profile === "undefined";
const resolveAssumeRoleCredentials = async (profileName, profiles, options, visitedProfiles = {}) => {
    const data = profiles[profileName];
    if (!options.roleAssumer) {
        throw new CredentialsProviderError(`Profile ${profileName} requires a role to be assumed, but no role assumption callback was provided.`, false);
    }
    const { source_profile } = data;
    if (source_profile && source_profile in visitedProfiles) {
        throw new CredentialsProviderError(`Detected a cycle attempting to resolve credentials for profile` +
            ` ${getProfileName(options)}. Profiles visited: ` +
            Object.keys(visitedProfiles).join(", "), false);
    }
    const sourceCredsProvider = source_profile
        ? resolveProfileData(source_profile, profiles, options, {
            ...visitedProfiles,
            [source_profile]: true,
        })
        : resolveCredentialSource(data.credential_source, profileName)();
    const params = {
        RoleArn: data.role_arn,
        RoleSessionName: data.role_session_name || `aws-sdk-js-${Date.now()}`,
        ExternalId: data.external_id,
    };
    const { mfa_serial } = data;
    if (mfa_serial) {
        if (!options.mfaCodeProvider) {
            throw new CredentialsProviderError(`Profile ${profileName} requires multi-factor authentication, but no MFA code callback was provided.`, false);
        }
        params.SerialNumber = mfa_serial;
        params.TokenCode = await options.mfaCodeProvider(mfa_serial);
    }
    const sourceCreds = await sourceCredsProvider;
    return options.roleAssumer(sourceCreds, params);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-sso/dist-es/isSsoProfile.js
const isSsoProfile = (arg) => arg &&
    (typeof arg.sso_start_url === "string" ||
        typeof arg.sso_account_id === "string" ||
        typeof arg.sso_region === "string" ||
        typeof arg.sso_role_name === "string");

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sso/package.json
const client_sso_package_namespaceObject = {"i8":"3.188.0"};
;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-buffer-from/dist-es/index.js


const fromArrayBuffer = (input, offset = 0, length = input.byteLength - offset) => {
    if (!isArrayBuffer(input)) {
        throw new TypeError(`The "input" argument must be ArrayBuffer. Received type ${typeof input} (${input})`);
    }
    return external_buffer_namespaceObject.Buffer.from(input, offset, length);
};
const fromString = (input, encoding) => {
    if (typeof input !== "string") {
        throw new TypeError(`The "input" argument must be of type string. Received type ${typeof input} (${input})`);
    }
    return encoding ? external_buffer_namespaceObject.Buffer.from(input, encoding) : external_buffer_namespaceObject.Buffer.from(input);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/hash-node/dist-es/index.js



class Hash {
    constructor(algorithmIdentifier, secret) {
        this.hash = secret ? (0,external_crypto_namespaceObject.createHmac)(algorithmIdentifier, castSourceData(secret)) : (0,external_crypto_namespaceObject.createHash)(algorithmIdentifier);
    }
    update(toHash, encoding) {
        this.hash.update(castSourceData(toHash, encoding));
    }
    digest() {
        return Promise.resolve(this.hash.digest());
    }
}
function castSourceData(toCast, encoding) {
    if (external_buffer_namespaceObject.Buffer.isBuffer(toCast)) {
        return toCast;
    }
    if (typeof toCast === "string") {
        return fromString(toCast, encoding);
    }
    if (ArrayBuffer.isView(toCast)) {
        return fromArrayBuffer(toCast.buffer, toCast.byteOffset, toCast.byteLength);
    }
    return fromArrayBuffer(toCast);
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/querystring-builder/dist-es/index.js

function dist_es_buildQueryString(query) {
    const parts = [];
    for (let key of Object.keys(query).sort()) {
        const value = query[key];
        key = escapeUri(key);
        if (Array.isArray(value)) {
            for (let i = 0, iLen = value.length; i < iLen; i++) {
                parts.push(`${key}=${escapeUri(value[i])}`);
            }
        }
        else {
            let qsEntry = key;
            if (value || typeof value === "string") {
                qsEntry += `=${escapeUri(value)}`;
            }
            parts.push(qsEntry);
        }
    }
    return parts.join("&");
}

;// CONCATENATED MODULE: external "https"
const external_https_namespaceObject = require("https");
;// CONCATENATED MODULE: ../node_modules/@aws-sdk/node-http-handler/dist-es/constants.js
const constants_NODEJS_TIMEOUT_ERROR_CODES = ["ECONNRESET", "EPIPE", "ETIMEDOUT"];

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/node-http-handler/dist-es/get-transformed-headers.js
const get_transformed_headers_getTransformedHeaders = (headers) => {
    const transformedHeaders = {};
    for (const name of Object.keys(headers)) {
        const headerValues = headers[name];
        transformedHeaders[name] = Array.isArray(headerValues) ? headerValues.join(",") : headerValues;
    }
    return transformedHeaders;
};


;// CONCATENATED MODULE: ../node_modules/@aws-sdk/node-http-handler/dist-es/set-connection-timeout.js
const setConnectionTimeout = (request, reject, timeoutInMs = 0) => {
    if (!timeoutInMs) {
        return;
    }
    request.on("socket", (socket) => {
        if (socket.connecting) {
            const timeoutId = setTimeout(() => {
                request.destroy();
                reject(Object.assign(new Error(`Socket timed out without establishing a connection within ${timeoutInMs} ms`), {
                    name: "TimeoutError",
                }));
            }, timeoutInMs);
            socket.on("connect", () => {
                clearTimeout(timeoutId);
            });
        }
    });
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/node-http-handler/dist-es/set-socket-timeout.js
const setSocketTimeout = (request, reject, timeoutInMs = 0) => {
    request.setTimeout(timeoutInMs, () => {
        request.destroy();
        reject(Object.assign(new Error(`Connection timed out after ${timeoutInMs} ms`), { name: "TimeoutError" }));
    });
};

;// CONCATENATED MODULE: external "stream"
const external_stream_namespaceObject = require("stream");
;// CONCATENATED MODULE: ../node_modules/@aws-sdk/node-http-handler/dist-es/write-request-body.js

function write_request_body_writeRequestBody(httpRequest, request) {
    const expect = request.headers["Expect"] || request.headers["expect"];
    if (expect === "100-continue") {
        httpRequest.on("continue", () => {
            writeBody(httpRequest, request.body);
        });
    }
    else {
        writeBody(httpRequest, request.body);
    }
}
function writeBody(httpRequest, body) {
    if (body instanceof external_stream_namespaceObject.Readable) {
        body.pipe(httpRequest);
    }
    else if (body) {
        httpRequest.end(Buffer.from(body));
    }
    else {
        httpRequest.end();
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/node-http-handler/dist-es/node-http-handler.js









class NodeHttpHandler {
    constructor(options) {
        this.metadata = { handlerProtocol: "http/1.1" };
        this.configProvider = new Promise((resolve, reject) => {
            if (typeof options === "function") {
                options()
                    .then((_options) => {
                    resolve(this.resolveDefaultConfig(_options));
                })
                    .catch(reject);
            }
            else {
                resolve(this.resolveDefaultConfig(options));
            }
        });
    }
    resolveDefaultConfig(options) {
        const { connectionTimeout, socketTimeout, httpAgent, httpsAgent } = options || {};
        const keepAlive = true;
        const maxSockets = 50;
        return {
            connectionTimeout,
            socketTimeout,
            httpAgent: httpAgent || new external_http_namespaceObject.Agent({ keepAlive, maxSockets }),
            httpsAgent: httpsAgent || new external_https_namespaceObject.Agent({ keepAlive, maxSockets }),
        };
    }
    destroy() {
        this.config?.httpAgent?.destroy();
        this.config?.httpsAgent?.destroy();
    }
    async handle(request, { abortSignal } = {}) {
        if (!this.config) {
            this.config = await this.configProvider;
        }
        return new Promise((resolve, reject) => {
            if (!this.config) {
                throw new Error("Node HTTP request handler config is not resolved");
            }
            if (abortSignal?.aborted) {
                const abortError = new Error("Request aborted");
                abortError.name = "AbortError";
                reject(abortError);
                return;
            }
            const isSSL = request.protocol === "https:";
            const queryString = dist_es_buildQueryString(request.query || {});
            const nodeHttpsOptions = {
                headers: request.headers,
                host: request.hostname,
                method: request.method,
                path: queryString ? `${request.path}?${queryString}` : request.path,
                port: request.port,
                agent: isSSL ? this.config.httpsAgent : this.config.httpAgent,
            };
            const requestFunc = isSSL ? external_https_namespaceObject.request : external_http_namespaceObject.request;
            const req = requestFunc(nodeHttpsOptions, (res) => {
                const httpResponse = new httpResponse_HttpResponse({
                    statusCode: res.statusCode || -1,
                    headers: get_transformed_headers_getTransformedHeaders(res.headers),
                    body: res,
                });
                resolve({ response: httpResponse });
            });
            req.on("error", (err) => {
                if (constants_NODEJS_TIMEOUT_ERROR_CODES.includes(err.code)) {
                    reject(Object.assign(err, { name: "TimeoutError" }));
                }
                else {
                    reject(err);
                }
            });
            setConnectionTimeout(req, reject, this.config.connectionTimeout);
            setSocketTimeout(req, reject, this.config.socketTimeout);
            if (abortSignal) {
                abortSignal.onabort = () => {
                    req.abort();
                    const abortError = new Error("Request aborted");
                    abortError.name = "AbortError";
                    reject(abortError);
                };
            }
            write_request_body_writeRequestBody(req, request);
        });
    }
}

;// CONCATENATED MODULE: external "http2"
const external_http2_namespaceObject = require("http2");
;// CONCATENATED MODULE: ../node_modules/@aws-sdk/node-http-handler/dist-es/node-http2-handler.js





class NodeHttp2Handler {
    constructor(options) {
        this.metadata = { handlerProtocol: "h2" };
        this.configProvider = new Promise((resolve, reject) => {
            if (typeof options === "function") {
                options()
                    .then((opts) => {
                    resolve(opts || {});
                })
                    .catch(reject);
            }
            else {
                resolve(options || {});
            }
        });
        this.sessionCache = new Map();
    }
    destroy() {
        for (const sessions of this.sessionCache.values()) {
            sessions.forEach((session) => this.destroySession(session));
        }
        this.sessionCache.clear();
    }
    async handle(request, { abortSignal } = {}) {
        if (!this.config) {
            this.config = await this.configProvider;
        }
        const { requestTimeout, disableConcurrentStreams } = this.config;
        return new Promise((resolve, rejectOriginal) => {
            let fulfilled = false;
            if (abortSignal?.aborted) {
                fulfilled = true;
                const abortError = new Error("Request aborted");
                abortError.name = "AbortError";
                rejectOriginal(abortError);
                return;
            }
            const { hostname, method, port, protocol, path, query } = request;
            const authority = `${protocol}//${hostname}${port ? `:${port}` : ""}`;
            const session = this.getSession(authority, disableConcurrentStreams || false);
            const reject = (err) => {
                if (disableConcurrentStreams) {
                    this.destroySession(session);
                }
                fulfilled = true;
                rejectOriginal(err);
            };
            const queryString = buildQueryString(query || {});
            const req = session.request({
                ...request.headers,
                [constants.HTTP2_HEADER_PATH]: queryString ? `${path}?${queryString}` : path,
                [constants.HTTP2_HEADER_METHOD]: method,
            });
            session.ref();
            req.on("response", (headers) => {
                const httpResponse = new HttpResponse({
                    statusCode: headers[":status"] || -1,
                    headers: getTransformedHeaders(headers),
                    body: req,
                });
                fulfilled = true;
                resolve({ response: httpResponse });
                if (disableConcurrentStreams) {
                    session.close();
                    this.deleteSessionFromCache(authority, session);
                }
            });
            if (requestTimeout) {
                req.setTimeout(requestTimeout, () => {
                    req.close();
                    const timeoutError = new Error(`Stream timed out because of no activity for ${requestTimeout} ms`);
                    timeoutError.name = "TimeoutError";
                    reject(timeoutError);
                });
            }
            if (abortSignal) {
                abortSignal.onabort = () => {
                    req.close();
                    const abortError = new Error("Request aborted");
                    abortError.name = "AbortError";
                    reject(abortError);
                };
            }
            req.on("frameError", (type, code, id) => {
                reject(new Error(`Frame type id ${type} in stream id ${id} has failed with code ${code}.`));
            });
            req.on("error", reject);
            req.on("aborted", () => {
                reject(new Error(`HTTP/2 stream is abnormally aborted in mid-communication with result code ${req.rstCode}.`));
            });
            req.on("close", () => {
                session.unref();
                if (disableConcurrentStreams) {
                    session.destroy();
                }
                if (!fulfilled) {
                    reject(new Error("Unexpected error: http2 request did not get a response"));
                }
            });
            writeRequestBody(req, request);
        });
    }
    getSession(authority, disableConcurrentStreams) {
        const sessionCache = this.sessionCache;
        const existingSessions = sessionCache.get(authority) || [];
        if (existingSessions.length > 0 && !disableConcurrentStreams)
            return existingSessions[0];
        const newSession = connect(authority);
        newSession.unref();
        const destroySessionCb = () => {
            this.destroySession(newSession);
            this.deleteSessionFromCache(authority, newSession);
        };
        newSession.on("goaway", destroySessionCb);
        newSession.on("error", destroySessionCb);
        newSession.on("frameError", destroySessionCb);
        newSession.on("close", () => this.deleteSessionFromCache(authority, newSession));
        if (this.config?.sessionTimeout) {
            newSession.setTimeout(this.config.sessionTimeout, destroySessionCb);
        }
        existingSessions.push(newSession);
        sessionCache.set(authority, existingSessions);
        return newSession;
    }
    destroySession(session) {
        if (!session.destroyed) {
            session.destroy();
        }
    }
    deleteSessionFromCache(authority, session) {
        const existingSessions = this.sessionCache.get(authority) || [];
        if (!existingSessions.includes(session)) {
            return;
        }
        this.sessionCache.set(authority, existingSessions.filter((s) => s !== session));
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/node-http-handler/dist-es/stream-collector/collector.js

class Collector extends external_stream_namespaceObject.Writable {
    constructor() {
        super(...arguments);
        this.bufferedBytes = [];
    }
    _write(chunk, encoding, callback) {
        this.bufferedBytes.push(chunk);
        callback();
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/node-http-handler/dist-es/stream-collector/index.js

const streamCollector = (stream) => new Promise((resolve, reject) => {
    const collector = new Collector();
    stream.pipe(collector);
    stream.on("error", (err) => {
        collector.end();
        reject(err);
    });
    collector.on("error", reject);
    collector.on("finish", function () {
        const bytes = new Uint8Array(Buffer.concat(this.bufferedBytes));
        resolve(bytes);
    });
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/node-http-handler/dist-es/index.js




;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-base64-node/dist-es/index.js

const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;
function fromBase64(input) {
    if ((input.length * 3) % 4 !== 0) {
        throw new TypeError(`Incorrect padding on base64 string.`);
    }
    if (!BASE64_REGEX.exec(input)) {
        throw new TypeError(`Invalid base64 string.`);
    }
    const buffer = fromString(input, "base64");
    return new Uint8Array(buffer.buffer, buffer.byteOffset, buffer.byteLength);
}
function toBase64(input) {
    return fromArrayBuffer(input.buffer, input.byteOffset, input.byteLength).toString("base64");
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-body-length-node/dist-es/calculateBodyLength.js

const calculateBodyLength = (body) => {
    if (!body) {
        return 0;
    }
    if (typeof body === "string") {
        return Buffer.from(body).length;
    }
    else if (typeof body.byteLength === "number") {
        return body.byteLength;
    }
    else if (typeof body.size === "number") {
        return body.size;
    }
    else if (typeof body.path === "string" || Buffer.isBuffer(body.path)) {
        return (0,external_fs_namespaceObject.lstatSync)(body.path).size;
    }
    else if (typeof body.fd === "number") {
        return (0,external_fs_namespaceObject.fstatSync)(body.fd).size;
    }
    throw new Error(`Body Length computation failed for ${body}`);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-body-length-node/dist-es/index.js


;// CONCATENATED MODULE: external "process"
const external_process_namespaceObject = require("process");
// EXTERNAL MODULE: ../node_modules/@aws-sdk/util-user-agent-node/dist-es/is-crt-available.js
var is_crt_available = __webpack_require__(726);
;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-user-agent-node/dist-es/index.js




const UA_APP_ID_ENV_NAME = "AWS_SDK_UA_APP_ID";
const UA_APP_ID_INI_NAME = "sdk-ua-app-id";
const defaultUserAgent = ({ serviceId, clientVersion }) => {
    const sections = [
        ["aws-sdk-js", clientVersion],
        [`os/${(0,external_os_namespaceObject.platform)()}`, (0,external_os_namespaceObject.release)()],
        ["lang/js"],
        ["md/nodejs", `${external_process_namespaceObject.versions.node}`],
    ];
    const crtAvailable = (0,is_crt_available/* isCrtAvailable */.E)();
    if (crtAvailable) {
        sections.push(crtAvailable);
    }
    if (serviceId) {
        sections.push([`api/${serviceId}`, clientVersion]);
    }
    if (external_process_namespaceObject.env.AWS_EXECUTION_ENV) {
        sections.push([`exec-env/${external_process_namespaceObject.env.AWS_EXECUTION_ENV}`]);
    }
    const appIdPromise = loadConfig({
        environmentVariableSelector: (env) => env[UA_APP_ID_ENV_NAME],
        configFileSelector: (profile) => profile[UA_APP_ID_INI_NAME],
        default: undefined,
    })();
    let resolvedUserAgent = undefined;
    return async () => {
        if (!resolvedUserAgent) {
            const appId = await appIdPromise;
            resolvedUserAgent = appId ? [...sections, [`app/${appId}`]] : [...sections];
        }
        return resolvedUserAgent;
    };
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-utf8-node/dist-es/index.js

const fromUtf8 = (input) => {
    const buf = fromString(input, "utf8");
    return new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength / Uint8Array.BYTES_PER_ELEMENT);
};
const toUtf8 = (input) => fromArrayBuffer(input.buffer, input.byteOffset, input.byteLength).toString("utf8");

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sso/dist-es/endpoints.js

const regionHash = {
    "ap-east-1": {
        variants: [
            {
                hostname: "portal.sso.ap-east-1.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "ap-east-1",
    },
    "ap-northeast-1": {
        variants: [
            {
                hostname: "portal.sso.ap-northeast-1.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "ap-northeast-1",
    },
    "ap-northeast-2": {
        variants: [
            {
                hostname: "portal.sso.ap-northeast-2.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "ap-northeast-2",
    },
    "ap-northeast-3": {
        variants: [
            {
                hostname: "portal.sso.ap-northeast-3.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "ap-northeast-3",
    },
    "ap-south-1": {
        variants: [
            {
                hostname: "portal.sso.ap-south-1.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "ap-south-1",
    },
    "ap-southeast-1": {
        variants: [
            {
                hostname: "portal.sso.ap-southeast-1.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "ap-southeast-1",
    },
    "ap-southeast-2": {
        variants: [
            {
                hostname: "portal.sso.ap-southeast-2.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "ap-southeast-2",
    },
    "ca-central-1": {
        variants: [
            {
                hostname: "portal.sso.ca-central-1.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "ca-central-1",
    },
    "eu-central-1": {
        variants: [
            {
                hostname: "portal.sso.eu-central-1.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "eu-central-1",
    },
    "eu-north-1": {
        variants: [
            {
                hostname: "portal.sso.eu-north-1.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "eu-north-1",
    },
    "eu-south-1": {
        variants: [
            {
                hostname: "portal.sso.eu-south-1.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "eu-south-1",
    },
    "eu-west-1": {
        variants: [
            {
                hostname: "portal.sso.eu-west-1.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "eu-west-1",
    },
    "eu-west-2": {
        variants: [
            {
                hostname: "portal.sso.eu-west-2.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "eu-west-2",
    },
    "eu-west-3": {
        variants: [
            {
                hostname: "portal.sso.eu-west-3.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "eu-west-3",
    },
    "me-south-1": {
        variants: [
            {
                hostname: "portal.sso.me-south-1.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "me-south-1",
    },
    "sa-east-1": {
        variants: [
            {
                hostname: "portal.sso.sa-east-1.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "sa-east-1",
    },
    "us-east-1": {
        variants: [
            {
                hostname: "portal.sso.us-east-1.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "us-east-1",
    },
    "us-east-2": {
        variants: [
            {
                hostname: "portal.sso.us-east-2.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "us-east-2",
    },
    "us-gov-east-1": {
        variants: [
            {
                hostname: "portal.sso.us-gov-east-1.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "us-gov-east-1",
    },
    "us-gov-west-1": {
        variants: [
            {
                hostname: "portal.sso.us-gov-west-1.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "us-gov-west-1",
    },
    "us-west-2": {
        variants: [
            {
                hostname: "portal.sso.us-west-2.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "us-west-2",
    },
};
const partitionHash = {
    aws: {
        regions: [
            "af-south-1",
            "ap-east-1",
            "ap-northeast-1",
            "ap-northeast-2",
            "ap-northeast-3",
            "ap-south-1",
            "ap-southeast-1",
            "ap-southeast-2",
            "ap-southeast-3",
            "ca-central-1",
            "eu-central-1",
            "eu-north-1",
            "eu-south-1",
            "eu-west-1",
            "eu-west-2",
            "eu-west-3",
            "me-central-1",
            "me-south-1",
            "sa-east-1",
            "us-east-1",
            "us-east-2",
            "us-west-1",
            "us-west-2",
        ],
        regionRegex: "^(us|eu|ap|sa|ca|me|af)\\-\\w+\\-\\d+$",
        variants: [
            {
                hostname: "portal.sso.{region}.amazonaws.com",
                tags: [],
            },
            {
                hostname: "portal.sso-fips.{region}.amazonaws.com",
                tags: ["fips"],
            },
            {
                hostname: "portal.sso-fips.{region}.api.aws",
                tags: ["dualstack", "fips"],
            },
            {
                hostname: "portal.sso.{region}.api.aws",
                tags: ["dualstack"],
            },
        ],
    },
    "aws-cn": {
        regions: ["cn-north-1", "cn-northwest-1"],
        regionRegex: "^cn\\-\\w+\\-\\d+$",
        variants: [
            {
                hostname: "portal.sso.{region}.amazonaws.com.cn",
                tags: [],
            },
            {
                hostname: "portal.sso-fips.{region}.amazonaws.com.cn",
                tags: ["fips"],
            },
            {
                hostname: "portal.sso-fips.{region}.api.amazonwebservices.com.cn",
                tags: ["dualstack", "fips"],
            },
            {
                hostname: "portal.sso.{region}.api.amazonwebservices.com.cn",
                tags: ["dualstack"],
            },
        ],
    },
    "aws-iso": {
        regions: ["us-iso-east-1", "us-iso-west-1"],
        regionRegex: "^us\\-iso\\-\\w+\\-\\d+$",
        variants: [
            {
                hostname: "portal.sso.{region}.c2s.ic.gov",
                tags: [],
            },
            {
                hostname: "portal.sso-fips.{region}.c2s.ic.gov",
                tags: ["fips"],
            },
        ],
    },
    "aws-iso-b": {
        regions: ["us-isob-east-1"],
        regionRegex: "^us\\-isob\\-\\w+\\-\\d+$",
        variants: [
            {
                hostname: "portal.sso.{region}.sc2s.sgov.gov",
                tags: [],
            },
            {
                hostname: "portal.sso-fips.{region}.sc2s.sgov.gov",
                tags: ["fips"],
            },
        ],
    },
    "aws-us-gov": {
        regions: ["us-gov-east-1", "us-gov-west-1"],
        regionRegex: "^us\\-gov\\-\\w+\\-\\d+$",
        variants: [
            {
                hostname: "portal.sso.{region}.amazonaws.com",
                tags: [],
            },
            {
                hostname: "portal.sso-fips.{region}.amazonaws.com",
                tags: ["fips"],
            },
            {
                hostname: "portal.sso-fips.{region}.api.aws",
                tags: ["dualstack", "fips"],
            },
            {
                hostname: "portal.sso.{region}.api.aws",
                tags: ["dualstack"],
            },
        ],
    },
};
const defaultRegionInfoProvider = async (region, options) => getRegionInfo(region, {
    ...options,
    signingService: "awsssoportal",
    regionHash,
    partitionHash,
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sso/dist-es/runtimeConfig.shared.js


const getRuntimeConfig = (config) => ({
    apiVersion: "2019-06-10",
    disableHostPrefix: config?.disableHostPrefix ?? false,
    logger: config?.logger ?? {},
    regionInfoProvider: config?.regionInfoProvider ?? defaultRegionInfoProvider,
    serviceId: config?.serviceId ?? "SSO",
    urlParser: config?.urlParser ?? parseUrl,
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-defaults-mode-node/dist-es/constants.js
const AWS_EXECUTION_ENV = "AWS_EXECUTION_ENV";
const AWS_REGION_ENV = "AWS_REGION";
const AWS_DEFAULT_REGION_ENV = "AWS_DEFAULT_REGION";
const ENV_IMDS_DISABLED = "AWS_EC2_METADATA_DISABLED";
const DEFAULTS_MODE_OPTIONS = ["in-region", "cross-region", "mobile", "standard", "legacy"];
const IMDS_REGION_PATH = "/latest/meta-data/placement/region";

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-defaults-mode-node/dist-es/defaultsModeConfig.js
const AWS_DEFAULTS_MODE_ENV = "AWS_DEFAULTS_MODE";
const AWS_DEFAULTS_MODE_CONFIG = "defaults_mode";
const NODE_DEFAULTS_MODE_CONFIG_OPTIONS = {
    environmentVariableSelector: (env) => {
        return env[AWS_DEFAULTS_MODE_ENV];
    },
    configFileSelector: (profile) => {
        return profile[AWS_DEFAULTS_MODE_CONFIG];
    },
    default: "legacy",
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-defaults-mode-node/dist-es/resolveDefaultsModeConfig.js






const resolveDefaultsModeConfig = ({ region = loadConfig(NODE_REGION_CONFIG_OPTIONS), defaultsMode = loadConfig(NODE_DEFAULTS_MODE_CONFIG_OPTIONS), } = {}) => memoize(async () => {
    const mode = typeof defaultsMode === "function" ? await defaultsMode() : defaultsMode;
    switch (mode?.toLowerCase()) {
        case "auto":
            return resolveNodeDefaultsModeAuto(region);
        case "in-region":
        case "cross-region":
        case "mobile":
        case "standard":
        case "legacy":
            return Promise.resolve(mode?.toLocaleLowerCase());
        case undefined:
            return Promise.resolve("legacy");
        default:
            throw new Error(`Invalid parameter for "defaultsMode", expect ${DEFAULTS_MODE_OPTIONS.join(", ")}, got ${mode}`);
    }
});
const resolveNodeDefaultsModeAuto = async (clientRegion) => {
    if (clientRegion) {
        const resolvedRegion = typeof clientRegion === "function" ? await clientRegion() : clientRegion;
        const inferredRegion = await inferPhysicalRegion();
        if (!inferredRegion) {
            return "standard";
        }
        if (resolvedRegion === inferredRegion) {
            return "in-region";
        }
        else {
            return "cross-region";
        }
    }
    return "standard";
};
const inferPhysicalRegion = async () => {
    if (process.env[AWS_EXECUTION_ENV] && (process.env[AWS_REGION_ENV] || process.env[AWS_DEFAULT_REGION_ENV])) {
        return process.env[AWS_REGION_ENV] ?? process.env[AWS_DEFAULT_REGION_ENV];
    }
    if (!process.env[ENV_IMDS_DISABLED]) {
        try {
            const endpoint = await getInstanceMetadataEndpoint();
            return (await httpRequest({ ...endpoint, path: IMDS_REGION_PATH })).toString();
        }
        catch (e) {
        }
    }
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-defaults-mode-node/dist-es/index.js


;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sso/dist-es/runtimeConfig.js














const runtimeConfig_getRuntimeConfig = (config) => {
    emitWarningIfUnsupportedVersion(process.version);
    const defaultsMode = resolveDefaultsModeConfig(config);
    const defaultConfigProvider = () => defaultsMode().then(loadConfigsForDefaultMode);
    const clientSharedValues = getRuntimeConfig(config);
    return {
        ...clientSharedValues,
        ...config,
        runtime: "node",
        defaultsMode,
        base64Decoder: config?.base64Decoder ?? fromBase64,
        base64Encoder: config?.base64Encoder ?? toBase64,
        bodyLengthChecker: config?.bodyLengthChecker ?? calculateBodyLength,
        defaultUserAgentProvider: config?.defaultUserAgentProvider ??
            defaultUserAgent({ serviceId: clientSharedValues.serviceId, clientVersion: client_sso_package_namespaceObject.i8 }),
        maxAttempts: config?.maxAttempts ?? loadConfig(NODE_MAX_ATTEMPT_CONFIG_OPTIONS),
        region: config?.region ?? loadConfig(NODE_REGION_CONFIG_OPTIONS, NODE_REGION_CONFIG_FILE_OPTIONS),
        requestHandler: config?.requestHandler ?? new NodeHttpHandler(defaultConfigProvider),
        retryMode: config?.retryMode ??
            loadConfig({
                ...NODE_RETRY_MODE_CONFIG_OPTIONS,
                default: async () => (await defaultConfigProvider()).retryMode || DEFAULT_RETRY_MODE,
            }),
        sha256: config?.sha256 ?? Hash.bind(null, "sha256"),
        streamCollector: config?.streamCollector ?? streamCollector,
        useDualstackEndpoint: config?.useDualstackEndpoint ?? loadConfig(NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS),
        useFipsEndpoint: config?.useFipsEndpoint ?? loadConfig(NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS),
        utf8Decoder: config?.utf8Decoder ?? fromUtf8,
        utf8Encoder: config?.utf8Encoder ?? toUtf8,
    };
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sso/dist-es/SSOClient.js









class SSOClient extends Client {
    constructor(configuration) {
        const _config_0 = runtimeConfig_getRuntimeConfig(configuration);
        const _config_1 = resolveRegionConfig(_config_0);
        const _config_2 = resolveEndpointsConfig(_config_1);
        const _config_3 = resolveRetryConfig(_config_2);
        const _config_4 = resolveHostHeaderConfig(_config_3);
        const _config_5 = resolveUserAgentConfig(_config_4);
        super(_config_5);
        this.config = _config_5;
        this.middlewareStack.use(getRetryPlugin(this.config));
        this.middlewareStack.use(getContentLengthPlugin(this.config));
        this.middlewareStack.use(getHostHeaderPlugin(this.config));
        this.middlewareStack.use(getLoggerPlugin(this.config));
        this.middlewareStack.use(getRecursionDetectionPlugin(this.config));
        this.middlewareStack.use(getUserAgentPlugin(this.config));
    }
    destroy() {
        super.destroy();
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sso/dist-es/models/SSOServiceException.js

class SSOServiceException extends ServiceException {
    constructor(options) {
        super(options);
        Object.setPrototypeOf(this, SSOServiceException.prototype);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sso/dist-es/models/models_0.js


class InvalidRequestException extends SSOServiceException {
    constructor(opts) {
        super({
            name: "InvalidRequestException",
            $fault: "client",
            ...opts,
        });
        this.name = "InvalidRequestException";
        this.$fault = "client";
        Object.setPrototypeOf(this, InvalidRequestException.prototype);
    }
}
class models_0_ResourceNotFoundException extends SSOServiceException {
    constructor(opts) {
        super({
            name: "ResourceNotFoundException",
            $fault: "client",
            ...opts,
        });
        this.name = "ResourceNotFoundException";
        this.$fault = "client";
        Object.setPrototypeOf(this, models_0_ResourceNotFoundException.prototype);
    }
}
class TooManyRequestsException extends SSOServiceException {
    constructor(opts) {
        super({
            name: "TooManyRequestsException",
            $fault: "client",
            ...opts,
        });
        this.name = "TooManyRequestsException";
        this.$fault = "client";
        Object.setPrototypeOf(this, TooManyRequestsException.prototype);
    }
}
class UnauthorizedException extends SSOServiceException {
    constructor(opts) {
        super({
            name: "UnauthorizedException",
            $fault: "client",
            ...opts,
        });
        this.name = "UnauthorizedException";
        this.$fault = "client";
        Object.setPrototypeOf(this, UnauthorizedException.prototype);
    }
}
const AccountInfoFilterSensitiveLog = (obj) => ({
    ...obj,
});
const GetRoleCredentialsRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.accessToken && { accessToken: constants_SENSITIVE_STRING }),
});
const RoleCredentialsFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.secretAccessKey && { secretAccessKey: constants_SENSITIVE_STRING }),
    ...(obj.sessionToken && { sessionToken: constants_SENSITIVE_STRING }),
});
const GetRoleCredentialsResponseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.roleCredentials && { roleCredentials: RoleCredentialsFilterSensitiveLog(obj.roleCredentials) }),
});
const ListAccountRolesRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.accessToken && { accessToken: SENSITIVE_STRING }),
});
const RoleInfoFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ListAccountRolesResponseFilterSensitiveLog = (obj) => ({
    ...obj,
});
const ListAccountsRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.accessToken && { accessToken: SENSITIVE_STRING }),
});
const ListAccountsResponseFilterSensitiveLog = (obj) => ({
    ...obj,
});
const LogoutRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.accessToken && { accessToken: SENSITIVE_STRING }),
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sso/dist-es/protocols/Aws_restJson1.js




const serializeAws_restJson1GetRoleCredentialsCommand = async (input, context) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const headers = Aws_restJson1_map({}, isSerializableHeaderValue, {
        "x-amz-sso_bearer_token": input.accessToken,
    });
    const resolvedPath = `${basePath?.endsWith("/") ? basePath.slice(0, -1) : basePath || ""}` + "/federation/credentials";
    const query = Aws_restJson1_map({
        role_name: [, input.roleName],
        account_id: [, input.accountId],
    });
    let body;
    return new httpRequest_HttpRequest({
        protocol,
        hostname,
        port,
        method: "GET",
        headers,
        path: resolvedPath,
        query,
        body,
    });
};
const serializeAws_restJson1ListAccountRolesCommand = async (input, context) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const headers = Aws_restJson1_map({}, isSerializableHeaderValue, {
        "x-amz-sso_bearer_token": input.accessToken,
    });
    const resolvedPath = `${basePath?.endsWith("/") ? basePath.slice(0, -1) : basePath || ""}` + "/assignment/roles";
    const query = Aws_restJson1_map({
        next_token: [, input.nextToken],
        max_result: [() => input.maxResults !== void 0, () => input.maxResults.toString()],
        account_id: [, input.accountId],
    });
    let body;
    return new __HttpRequest({
        protocol,
        hostname,
        port,
        method: "GET",
        headers,
        path: resolvedPath,
        query,
        body,
    });
};
const serializeAws_restJson1ListAccountsCommand = async (input, context) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const headers = Aws_restJson1_map({}, isSerializableHeaderValue, {
        "x-amz-sso_bearer_token": input.accessToken,
    });
    const resolvedPath = `${basePath?.endsWith("/") ? basePath.slice(0, -1) : basePath || ""}` + "/assignment/accounts";
    const query = Aws_restJson1_map({
        next_token: [, input.nextToken],
        max_result: [() => input.maxResults !== void 0, () => input.maxResults.toString()],
    });
    let body;
    return new __HttpRequest({
        protocol,
        hostname,
        port,
        method: "GET",
        headers,
        path: resolvedPath,
        query,
        body,
    });
};
const serializeAws_restJson1LogoutCommand = async (input, context) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const headers = Aws_restJson1_map({}, isSerializableHeaderValue, {
        "x-amz-sso_bearer_token": input.accessToken,
    });
    const resolvedPath = `${basePath?.endsWith("/") ? basePath.slice(0, -1) : basePath || ""}` + "/logout";
    let body;
    return new __HttpRequest({
        protocol,
        hostname,
        port,
        method: "POST",
        headers,
        path: resolvedPath,
        body,
    });
};
const deserializeAws_restJson1GetRoleCredentialsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return deserializeAws_restJson1GetRoleCredentialsCommandError(output, context);
    }
    const contents = Aws_restJson1_map({
        $metadata: Aws_restJson1_deserializeMetadata(output),
    });
    const data = expectNonNull(expectObject(await Aws_restJson1_parseBody(output.body, context)), "body");
    if (data.roleCredentials != null) {
        contents.roleCredentials = deserializeAws_restJson1RoleCredentials(data.roleCredentials, context);
    }
    return contents;
};
const deserializeAws_restJson1GetRoleCredentialsCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await Aws_restJson1_parseErrorBody(output.body, context),
    };
    const errorCode = Aws_restJson1_loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InvalidRequestException":
        case "com.amazonaws.sso#InvalidRequestException":
            throw await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.sso#ResourceNotFoundException":
            throw await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context);
        case "TooManyRequestsException":
        case "com.amazonaws.sso#TooManyRequestsException":
            throw await deserializeAws_restJson1TooManyRequestsExceptionResponse(parsedOutput, context);
        case "UnauthorizedException":
        case "com.amazonaws.sso#UnauthorizedException":
            throw await deserializeAws_restJson1UnauthorizedExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            default_error_handler_throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: SSOServiceException,
                errorCode,
            });
    }
};
const deserializeAws_restJson1ListAccountRolesCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return deserializeAws_restJson1ListAccountRolesCommandError(output, context);
    }
    const contents = Aws_restJson1_map({
        $metadata: Aws_restJson1_deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await Aws_restJson1_parseBody(output.body, context)), "body");
    if (data.nextToken != null) {
        contents.nextToken = __expectString(data.nextToken);
    }
    if (data.roleList != null) {
        contents.roleList = deserializeAws_restJson1RoleListType(data.roleList, context);
    }
    return contents;
};
const deserializeAws_restJson1ListAccountRolesCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await Aws_restJson1_parseErrorBody(output.body, context),
    };
    const errorCode = Aws_restJson1_loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InvalidRequestException":
        case "com.amazonaws.sso#InvalidRequestException":
            throw await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.sso#ResourceNotFoundException":
            throw await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context);
        case "TooManyRequestsException":
        case "com.amazonaws.sso#TooManyRequestsException":
            throw await deserializeAws_restJson1TooManyRequestsExceptionResponse(parsedOutput, context);
        case "UnauthorizedException":
        case "com.amazonaws.sso#UnauthorizedException":
            throw await deserializeAws_restJson1UnauthorizedExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: __BaseException,
                errorCode,
            });
    }
};
const deserializeAws_restJson1ListAccountsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return deserializeAws_restJson1ListAccountsCommandError(output, context);
    }
    const contents = Aws_restJson1_map({
        $metadata: Aws_restJson1_deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await Aws_restJson1_parseBody(output.body, context)), "body");
    if (data.accountList != null) {
        contents.accountList = deserializeAws_restJson1AccountListType(data.accountList, context);
    }
    if (data.nextToken != null) {
        contents.nextToken = __expectString(data.nextToken);
    }
    return contents;
};
const deserializeAws_restJson1ListAccountsCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await Aws_restJson1_parseErrorBody(output.body, context),
    };
    const errorCode = Aws_restJson1_loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InvalidRequestException":
        case "com.amazonaws.sso#InvalidRequestException":
            throw await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.sso#ResourceNotFoundException":
            throw await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context);
        case "TooManyRequestsException":
        case "com.amazonaws.sso#TooManyRequestsException":
            throw await deserializeAws_restJson1TooManyRequestsExceptionResponse(parsedOutput, context);
        case "UnauthorizedException":
        case "com.amazonaws.sso#UnauthorizedException":
            throw await deserializeAws_restJson1UnauthorizedExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: __BaseException,
                errorCode,
            });
    }
};
const deserializeAws_restJson1LogoutCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return deserializeAws_restJson1LogoutCommandError(output, context);
    }
    const contents = Aws_restJson1_map({
        $metadata: Aws_restJson1_deserializeMetadata(output),
    });
    await Aws_restJson1_collectBody(output.body, context);
    return contents;
};
const deserializeAws_restJson1LogoutCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await Aws_restJson1_parseErrorBody(output.body, context),
    };
    const errorCode = Aws_restJson1_loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InvalidRequestException":
        case "com.amazonaws.sso#InvalidRequestException":
            throw await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context);
        case "TooManyRequestsException":
        case "com.amazonaws.sso#TooManyRequestsException":
            throw await deserializeAws_restJson1TooManyRequestsExceptionResponse(parsedOutput, context);
        case "UnauthorizedException":
        case "com.amazonaws.sso#UnauthorizedException":
            throw await deserializeAws_restJson1UnauthorizedExceptionResponse(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            throwDefaultError({
                output,
                parsedBody,
                exceptionCtor: __BaseException,
                errorCode,
            });
    }
};
const Aws_restJson1_map = map;
const deserializeAws_restJson1InvalidRequestExceptionResponse = async (parsedOutput, context) => {
    const contents = Aws_restJson1_map({});
    const data = parsedOutput.body;
    if (data.message != null) {
        contents.message = expectString(data.message);
    }
    const exception = new InvalidRequestException({
        $metadata: Aws_restJson1_deserializeMetadata(parsedOutput),
        ...contents,
    });
    return decorateServiceException(exception, parsedOutput.body);
};
const deserializeAws_restJson1ResourceNotFoundExceptionResponse = async (parsedOutput, context) => {
    const contents = Aws_restJson1_map({});
    const data = parsedOutput.body;
    if (data.message != null) {
        contents.message = expectString(data.message);
    }
    const exception = new models_0_ResourceNotFoundException({
        $metadata: Aws_restJson1_deserializeMetadata(parsedOutput),
        ...contents,
    });
    return decorateServiceException(exception, parsedOutput.body);
};
const deserializeAws_restJson1TooManyRequestsExceptionResponse = async (parsedOutput, context) => {
    const contents = Aws_restJson1_map({});
    const data = parsedOutput.body;
    if (data.message != null) {
        contents.message = expectString(data.message);
    }
    const exception = new TooManyRequestsException({
        $metadata: Aws_restJson1_deserializeMetadata(parsedOutput),
        ...contents,
    });
    return decorateServiceException(exception, parsedOutput.body);
};
const deserializeAws_restJson1UnauthorizedExceptionResponse = async (parsedOutput, context) => {
    const contents = Aws_restJson1_map({});
    const data = parsedOutput.body;
    if (data.message != null) {
        contents.message = expectString(data.message);
    }
    const exception = new UnauthorizedException({
        $metadata: Aws_restJson1_deserializeMetadata(parsedOutput),
        ...contents,
    });
    return decorateServiceException(exception, parsedOutput.body);
};
const deserializeAws_restJson1AccountInfo = (output, context) => {
    return {
        accountId: __expectString(output.accountId),
        accountName: __expectString(output.accountName),
        emailAddress: __expectString(output.emailAddress),
    };
};
const deserializeAws_restJson1AccountListType = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_restJson1AccountInfo(entry, context);
    });
    return retVal;
};
const deserializeAws_restJson1RoleCredentials = (output, context) => {
    return {
        accessKeyId: expectString(output.accessKeyId),
        expiration: expectLong(output.expiration),
        secretAccessKey: expectString(output.secretAccessKey),
        sessionToken: expectString(output.sessionToken),
    };
};
const deserializeAws_restJson1RoleInfo = (output, context) => {
    return {
        accountId: __expectString(output.accountId),
        roleName: __expectString(output.roleName),
    };
};
const deserializeAws_restJson1RoleListType = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        if (entry === null) {
            return null;
        }
        return deserializeAws_restJson1RoleInfo(entry, context);
    });
    return retVal;
};
const Aws_restJson1_deserializeMetadata = (output) => ({
    httpStatusCode: output.statusCode,
    requestId: output.headers["x-amzn-requestid"] ?? output.headers["x-amzn-request-id"] ?? output.headers["x-amz-request-id"],
    extendedRequestId: output.headers["x-amz-id-2"],
    cfId: output.headers["x-amz-cf-id"],
});
const Aws_restJson1_collectBody = (streamBody = new Uint8Array(), context) => {
    if (streamBody instanceof Uint8Array) {
        return Promise.resolve(streamBody);
    }
    return context.streamCollector(streamBody) || Promise.resolve(new Uint8Array());
};
const Aws_restJson1_collectBodyString = (streamBody, context) => Aws_restJson1_collectBody(streamBody, context).then((body) => context.utf8Encoder(body));
const isSerializableHeaderValue = (value) => value !== undefined &&
    value !== null &&
    value !== "" &&
    (!Object.getOwnPropertyNames(value).includes("length") || value.length != 0) &&
    (!Object.getOwnPropertyNames(value).includes("size") || value.size != 0);
const Aws_restJson1_parseBody = (streamBody, context) => Aws_restJson1_collectBodyString(streamBody, context).then((encoded) => {
    if (encoded.length) {
        return JSON.parse(encoded);
    }
    return {};
});
const Aws_restJson1_parseErrorBody = async (errorBody, context) => {
    const value = await Aws_restJson1_parseBody(errorBody, context);
    value.message = value.message ?? value.Message;
    return value;
};
const Aws_restJson1_loadRestJsonErrorCode = (output, data) => {
    const findKey = (object, key) => Object.keys(object).find((k) => k.toLowerCase() === key.toLowerCase());
    const sanitizeErrorCode = (rawValue) => {
        let cleanValue = rawValue;
        if (typeof cleanValue === "number") {
            cleanValue = cleanValue.toString();
        }
        if (cleanValue.indexOf(",") >= 0) {
            cleanValue = cleanValue.split(",")[0];
        }
        if (cleanValue.indexOf(":") >= 0) {
            cleanValue = cleanValue.split(":")[0];
        }
        if (cleanValue.indexOf("#") >= 0) {
            cleanValue = cleanValue.split("#")[1];
        }
        return cleanValue;
    };
    const headerKey = findKey(output.headers, "x-amzn-errortype");
    if (headerKey !== undefined) {
        return sanitizeErrorCode(output.headers[headerKey]);
    }
    if (data.code !== undefined) {
        return sanitizeErrorCode(data.code);
    }
    if (data["__type"] !== undefined) {
        return sanitizeErrorCode(data["__type"]);
    }
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sso/dist-es/commands/GetRoleCredentialsCommand.js




class GetRoleCredentialsCommand extends Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "SSOClient";
        const commandName = "GetRoleCredentialsCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: GetRoleCredentialsRequestFilterSensitiveLog,
            outputFilterSensitiveLog: GetRoleCredentialsResponseFilterSensitiveLog,
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return serializeAws_restJson1GetRoleCredentialsCommand(input, context);
    }
    deserialize(output, context) {
        return deserializeAws_restJson1GetRoleCredentialsCommand(output, context);
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-sso/dist-es/resolveSSOCredentials.js



const EXPIRE_WINDOW_MS = 15 * 60 * 1000;
const SHOULD_FAIL_CREDENTIAL_CHAIN = false;
const resolveSSOCredentials = async ({ ssoStartUrl, ssoAccountId, ssoRegion, ssoRoleName, ssoClient, }) => {
    let token;
    const refreshMessage = `To refresh this SSO session run aws sso login with the corresponding profile.`;
    try {
        token = await getSSOTokenFromFile(ssoStartUrl);
    }
    catch (e) {
        throw new CredentialsProviderError(`The SSO session associated with this profile is invalid. ${refreshMessage}`, SHOULD_FAIL_CREDENTIAL_CHAIN);
    }
    if (new Date(token.expiresAt).getTime() - Date.now() <= EXPIRE_WINDOW_MS) {
        throw new CredentialsProviderError(`The SSO session associated with this profile has expired. ${refreshMessage}`, SHOULD_FAIL_CREDENTIAL_CHAIN);
    }
    const { accessToken } = token;
    const sso = ssoClient || new SSOClient({ region: ssoRegion });
    let ssoResp;
    try {
        ssoResp = await sso.send(new GetRoleCredentialsCommand({
            accountId: ssoAccountId,
            roleName: ssoRoleName,
            accessToken,
        }));
    }
    catch (e) {
        throw CredentialsProviderError.from(e, SHOULD_FAIL_CREDENTIAL_CHAIN);
    }
    const { roleCredentials: { accessKeyId, secretAccessKey, sessionToken, expiration } = {} } = ssoResp;
    if (!accessKeyId || !secretAccessKey || !sessionToken || !expiration) {
        throw new CredentialsProviderError("SSO returns an invalid temporary credential.", SHOULD_FAIL_CREDENTIAL_CHAIN);
    }
    return { accessKeyId, secretAccessKey, sessionToken, expiration: new Date(expiration) };
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-sso/dist-es/validateSsoProfile.js

const validateSsoProfile = (profile) => {
    const { sso_start_url, sso_account_id, sso_region, sso_role_name } = profile;
    if (!sso_start_url || !sso_account_id || !sso_region || !sso_role_name) {
        throw new CredentialsProviderError(`Profile is configured with invalid SSO credentials. Required parameters "sso_account_id", "sso_region", ` +
            `"sso_role_name", "sso_start_url". Got ${Object.keys(profile).join(", ")}\nReference: https://docs.aws.amazon.com/cli/latest/userguide/cli-configure-sso.html`, false);
    }
    return profile;
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-sso/dist-es/fromSSO.js





const fromSSO = (init = {}) => async () => {
    const { ssoStartUrl, ssoAccountId, ssoRegion, ssoRoleName, ssoClient } = init;
    if (!ssoStartUrl && !ssoAccountId && !ssoRegion && !ssoRoleName) {
        const profiles = await parseKnownFiles(init);
        const profileName = getProfileName(init);
        const profile = profiles[profileName];
        if (!isSsoProfile(profile)) {
            throw new CredentialsProviderError(`Profile ${profileName} is not configured with SSO credentials.`);
        }
        const { sso_start_url, sso_account_id, sso_region, sso_role_name } = validateSsoProfile(profile);
        return resolveSSOCredentials({
            ssoStartUrl: sso_start_url,
            ssoAccountId: sso_account_id,
            ssoRegion: sso_region,
            ssoRoleName: sso_role_name,
            ssoClient: ssoClient,
        });
    }
    else if (!ssoStartUrl || !ssoAccountId || !ssoRegion || !ssoRoleName) {
        throw new CredentialsProviderError('Incomplete configuration. The fromSSO() argument hash must include "ssoStartUrl",' +
            ' "ssoAccountId", "ssoRegion", "ssoRoleName"');
    }
    else {
        return resolveSSOCredentials({ ssoStartUrl, ssoAccountId, ssoRegion, ssoRoleName, ssoClient });
    }
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-sso/dist-es/index.js





;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-ini/dist-es/resolveSsoCredentials.js


const resolveSsoCredentials = (data) => {
    const { sso_start_url, sso_account_id, sso_region, sso_role_name } = validateSsoProfile(data);
    return fromSSO({
        ssoStartUrl: sso_start_url,
        ssoAccountId: sso_account_id,
        ssoRegion: sso_region,
        ssoRoleName: sso_role_name,
    })();
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-ini/dist-es/resolveStaticCredentials.js
const isStaticCredsProfile = (arg) => Boolean(arg) &&
    typeof arg === "object" &&
    typeof arg.aws_access_key_id === "string" &&
    typeof arg.aws_secret_access_key === "string" &&
    ["undefined", "string"].indexOf(typeof arg.aws_session_token) > -1;
const resolveStaticCredentials = (profile) => Promise.resolve({
    accessKeyId: profile.aws_access_key_id,
    secretAccessKey: profile.aws_secret_access_key,
    sessionToken: profile.aws_session_token,
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-web-identity/dist-es/fromWebToken.js

const fromWebToken = (init) => () => {
    const { roleArn, roleSessionName, webIdentityToken, providerId, policyArns, policy, durationSeconds, roleAssumerWithWebIdentity, } = init;
    if (!roleAssumerWithWebIdentity) {
        throw new CredentialsProviderError(`Role Arn '${roleArn}' needs to be assumed with web identity,` +
            ` but no role assumption callback was provided.`, false);
    }
    return roleAssumerWithWebIdentity({
        RoleArn: roleArn,
        RoleSessionName: roleSessionName ?? `aws-sdk-js-session-${Date.now()}`,
        WebIdentityToken: webIdentityToken,
        ProviderId: providerId,
        PolicyArns: policyArns,
        Policy: policy,
        DurationSeconds: durationSeconds,
    });
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-web-identity/dist-es/fromTokenFile.js



const ENV_TOKEN_FILE = "AWS_WEB_IDENTITY_TOKEN_FILE";
const ENV_ROLE_ARN = "AWS_ROLE_ARN";
const ENV_ROLE_SESSION_NAME = "AWS_ROLE_SESSION_NAME";
const fromTokenFile = (init = {}) => async () => {
    return resolveTokenFile(init);
};
const resolveTokenFile = (init) => {
    const webIdentityTokenFile = init?.webIdentityTokenFile ?? process.env[ENV_TOKEN_FILE];
    const roleArn = init?.roleArn ?? process.env[ENV_ROLE_ARN];
    const roleSessionName = init?.roleSessionName ?? process.env[ENV_ROLE_SESSION_NAME];
    if (!webIdentityTokenFile || !roleArn) {
        throw new CredentialsProviderError("Web identity configuration not specified");
    }
    return fromWebToken({
        ...init,
        webIdentityToken: (0,external_fs_namespaceObject.readFileSync)(webIdentityTokenFile, { encoding: "ascii" }),
        roleArn,
        roleSessionName,
    })();
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-web-identity/dist-es/index.js



;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-ini/dist-es/resolveWebIdentityCredentials.js

const isWebIdentityProfile = (arg) => Boolean(arg) &&
    typeof arg === "object" &&
    typeof arg.web_identity_token_file === "string" &&
    typeof arg.role_arn === "string" &&
    ["undefined", "string"].indexOf(typeof arg.role_session_name) > -1;
const resolveWebIdentityCredentials = async (profile, options) => fromTokenFile({
    webIdentityTokenFile: profile.web_identity_token_file,
    roleArn: profile.role_arn,
    roleSessionName: profile.role_session_name,
    roleAssumerWithWebIdentity: options.roleAssumerWithWebIdentity,
})();

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-ini/dist-es/resolveProfileData.js





const resolveProfileData = async (profileName, profiles, options, visitedProfiles = {}) => {
    const data = profiles[profileName];
    if (Object.keys(visitedProfiles).length > 0 && isStaticCredsProfile(data)) {
        return resolveStaticCredentials(data);
    }
    if (isAssumeRoleProfile(data)) {
        return resolveAssumeRoleCredentials(profileName, profiles, options, visitedProfiles);
    }
    if (isStaticCredsProfile(data)) {
        return resolveStaticCredentials(data);
    }
    if (isWebIdentityProfile(data)) {
        return resolveWebIdentityCredentials(data, options);
    }
    if (isSsoProfile(data)) {
        return resolveSsoCredentials(data);
    }
    throw new CredentialsProviderError(`Profile ${profileName} could not be found or parsed in shared credentials file.`);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-ini/dist-es/fromIni.js


const fromIni = (init = {}) => async () => {
    const profiles = await parseKnownFiles(init);
    return resolveProfileData(getProfileName(init), profiles, init);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-ini/dist-es/index.js


;// CONCATENATED MODULE: external "child_process"
const external_child_process_namespaceObject = require("child_process");
;// CONCATENATED MODULE: external "util"
const external_util_namespaceObject = require("util");
;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-process/dist-es/getValidatedProcessCredentials.js
const getValidatedProcessCredentials = (profileName, data) => {
    if (data.Version !== 1) {
        throw Error(`Profile ${profileName} credential_process did not return Version 1.`);
    }
    if (data.AccessKeyId === undefined || data.SecretAccessKey === undefined) {
        throw Error(`Profile ${profileName} credential_process returned invalid credentials.`);
    }
    if (data.Expiration) {
        const currentTime = new Date();
        const expireTime = new Date(data.Expiration);
        if (expireTime < currentTime) {
            throw Error(`Profile ${profileName} credential_process returned expired credentials.`);
        }
    }
    return {
        accessKeyId: data.AccessKeyId,
        secretAccessKey: data.SecretAccessKey,
        ...(data.SessionToken && { sessionToken: data.SessionToken }),
        ...(data.Expiration && { expiration: new Date(data.Expiration) }),
    };
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-process/dist-es/resolveProcessCredentials.js




const resolveProcessCredentials = async (profileName, profiles) => {
    const profile = profiles[profileName];
    if (profiles[profileName]) {
        const credentialProcess = profile["credential_process"];
        if (credentialProcess !== undefined) {
            const execPromise = (0,external_util_namespaceObject.promisify)(external_child_process_namespaceObject.exec);
            try {
                const { stdout } = await execPromise(credentialProcess);
                let data;
                try {
                    data = JSON.parse(stdout.trim());
                }
                catch {
                    throw Error(`Profile ${profileName} credential_process returned invalid JSON.`);
                }
                return getValidatedProcessCredentials(profileName, data);
            }
            catch (error) {
                throw new CredentialsProviderError(error.message);
            }
        }
        else {
            throw new CredentialsProviderError(`Profile ${profileName} did not contain credential_process.`);
        }
    }
    else {
        throw new CredentialsProviderError(`Profile ${profileName} could not be found in shared credentials file.`);
    }
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-process/dist-es/fromProcess.js


const fromProcess = (init = {}) => async () => {
    const profiles = await parseKnownFiles(init);
    return resolveProcessCredentials(getProfileName(init), profiles);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-process/dist-es/index.js


;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-node/dist-es/remoteProvider.js


const remoteProvider_ENV_IMDS_DISABLED = "AWS_EC2_METADATA_DISABLED";
const remoteProvider = (init) => {
    if (process.env[ENV_CMDS_RELATIVE_URI] || process.env[ENV_CMDS_FULL_URI]) {
        return fromContainerMetadata(init);
    }
    if (process.env[remoteProvider_ENV_IMDS_DISABLED]) {
        return async () => {
            throw new CredentialsProviderError("EC2 Instance Metadata Service access disabled");
        };
    }
    return fromInstanceMetadata(init);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-node/dist-es/defaultProvider.js








const defaultProvider = (init = {}) => memoize(chain(...(init.profile || process.env[ENV_PROFILE] ? [] : [fromEnv()]), fromSSO(init), fromIni(init), fromProcess(init), fromTokenFile(init), remoteProvider(init), async () => {
    throw new CredentialsProviderError("Could not load credentials from any providers", false);
}), (credentials) => credentials.expiration !== undefined && credentials.expiration.getTime() - Date.now() < 300000, (credentials) => credentials.expiration !== undefined);

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/credential-provider-node/dist-es/index.js


;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sts/dist-es/endpoints.js

const endpoints_regionHash = {
    "aws-global": {
        variants: [
            {
                hostname: "sts.amazonaws.com",
                tags: [],
            },
        ],
        signingRegion: "us-east-1",
    },
    "us-east-1": {
        variants: [
            {
                hostname: "sts-fips.us-east-1.amazonaws.com",
                tags: ["fips"],
            },
        ],
    },
    "us-east-2": {
        variants: [
            {
                hostname: "sts-fips.us-east-2.amazonaws.com",
                tags: ["fips"],
            },
        ],
    },
    "us-gov-east-1": {
        variants: [
            {
                hostname: "sts.us-gov-east-1.amazonaws.com",
                tags: ["fips"],
            },
        ],
    },
    "us-gov-west-1": {
        variants: [
            {
                hostname: "sts.us-gov-west-1.amazonaws.com",
                tags: ["fips"],
            },
        ],
    },
    "us-west-1": {
        variants: [
            {
                hostname: "sts-fips.us-west-1.amazonaws.com",
                tags: ["fips"],
            },
        ],
    },
    "us-west-2": {
        variants: [
            {
                hostname: "sts-fips.us-west-2.amazonaws.com",
                tags: ["fips"],
            },
        ],
    },
};
const endpoints_partitionHash = {
    aws: {
        regions: [
            "af-south-1",
            "ap-east-1",
            "ap-northeast-1",
            "ap-northeast-2",
            "ap-northeast-3",
            "ap-south-1",
            "ap-southeast-1",
            "ap-southeast-2",
            "ap-southeast-3",
            "aws-global",
            "ca-central-1",
            "eu-central-1",
            "eu-north-1",
            "eu-south-1",
            "eu-west-1",
            "eu-west-2",
            "eu-west-3",
            "me-central-1",
            "me-south-1",
            "sa-east-1",
            "us-east-1",
            "us-east-1-fips",
            "us-east-2",
            "us-east-2-fips",
            "us-west-1",
            "us-west-1-fips",
            "us-west-2",
            "us-west-2-fips",
        ],
        regionRegex: "^(us|eu|ap|sa|ca|me|af)\\-\\w+\\-\\d+$",
        variants: [
            {
                hostname: "sts.{region}.amazonaws.com",
                tags: [],
            },
            {
                hostname: "sts-fips.{region}.amazonaws.com",
                tags: ["fips"],
            },
            {
                hostname: "sts-fips.{region}.api.aws",
                tags: ["dualstack", "fips"],
            },
            {
                hostname: "sts.{region}.api.aws",
                tags: ["dualstack"],
            },
        ],
    },
    "aws-cn": {
        regions: ["cn-north-1", "cn-northwest-1"],
        regionRegex: "^cn\\-\\w+\\-\\d+$",
        variants: [
            {
                hostname: "sts.{region}.amazonaws.com.cn",
                tags: [],
            },
            {
                hostname: "sts-fips.{region}.amazonaws.com.cn",
                tags: ["fips"],
            },
            {
                hostname: "sts-fips.{region}.api.amazonwebservices.com.cn",
                tags: ["dualstack", "fips"],
            },
            {
                hostname: "sts.{region}.api.amazonwebservices.com.cn",
                tags: ["dualstack"],
            },
        ],
    },
    "aws-iso": {
        regions: ["us-iso-east-1", "us-iso-west-1"],
        regionRegex: "^us\\-iso\\-\\w+\\-\\d+$",
        variants: [
            {
                hostname: "sts.{region}.c2s.ic.gov",
                tags: [],
            },
            {
                hostname: "sts-fips.{region}.c2s.ic.gov",
                tags: ["fips"],
            },
        ],
    },
    "aws-iso-b": {
        regions: ["us-isob-east-1"],
        regionRegex: "^us\\-isob\\-\\w+\\-\\d+$",
        variants: [
            {
                hostname: "sts.{region}.sc2s.sgov.gov",
                tags: [],
            },
            {
                hostname: "sts-fips.{region}.sc2s.sgov.gov",
                tags: ["fips"],
            },
        ],
    },
    "aws-us-gov": {
        regions: ["us-gov-east-1", "us-gov-east-1-fips", "us-gov-west-1", "us-gov-west-1-fips"],
        regionRegex: "^us\\-gov\\-\\w+\\-\\d+$",
        variants: [
            {
                hostname: "sts.{region}.amazonaws.com",
                tags: [],
            },
            {
                hostname: "sts.{region}.amazonaws.com",
                tags: ["fips"],
            },
            {
                hostname: "sts-fips.{region}.api.aws",
                tags: ["dualstack", "fips"],
            },
            {
                hostname: "sts.{region}.api.aws",
                tags: ["dualstack"],
            },
        ],
    },
};
const endpoints_defaultRegionInfoProvider = async (region, options) => getRegionInfo(region, {
    ...options,
    signingService: "sts",
    regionHash: endpoints_regionHash,
    partitionHash: endpoints_partitionHash,
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sts/dist-es/runtimeConfig.shared.js


const runtimeConfig_shared_getRuntimeConfig = (config) => ({
    apiVersion: "2011-06-15",
    disableHostPrefix: config?.disableHostPrefix ?? false,
    logger: config?.logger ?? {},
    regionInfoProvider: config?.regionInfoProvider ?? endpoints_defaultRegionInfoProvider,
    serviceId: config?.serviceId ?? "STS",
    urlParser: config?.urlParser ?? parseUrl,
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sts/dist-es/runtimeConfig.js
















const dist_es_runtimeConfig_getRuntimeConfig = (config) => {
    emitWarningIfUnsupportedVersion(process.version);
    const defaultsMode = resolveDefaultsModeConfig(config);
    const defaultConfigProvider = () => defaultsMode().then(loadConfigsForDefaultMode);
    const clientSharedValues = runtimeConfig_shared_getRuntimeConfig(config);
    return {
        ...clientSharedValues,
        ...config,
        runtime: "node",
        defaultsMode,
        base64Decoder: config?.base64Decoder ?? fromBase64,
        base64Encoder: config?.base64Encoder ?? toBase64,
        bodyLengthChecker: config?.bodyLengthChecker ?? calculateBodyLength,
        credentialDefaultProvider: config?.credentialDefaultProvider ?? decorateDefaultCredentialProvider(defaultProvider),
        defaultUserAgentProvider: config?.defaultUserAgentProvider ??
            defaultUserAgent({ serviceId: clientSharedValues.serviceId, clientVersion: client_sts_package_namespaceObject.i8 }),
        maxAttempts: config?.maxAttempts ?? loadConfig(NODE_MAX_ATTEMPT_CONFIG_OPTIONS),
        region: config?.region ?? loadConfig(NODE_REGION_CONFIG_OPTIONS, NODE_REGION_CONFIG_FILE_OPTIONS),
        requestHandler: config?.requestHandler ?? new NodeHttpHandler(defaultConfigProvider),
        retryMode: config?.retryMode ??
            loadConfig({
                ...NODE_RETRY_MODE_CONFIG_OPTIONS,
                default: async () => (await defaultConfigProvider()).retryMode || DEFAULT_RETRY_MODE,
            }),
        sha256: config?.sha256 ?? Hash.bind(null, "sha256"),
        streamCollector: config?.streamCollector ?? streamCollector,
        useDualstackEndpoint: config?.useDualstackEndpoint ?? loadConfig(NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS),
        useFipsEndpoint: config?.useFipsEndpoint ?? loadConfig(NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS),
        utf8Decoder: config?.utf8Decoder ?? fromUtf8,
        utf8Encoder: config?.utf8Encoder ?? toUtf8,
    };
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sts/dist-es/STSClient.js










class STSClient extends Client {
    constructor(configuration) {
        const _config_0 = dist_es_runtimeConfig_getRuntimeConfig(configuration);
        const _config_1 = resolveRegionConfig(_config_0);
        const _config_2 = resolveEndpointsConfig(_config_1);
        const _config_3 = resolveRetryConfig(_config_2);
        const _config_4 = resolveHostHeaderConfig(_config_3);
        const _config_5 = resolveStsAuthConfig(_config_4, { stsClientCtor: STSClient });
        const _config_6 = resolveUserAgentConfig(_config_5);
        super(_config_6);
        this.config = _config_6;
        this.middlewareStack.use(getRetryPlugin(this.config));
        this.middlewareStack.use(getContentLengthPlugin(this.config));
        this.middlewareStack.use(getHostHeaderPlugin(this.config));
        this.middlewareStack.use(getLoggerPlugin(this.config));
        this.middlewareStack.use(getRecursionDetectionPlugin(this.config));
        this.middlewareStack.use(getUserAgentPlugin(this.config));
    }
    destroy() {
        super.destroy();
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-sts/dist-es/defaultRoleAssumers.js


const getCustomizableStsClientCtor = (baseCtor, customizations) => {
    if (!customizations)
        return baseCtor;
    else
        return class CustomizableSTSClient extends baseCtor {
            constructor(config) {
                super(config);
                for (const customization of customizations) {
                    this.middlewareStack.use(customization);
                }
            }
        };
};
const defaultRoleAssumers_getDefaultRoleAssumer = (stsOptions = {}, stsPlugins) => getDefaultRoleAssumer(stsOptions, getCustomizableStsClientCtor(STSClient, stsPlugins));
const defaultRoleAssumers_getDefaultRoleAssumerWithWebIdentity = (stsOptions = {}, stsPlugins) => getDefaultRoleAssumerWithWebIdentity(stsOptions, getCustomizableStsClientCtor(STSClient, stsPlugins));
const defaultRoleAssumers_decorateDefaultCredentialProvider = (provider) => (input) => provider({
    roleAssumer: defaultRoleAssumers_getDefaultRoleAssumer(input),
    roleAssumerWithWebIdentity: defaultRoleAssumers_getDefaultRoleAssumerWithWebIdentity(input),
    ...input,
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/endpoints.js

const dist_es_endpoints_regionHash = {
    "ca-central-1": {
        variants: [
            {
                hostname: "dynamodb-fips.ca-central-1.amazonaws.com",
                tags: ["fips"],
            },
        ],
    },
    local: {
        variants: [
            {
                hostname: "localhost:8000",
                tags: [],
            },
        ],
        signingRegion: "us-east-1",
    },
    "us-east-1": {
        variants: [
            {
                hostname: "dynamodb-fips.us-east-1.amazonaws.com",
                tags: ["fips"],
            },
        ],
    },
    "us-east-2": {
        variants: [
            {
                hostname: "dynamodb-fips.us-east-2.amazonaws.com",
                tags: ["fips"],
            },
        ],
    },
    "us-gov-east-1": {
        variants: [
            {
                hostname: "dynamodb.us-gov-east-1.amazonaws.com",
                tags: ["fips"],
            },
        ],
    },
    "us-gov-west-1": {
        variants: [
            {
                hostname: "dynamodb.us-gov-west-1.amazonaws.com",
                tags: ["fips"],
            },
        ],
    },
    "us-west-1": {
        variants: [
            {
                hostname: "dynamodb-fips.us-west-1.amazonaws.com",
                tags: ["fips"],
            },
        ],
    },
    "us-west-2": {
        variants: [
            {
                hostname: "dynamodb-fips.us-west-2.amazonaws.com",
                tags: ["fips"],
            },
        ],
    },
};
const dist_es_endpoints_partitionHash = {
    aws: {
        regions: [
            "af-south-1",
            "ap-east-1",
            "ap-northeast-1",
            "ap-northeast-2",
            "ap-northeast-3",
            "ap-south-1",
            "ap-southeast-1",
            "ap-southeast-2",
            "ap-southeast-3",
            "ca-central-1",
            "ca-central-1-fips",
            "eu-central-1",
            "eu-north-1",
            "eu-south-1",
            "eu-west-1",
            "eu-west-2",
            "eu-west-3",
            "local",
            "me-central-1",
            "me-south-1",
            "sa-east-1",
            "us-east-1",
            "us-east-1-fips",
            "us-east-2",
            "us-east-2-fips",
            "us-west-1",
            "us-west-1-fips",
            "us-west-2",
            "us-west-2-fips",
        ],
        regionRegex: "^(us|eu|ap|sa|ca|me|af)\\-\\w+\\-\\d+$",
        variants: [
            {
                hostname: "dynamodb.{region}.amazonaws.com",
                tags: [],
            },
            {
                hostname: "dynamodb-fips.{region}.amazonaws.com",
                tags: ["fips"],
            },
            {
                hostname: "dynamodb-fips.{region}.api.aws",
                tags: ["dualstack", "fips"],
            },
            {
                hostname: "dynamodb.{region}.api.aws",
                tags: ["dualstack"],
            },
        ],
    },
    "aws-cn": {
        regions: ["cn-north-1", "cn-northwest-1"],
        regionRegex: "^cn\\-\\w+\\-\\d+$",
        variants: [
            {
                hostname: "dynamodb.{region}.amazonaws.com.cn",
                tags: [],
            },
            {
                hostname: "dynamodb-fips.{region}.amazonaws.com.cn",
                tags: ["fips"],
            },
            {
                hostname: "dynamodb-fips.{region}.api.amazonwebservices.com.cn",
                tags: ["dualstack", "fips"],
            },
            {
                hostname: "dynamodb.{region}.api.amazonwebservices.com.cn",
                tags: ["dualstack"],
            },
        ],
    },
    "aws-iso": {
        regions: ["us-iso-east-1", "us-iso-west-1"],
        regionRegex: "^us\\-iso\\-\\w+\\-\\d+$",
        variants: [
            {
                hostname: "dynamodb.{region}.c2s.ic.gov",
                tags: [],
            },
            {
                hostname: "dynamodb-fips.{region}.c2s.ic.gov",
                tags: ["fips"],
            },
        ],
    },
    "aws-iso-b": {
        regions: ["us-isob-east-1"],
        regionRegex: "^us\\-isob\\-\\w+\\-\\d+$",
        variants: [
            {
                hostname: "dynamodb.{region}.sc2s.sgov.gov",
                tags: [],
            },
            {
                hostname: "dynamodb-fips.{region}.sc2s.sgov.gov",
                tags: ["fips"],
            },
        ],
    },
    "aws-us-gov": {
        regions: ["us-gov-east-1", "us-gov-east-1-fips", "us-gov-west-1", "us-gov-west-1-fips"],
        regionRegex: "^us\\-gov\\-\\w+\\-\\d+$",
        variants: [
            {
                hostname: "dynamodb.{region}.amazonaws.com",
                tags: [],
            },
            {
                hostname: "dynamodb.{region}.amazonaws.com",
                tags: ["fips"],
            },
            {
                hostname: "dynamodb-fips.{region}.api.aws",
                tags: ["dualstack", "fips"],
            },
            {
                hostname: "dynamodb.{region}.api.aws",
                tags: ["dualstack"],
            },
        ],
    },
};
const dist_es_endpoints_defaultRegionInfoProvider = async (region, options) => getRegionInfo(region, {
    ...options,
    signingService: "dynamodb",
    regionHash: dist_es_endpoints_regionHash,
    partitionHash: dist_es_endpoints_partitionHash,
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/runtimeConfig.shared.js


const dist_es_runtimeConfig_shared_getRuntimeConfig = (config) => ({
    apiVersion: "2012-08-10",
    disableHostPrefix: config?.disableHostPrefix ?? false,
    logger: config?.logger ?? {},
    regionInfoProvider: config?.regionInfoProvider ?? dist_es_endpoints_defaultRegionInfoProvider,
    serviceId: config?.serviceId ?? "DynamoDB",
    urlParser: config?.urlParser ?? parseUrl,
});

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/runtimeConfig.js

















const client_dynamodb_dist_es_runtimeConfig_getRuntimeConfig = (config) => {
    emitWarningIfUnsupportedVersion(process.version);
    const defaultsMode = resolveDefaultsModeConfig(config);
    const defaultConfigProvider = () => defaultsMode().then(loadConfigsForDefaultMode);
    const clientSharedValues = dist_es_runtimeConfig_shared_getRuntimeConfig(config);
    return {
        ...clientSharedValues,
        ...config,
        runtime: "node",
        defaultsMode,
        base64Decoder: config?.base64Decoder ?? fromBase64,
        base64Encoder: config?.base64Encoder ?? toBase64,
        bodyLengthChecker: config?.bodyLengthChecker ?? calculateBodyLength,
        credentialDefaultProvider: config?.credentialDefaultProvider ?? defaultRoleAssumers_decorateDefaultCredentialProvider(defaultProvider),
        defaultUserAgentProvider: config?.defaultUserAgentProvider ??
            defaultUserAgent({ serviceId: clientSharedValues.serviceId, clientVersion: package_namespaceObject.i8 }),
        endpointDiscoveryEnabledProvider: config?.endpointDiscoveryEnabledProvider ?? loadConfig(NODE_ENDPOINT_DISCOVERY_CONFIG_OPTIONS),
        maxAttempts: config?.maxAttempts ?? loadConfig(NODE_MAX_ATTEMPT_CONFIG_OPTIONS),
        region: config?.region ?? loadConfig(NODE_REGION_CONFIG_OPTIONS, NODE_REGION_CONFIG_FILE_OPTIONS),
        requestHandler: config?.requestHandler ?? new NodeHttpHandler(defaultConfigProvider),
        retryMode: config?.retryMode ??
            loadConfig({
                ...NODE_RETRY_MODE_CONFIG_OPTIONS,
                default: async () => (await defaultConfigProvider()).retryMode || DEFAULT_RETRY_MODE,
            }),
        sha256: config?.sha256 ?? Hash.bind(null, "sha256"),
        streamCollector: config?.streamCollector ?? streamCollector,
        useDualstackEndpoint: config?.useDualstackEndpoint ?? loadConfig(NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS),
        useFipsEndpoint: config?.useFipsEndpoint ?? loadConfig(NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS),
        utf8Decoder: config?.utf8Decoder ?? fromUtf8,
        utf8Encoder: config?.utf8Encoder ?? toUtf8,
    };
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/DynamoDBClient.js












class DynamoDBClient extends Client {
    constructor(configuration) {
        const _config_0 = client_dynamodb_dist_es_runtimeConfig_getRuntimeConfig(configuration);
        const _config_1 = resolveRegionConfig(_config_0);
        const _config_2 = resolveEndpointsConfig(_config_1);
        const _config_3 = resolveRetryConfig(_config_2);
        const _config_4 = resolveHostHeaderConfig(_config_3);
        const _config_5 = resolveAwsAuthConfig(_config_4);
        const _config_6 = resolveUserAgentConfig(_config_5);
        const _config_7 = resolveEndpointDiscoveryConfig(_config_6, {
            endpointDiscoveryCommandCtor: DescribeEndpointsCommand,
        });
        super(_config_7);
        this.config = _config_7;
        this.middlewareStack.use(getRetryPlugin(this.config));
        this.middlewareStack.use(getContentLengthPlugin(this.config));
        this.middlewareStack.use(getHostHeaderPlugin(this.config));
        this.middlewareStack.use(getLoggerPlugin(this.config));
        this.middlewareStack.use(getRecursionDetectionPlugin(this.config));
        this.middlewareStack.use(getAwsAuthPlugin(this.config));
        this.middlewareStack.use(getUserAgentPlugin(this.config));
    }
    destroy() {
        super.destroy();
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/DynamoDB.js






















































class DynamoDB extends DynamoDBClient {
    batchExecuteStatement(args, optionsOrCb, cb) {
        const command = new BatchExecuteStatementCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    batchGetItem(args, optionsOrCb, cb) {
        const command = new BatchGetItemCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    batchWriteItem(args, optionsOrCb, cb) {
        const command = new BatchWriteItemCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    createBackup(args, optionsOrCb, cb) {
        const command = new CreateBackupCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    createGlobalTable(args, optionsOrCb, cb) {
        const command = new CreateGlobalTableCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    createTable(args, optionsOrCb, cb) {
        const command = new CreateTableCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    deleteBackup(args, optionsOrCb, cb) {
        const command = new DeleteBackupCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    deleteItem(args, optionsOrCb, cb) {
        const command = new DeleteItemCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    deleteTable(args, optionsOrCb, cb) {
        const command = new DeleteTableCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    describeBackup(args, optionsOrCb, cb) {
        const command = new DescribeBackupCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    describeContinuousBackups(args, optionsOrCb, cb) {
        const command = new DescribeContinuousBackupsCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    describeContributorInsights(args, optionsOrCb, cb) {
        const command = new DescribeContributorInsightsCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    describeEndpoints(args, optionsOrCb, cb) {
        const command = new DescribeEndpointsCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    describeExport(args, optionsOrCb, cb) {
        const command = new DescribeExportCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    describeGlobalTable(args, optionsOrCb, cb) {
        const command = new DescribeGlobalTableCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    describeGlobalTableSettings(args, optionsOrCb, cb) {
        const command = new DescribeGlobalTableSettingsCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    describeImport(args, optionsOrCb, cb) {
        const command = new DescribeImportCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    describeKinesisStreamingDestination(args, optionsOrCb, cb) {
        const command = new DescribeKinesisStreamingDestinationCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    describeLimits(args, optionsOrCb, cb) {
        const command = new DescribeLimitsCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    describeTable(args, optionsOrCb, cb) {
        const command = new DescribeTableCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    describeTableReplicaAutoScaling(args, optionsOrCb, cb) {
        const command = new DescribeTableReplicaAutoScalingCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    describeTimeToLive(args, optionsOrCb, cb) {
        const command = new DescribeTimeToLiveCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    disableKinesisStreamingDestination(args, optionsOrCb, cb) {
        const command = new DisableKinesisStreamingDestinationCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    enableKinesisStreamingDestination(args, optionsOrCb, cb) {
        const command = new EnableKinesisStreamingDestinationCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    executeStatement(args, optionsOrCb, cb) {
        const command = new ExecuteStatementCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    executeTransaction(args, optionsOrCb, cb) {
        const command = new ExecuteTransactionCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    exportTableToPointInTime(args, optionsOrCb, cb) {
        const command = new ExportTableToPointInTimeCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    getItem(args, optionsOrCb, cb) {
        const command = new GetItemCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    importTable(args, optionsOrCb, cb) {
        const command = new ImportTableCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    listBackups(args, optionsOrCb, cb) {
        const command = new ListBackupsCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    listContributorInsights(args, optionsOrCb, cb) {
        const command = new ListContributorInsightsCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    listExports(args, optionsOrCb, cb) {
        const command = new ListExportsCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    listGlobalTables(args, optionsOrCb, cb) {
        const command = new ListGlobalTablesCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    listImports(args, optionsOrCb, cb) {
        const command = new ListImportsCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    listTables(args, optionsOrCb, cb) {
        const command = new ListTablesCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    listTagsOfResource(args, optionsOrCb, cb) {
        const command = new ListTagsOfResourceCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    putItem(args, optionsOrCb, cb) {
        const command = new PutItemCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    query(args, optionsOrCb, cb) {
        const command = new QueryCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    restoreTableFromBackup(args, optionsOrCb, cb) {
        const command = new RestoreTableFromBackupCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    restoreTableToPointInTime(args, optionsOrCb, cb) {
        const command = new RestoreTableToPointInTimeCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    scan(args, optionsOrCb, cb) {
        const command = new ScanCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    tagResource(args, optionsOrCb, cb) {
        const command = new TagResourceCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    transactGetItems(args, optionsOrCb, cb) {
        const command = new TransactGetItemsCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    transactWriteItems(args, optionsOrCb, cb) {
        const command = new TransactWriteItemsCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    untagResource(args, optionsOrCb, cb) {
        const command = new UntagResourceCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    updateContinuousBackups(args, optionsOrCb, cb) {
        const command = new UpdateContinuousBackupsCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    updateContributorInsights(args, optionsOrCb, cb) {
        const command = new UpdateContributorInsightsCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    updateGlobalTable(args, optionsOrCb, cb) {
        const command = new UpdateGlobalTableCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    updateGlobalTableSettings(args, optionsOrCb, cb) {
        const command = new UpdateGlobalTableSettingsCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    updateItem(args, optionsOrCb, cb) {
        const command = new UpdateItemCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    updateTable(args, optionsOrCb, cb) {
        const command = new UpdateTableCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    updateTableReplicaAutoScaling(args, optionsOrCb, cb) {
        const command = new UpdateTableReplicaAutoScalingCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
    updateTimeToLive(args, optionsOrCb, cb) {
        const command = new UpdateTimeToLiveCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error(`Expect http options but get ${typeof optionsOrCb}`);
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    }
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/commands/index.js






















































;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/models/index.js


;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/pagination/ListContributorInsightsPaginator.js



const makePagedClientRequest = async (client, input, ...args) => {
    return await client.send(new ListContributorInsightsCommand(input), ...args);
};
const makePagedRequest = async (client, input, ...args) => {
    return await client.listContributorInsights(input, ...args);
};
async function* paginateListContributorInsights(config, input, ...additionalArguments) {
    let token = config.startingToken || undefined;
    let hasNext = true;
    let page;
    while (hasNext) {
        input.NextToken = token;
        input["MaxResults"] = config.pageSize;
        if (config.client instanceof DynamoDB) {
            page = await makePagedRequest(config.client, input, ...additionalArguments);
        }
        else if (config.client instanceof DynamoDBClient) {
            page = await makePagedClientRequest(config.client, input, ...additionalArguments);
        }
        else {
            throw new Error("Invalid client, expected DynamoDB | DynamoDBClient");
        }
        yield page;
        const prevToken = token;
        token = page.NextToken;
        hasNext = !!(token && (!config.stopOnSameToken || token !== prevToken));
    }
    return undefined;
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/pagination/ListExportsPaginator.js



const ListExportsPaginator_makePagedClientRequest = async (client, input, ...args) => {
    return await client.send(new ListExportsCommand(input), ...args);
};
const ListExportsPaginator_makePagedRequest = async (client, input, ...args) => {
    return await client.listExports(input, ...args);
};
async function* paginateListExports(config, input, ...additionalArguments) {
    let token = config.startingToken || undefined;
    let hasNext = true;
    let page;
    while (hasNext) {
        input.NextToken = token;
        input["MaxResults"] = config.pageSize;
        if (config.client instanceof DynamoDB) {
            page = await ListExportsPaginator_makePagedRequest(config.client, input, ...additionalArguments);
        }
        else if (config.client instanceof DynamoDBClient) {
            page = await ListExportsPaginator_makePagedClientRequest(config.client, input, ...additionalArguments);
        }
        else {
            throw new Error("Invalid client, expected DynamoDB | DynamoDBClient");
        }
        yield page;
        const prevToken = token;
        token = page.NextToken;
        hasNext = !!(token && (!config.stopOnSameToken || token !== prevToken));
    }
    return undefined;
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/pagination/ListImportsPaginator.js



const ListImportsPaginator_makePagedClientRequest = async (client, input, ...args) => {
    return await client.send(new ListImportsCommand(input), ...args);
};
const ListImportsPaginator_makePagedRequest = async (client, input, ...args) => {
    return await client.listImports(input, ...args);
};
async function* paginateListImports(config, input, ...additionalArguments) {
    let token = config.startingToken || undefined;
    let hasNext = true;
    let page;
    while (hasNext) {
        input.NextToken = token;
        input["PageSize"] = config.pageSize;
        if (config.client instanceof DynamoDB) {
            page = await ListImportsPaginator_makePagedRequest(config.client, input, ...additionalArguments);
        }
        else if (config.client instanceof DynamoDBClient) {
            page = await ListImportsPaginator_makePagedClientRequest(config.client, input, ...additionalArguments);
        }
        else {
            throw new Error("Invalid client, expected DynamoDB | DynamoDBClient");
        }
        yield page;
        const prevToken = token;
        token = page.NextToken;
        hasNext = !!(token && (!config.stopOnSameToken || token !== prevToken));
    }
    return undefined;
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/pagination/ListTablesPaginator.js



const ListTablesPaginator_makePagedClientRequest = async (client, input, ...args) => {
    return await client.send(new ListTablesCommand(input), ...args);
};
const ListTablesPaginator_makePagedRequest = async (client, input, ...args) => {
    return await client.listTables(input, ...args);
};
async function* paginateListTables(config, input, ...additionalArguments) {
    let token = config.startingToken || undefined;
    let hasNext = true;
    let page;
    while (hasNext) {
        input.ExclusiveStartTableName = token;
        input["Limit"] = config.pageSize;
        if (config.client instanceof DynamoDB) {
            page = await ListTablesPaginator_makePagedRequest(config.client, input, ...additionalArguments);
        }
        else if (config.client instanceof DynamoDBClient) {
            page = await ListTablesPaginator_makePagedClientRequest(config.client, input, ...additionalArguments);
        }
        else {
            throw new Error("Invalid client, expected DynamoDB | DynamoDBClient");
        }
        yield page;
        const prevToken = token;
        token = page.LastEvaluatedTableName;
        hasNext = !!(token && (!config.stopOnSameToken || token !== prevToken));
    }
    return undefined;
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/pagination/QueryPaginator.js



const QueryPaginator_makePagedClientRequest = async (client, input, ...args) => {
    return await client.send(new QueryCommand(input), ...args);
};
const QueryPaginator_makePagedRequest = async (client, input, ...args) => {
    return await client.query(input, ...args);
};
async function* paginateQuery(config, input, ...additionalArguments) {
    let token = config.startingToken || undefined;
    let hasNext = true;
    let page;
    while (hasNext) {
        input.ExclusiveStartKey = token;
        input["Limit"] = config.pageSize;
        if (config.client instanceof DynamoDB) {
            page = await QueryPaginator_makePagedRequest(config.client, input, ...additionalArguments);
        }
        else if (config.client instanceof DynamoDBClient) {
            page = await QueryPaginator_makePagedClientRequest(config.client, input, ...additionalArguments);
        }
        else {
            throw new Error("Invalid client, expected DynamoDB | DynamoDBClient");
        }
        yield page;
        const prevToken = token;
        token = page.LastEvaluatedKey;
        hasNext = !!(token && (!config.stopOnSameToken || token !== prevToken));
    }
    return undefined;
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/pagination/ScanPaginator.js



const ScanPaginator_makePagedClientRequest = async (client, input, ...args) => {
    return await client.send(new ScanCommand(input), ...args);
};
const ScanPaginator_makePagedRequest = async (client, input, ...args) => {
    return await client.scan(input, ...args);
};
async function* paginateScan(config, input, ...additionalArguments) {
    let token = config.startingToken || undefined;
    let hasNext = true;
    let page;
    while (hasNext) {
        input.ExclusiveStartKey = token;
        input["Limit"] = config.pageSize;
        if (config.client instanceof DynamoDB) {
            page = await ScanPaginator_makePagedRequest(config.client, input, ...additionalArguments);
        }
        else if (config.client instanceof DynamoDBClient) {
            page = await ScanPaginator_makePagedClientRequest(config.client, input, ...additionalArguments);
        }
        else {
            throw new Error("Invalid client, expected DynamoDB | DynamoDBClient");
        }
        yield page;
        const prevToken = token;
        token = page.LastEvaluatedKey;
        hasNext = !!(token && (!config.stopOnSameToken || token !== prevToken));
    }
    return undefined;
}

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/pagination/index.js








;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-waiter/dist-es/utils/sleep.js
const sleep = (seconds) => {
    return new Promise((resolve) => setTimeout(resolve, seconds * 1000));
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-waiter/dist-es/waiter.js
const waiterServiceDefaults = {
    minDelay: 2,
    maxDelay: 120,
};
var WaiterState;
(function (WaiterState) {
    WaiterState["ABORTED"] = "ABORTED";
    WaiterState["FAILURE"] = "FAILURE";
    WaiterState["SUCCESS"] = "SUCCESS";
    WaiterState["RETRY"] = "RETRY";
    WaiterState["TIMEOUT"] = "TIMEOUT";
})(WaiterState || (WaiterState = {}));
const checkExceptions = (result) => {
    if (result.state === WaiterState.ABORTED) {
        const abortError = new Error(`${JSON.stringify({
            ...result,
            reason: "Request was aborted",
        })}`);
        abortError.name = "AbortError";
        throw abortError;
    }
    else if (result.state === WaiterState.TIMEOUT) {
        const timeoutError = new Error(`${JSON.stringify({
            ...result,
            reason: "Waiter has timed out",
        })}`);
        timeoutError.name = "TimeoutError";
        throw timeoutError;
    }
    else if (result.state !== WaiterState.SUCCESS) {
        throw new Error(`${JSON.stringify({ result })}`);
    }
    return result;
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-waiter/dist-es/poller.js


const exponentialBackoffWithJitter = (minDelay, maxDelay, attemptCeiling, attempt) => {
    if (attempt > attemptCeiling)
        return maxDelay;
    const delay = minDelay * 2 ** (attempt - 1);
    return randomInRange(minDelay, delay);
};
const randomInRange = (min, max) => min + Math.random() * (max - min);
const runPolling = async ({ minDelay, maxDelay, maxWaitTime, abortController, client, abortSignal }, input, acceptorChecks) => {
    const { state, reason } = await acceptorChecks(client, input);
    if (state !== WaiterState.RETRY) {
        return { state, reason };
    }
    let currentAttempt = 1;
    const waitUntil = Date.now() + maxWaitTime * 1000;
    const attemptCeiling = Math.log(maxDelay / minDelay) / Math.log(2) + 1;
    while (true) {
        if (abortController?.signal?.aborted || abortSignal?.aborted) {
            return { state: WaiterState.ABORTED };
        }
        const delay = exponentialBackoffWithJitter(minDelay, maxDelay, attemptCeiling, currentAttempt);
        if (Date.now() + delay * 1000 > waitUntil) {
            return { state: WaiterState.TIMEOUT };
        }
        await sleep(delay);
        const { state, reason } = await acceptorChecks(client, input);
        if (state !== WaiterState.RETRY) {
            return { state, reason };
        }
        currentAttempt += 1;
    }
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-waiter/dist-es/utils/validate.js
const validateWaiterOptions = (options) => {
    if (options.maxWaitTime < 1) {
        throw new Error(`WaiterConfiguration.maxWaitTime must be greater than 0`);
    }
    else if (options.minDelay < 1) {
        throw new Error(`WaiterConfiguration.minDelay must be greater than 0`);
    }
    else if (options.maxDelay < 1) {
        throw new Error(`WaiterConfiguration.maxDelay must be greater than 0`);
    }
    else if (options.maxWaitTime <= options.minDelay) {
        throw new Error(`WaiterConfiguration.maxWaitTime [${options.maxWaitTime}] must be greater than WaiterConfiguration.minDelay [${options.minDelay}] for this waiter`);
    }
    else if (options.maxDelay < options.minDelay) {
        throw new Error(`WaiterConfiguration.maxDelay [${options.maxDelay}] must be greater than WaiterConfiguration.minDelay [${options.minDelay}] for this waiter`);
    }
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-waiter/dist-es/createWaiter.js



const abortTimeout = async (abortSignal) => {
    return new Promise((resolve) => {
        abortSignal.onabort = () => resolve({ state: WaiterState.ABORTED });
    });
};
const createWaiter = async (options, input, acceptorChecks) => {
    const params = {
        ...waiterServiceDefaults,
        ...options,
    };
    validateWaiterOptions(params);
    const exitConditions = [runPolling(params, input, acceptorChecks)];
    if (options.abortController) {
        exitConditions.push(abortTimeout(options.abortController.signal));
    }
    if (options.abortSignal) {
        exitConditions.push(abortTimeout(options.abortSignal));
    }
    return Promise.race(exitConditions);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/util-waiter/dist-es/index.js



;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/waiters/waitForTableExists.js


const checkState = async (client, input) => {
    let reason;
    try {
        const result = await client.send(new DescribeTableCommand(input));
        reason = result;
        try {
            const returnComparator = () => {
                return result.Table.TableStatus;
            };
            if (returnComparator() === "ACTIVE") {
                return { state: WaiterState.SUCCESS, reason };
            }
        }
        catch (e) { }
    }
    catch (exception) {
        reason = exception;
        if (exception.name && exception.name == "ResourceNotFoundException") {
            return { state: WaiterState.RETRY, reason };
        }
    }
    return { state: WaiterState.RETRY, reason };
};
const waitForTableExists = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    return createWaiter({ ...serviceDefaults, ...params }, input, checkState);
};
const waitUntilTableExists = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    const result = await createWaiter({ ...serviceDefaults, ...params }, input, checkState);
    return checkExceptions(result);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/waiters/waitForTableNotExists.js


const waitForTableNotExists_checkState = async (client, input) => {
    let reason;
    try {
        const result = await client.send(new DescribeTableCommand(input));
        reason = result;
    }
    catch (exception) {
        reason = exception;
        if (exception.name && exception.name == "ResourceNotFoundException") {
            return { state: WaiterState.SUCCESS, reason };
        }
    }
    return { state: WaiterState.RETRY, reason };
};
const waitForTableNotExists = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    return createWaiter({ ...serviceDefaults, ...params }, input, waitForTableNotExists_checkState);
};
const waitUntilTableNotExists = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    const result = await createWaiter({ ...serviceDefaults, ...params }, input, waitForTableNotExists_checkState);
    return checkExceptions(result);
};

;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/waiters/index.js



;// CONCATENATED MODULE: ../node_modules/@aws-sdk/client-dynamodb/dist-es/index.js









/***/ }),

/***/ 726:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ isCrtAvailable)
/* harmony export */ });
/* module decorator */ module = __webpack_require__.hmd(module);
const isCrtAvailable = () => {
    try {
        if ( true && module.require && __webpack_require__(Object(function webpackMissingModule() { var e = new Error("Cannot find module 'aws-crt'"); e.code = 'MODULE_NOT_FOUND'; throw e; }()))) {
            return ["md/crt-avail"];
        }
        return null;
    }
    catch (e) {
        return null;
    }
};


/***/ }),

/***/ 232:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


const {
  DynamoDBClient,
  ScanCommand
} = __webpack_require__(915);
module.exports.getproductslist = async event => {
  const dynamoClient = new DynamoDBClient({
    region: "us-east-1"
  });
  const ProductTable = {
    TableName: "ProductsListTable"
  };
  const StockTable = {
    TableName: "StockListTable"
  };
  try {
    const data = await dynamoClient.send(new ScanCommand(ProductTable));
    const stockData = await dynamoClient.send(new ScanCommand(StockTable));
    console.log(stockData.Items);
    var formattedObjects = data.Items.map(function (item) {
      const stock = stockData.Items.find(st => st.product_id.S === item.id.S);
      if (stock) {
        return {
          "id": item.id.S,
          "description": item.description.S,
          "price": item.price.N,
          "title": item.title.S,
          "count": stock.count.N
        };
      } else {
        return {
          "id": item.id.S,
          "description": item.description.S,
          "price": item.price.N,
          "title": item.title.S
        };
      }
    });
    console.log(formattedObjects);
    if (!formattedObjects) {
      return {
        statusCode: 404,
        headers: {
          'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
          message: 'NotResultFound'
        })
      };
    }
    return {
      statusCode: 200,
      body: JSON.stringify(formattedObjects)
    };
  } catch (err) {
    console.log(err);
  }
  // Use this code if you don't use the http event with the LAMBDA-PROXY integration
  // return { message: 'Go Serverless v1.0! Your function executed successfully!', event };
};

/***/ }),

/***/ 368:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


const validator = __webpack_require__(754);
const XMLParser = __webpack_require__(696);
const XMLBuilder = __webpack_require__(753);

module.exports = {
  XMLParser: XMLParser,
  XMLValidator: validator,
  XMLBuilder: XMLBuilder
}

/***/ }),

/***/ 298:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


const nameStartChar = ':A-Za-z_\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD';
const nameChar = nameStartChar + '\\-.\\d\\u00B7\\u0300-\\u036F\\u203F-\\u2040';
const nameRegexp = '[' + nameStartChar + '][' + nameChar + ']*'
const regexName = new RegExp('^' + nameRegexp + '$');

const getAllMatches = function(string, regex) {
  const matches = [];
  let match = regex.exec(string);
  while (match) {
    const allmatches = [];
    allmatches.startIndex = regex.lastIndex - match[0].length;
    const len = match.length;
    for (let index = 0; index < len; index++) {
      allmatches.push(match[index]);
    }
    matches.push(allmatches);
    match = regex.exec(string);
  }
  return matches;
};

const isName = function(string) {
  const match = regexName.exec(string);
  return !(match === null || typeof match === 'undefined');
};

exports.isExist = function(v) {
  return typeof v !== 'undefined';
};

exports.isEmptyObject = function(obj) {
  return Object.keys(obj).length === 0;
};

/**
 * Copy all the properties of a into b.
 * @param {*} target
 * @param {*} a
 */
exports.merge = function(target, a, arrayMode) {
  if (a) {
    const keys = Object.keys(a); // will return an array of own properties
    const len = keys.length; //don't make it inline
    for (let i = 0; i < len; i++) {
      if (arrayMode === 'strict') {
        target[keys[i]] = [ a[keys[i]] ];
      } else {
        target[keys[i]] = a[keys[i]];
      }
    }
  }
};
/* exports.merge =function (b,a){
  return Object.assign(b,a);
} */

exports.getValue = function(v) {
  if (exports.isExist(v)) {
    return v;
  } else {
    return '';
  }
};

// const fakeCall = function(a) {return a;};
// const fakeCallNoReturn = function() {};

exports.isName = isName;
exports.getAllMatches = getAllMatches;
exports.nameRegexp = nameRegexp;


/***/ }),

/***/ 754:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


const util = __webpack_require__(298);

const defaultOptions = {
  allowBooleanAttributes: false, //A tag can have attributes without any value
  unpairedTags: []
};

//const tagsPattern = new RegExp("<\\/?([\\w:\\-_\.]+)\\s*\/?>","g");
exports.validate = function (xmlData, options) {
  options = Object.assign({}, defaultOptions, options);

  //xmlData = xmlData.replace(/(\r\n|\n|\r)/gm,"");//make it single line
  //xmlData = xmlData.replace(/(^\s*<\?xml.*?\?>)/g,"");//Remove XML starting tag
  //xmlData = xmlData.replace(/(<!DOCTYPE[\s\w\"\.\/\-\:]+(\[.*\])*\s*>)/g,"");//Remove DOCTYPE
  const tags = [];
  let tagFound = false;

  //indicates that the root tag has been closed (aka. depth 0 has been reached)
  let reachedRoot = false;

  if (xmlData[0] === '\ufeff') {
    // check for byte order mark (BOM)
    xmlData = xmlData.substr(1);
  }
  
  for (let i = 0; i < xmlData.length; i++) {

    if (xmlData[i] === '<' && xmlData[i+1] === '?') {
      i+=2;
      i = readPI(xmlData,i);
      if (i.err) return i;
    }else if (xmlData[i] === '<') {
      //starting of tag
      //read until you reach to '>' avoiding any '>' in attribute value
      let tagStartPos = i;
      i++;
      
      if (xmlData[i] === '!') {
        i = readCommentAndCDATA(xmlData, i);
        continue;
      } else {
        let closingTag = false;
        if (xmlData[i] === '/') {
          //closing tag
          closingTag = true;
          i++;
        }
        //read tagname
        let tagName = '';
        for (; i < xmlData.length &&
          xmlData[i] !== '>' &&
          xmlData[i] !== ' ' &&
          xmlData[i] !== '\t' &&
          xmlData[i] !== '\n' &&
          xmlData[i] !== '\r'; i++
        ) {
          tagName += xmlData[i];
        }
        tagName = tagName.trim();
        //console.log(tagName);

        if (tagName[tagName.length - 1] === '/') {
          //self closing tag without attributes
          tagName = tagName.substring(0, tagName.length - 1);
          //continue;
          i--;
        }
        if (!validateTagName(tagName)) {
          let msg;
          if (tagName.trim().length === 0) {
            msg = "Invalid space after '<'.";
          } else {
            msg = "Tag '"+tagName+"' is an invalid name.";
          }
          return getErrorObject('InvalidTag', msg, getLineNumberForPosition(xmlData, i));
        }

        const result = readAttributeStr(xmlData, i);
        if (result === false) {
          return getErrorObject('InvalidAttr', "Attributes for '"+tagName+"' have open quote.", getLineNumberForPosition(xmlData, i));
        }
        let attrStr = result.value;
        i = result.index;

        if (attrStr[attrStr.length - 1] === '/') {
          //self closing tag
          const attrStrStart = i - attrStr.length;
          attrStr = attrStr.substring(0, attrStr.length - 1);
          const isValid = validateAttributeString(attrStr, options);
          if (isValid === true) {
            tagFound = true;
            //continue; //text may presents after self closing tag
          } else {
            //the result from the nested function returns the position of the error within the attribute
            //in order to get the 'true' error line, we need to calculate the position where the attribute begins (i - attrStr.length) and then add the position within the attribute
            //this gives us the absolute index in the entire xml, which we can use to find the line at last
            return getErrorObject(isValid.err.code, isValid.err.msg, getLineNumberForPosition(xmlData, attrStrStart + isValid.err.line));
          }
        } else if (closingTag) {
          if (!result.tagClosed) {
            return getErrorObject('InvalidTag', "Closing tag '"+tagName+"' doesn't have proper closing.", getLineNumberForPosition(xmlData, i));
          } else if (attrStr.trim().length > 0) {
            return getErrorObject('InvalidTag', "Closing tag '"+tagName+"' can't have attributes or invalid starting.", getLineNumberForPosition(xmlData, tagStartPos));
          } else {
            const otg = tags.pop();
            if (tagName !== otg.tagName) {
              let openPos = getLineNumberForPosition(xmlData, otg.tagStartPos);
              return getErrorObject('InvalidTag',
                "Expected closing tag '"+otg.tagName+"' (opened in line "+openPos.line+", col "+openPos.col+") instead of closing tag '"+tagName+"'.",
                getLineNumberForPosition(xmlData, tagStartPos));
            }

            //when there are no more tags, we reached the root level.
            if (tags.length == 0) {
              reachedRoot = true;
            }
          }
        } else {
          const isValid = validateAttributeString(attrStr, options);
          if (isValid !== true) {
            //the result from the nested function returns the position of the error within the attribute
            //in order to get the 'true' error line, we need to calculate the position where the attribute begins (i - attrStr.length) and then add the position within the attribute
            //this gives us the absolute index in the entire xml, which we can use to find the line at last
            return getErrorObject(isValid.err.code, isValid.err.msg, getLineNumberForPosition(xmlData, i - attrStr.length + isValid.err.line));
          }

          //if the root level has been reached before ...
          if (reachedRoot === true) {
            return getErrorObject('InvalidXml', 'Multiple possible root nodes found.', getLineNumberForPosition(xmlData, i));
          } else if(options.unpairedTags.indexOf(tagName) !== -1){
            //don't push into stack
          } else {
            tags.push({tagName, tagStartPos});
          }
          tagFound = true;
        }

        //skip tag text value
        //It may include comments and CDATA value
        for (i++; i < xmlData.length; i++) {
          if (xmlData[i] === '<') {
            if (xmlData[i + 1] === '!') {
              //comment or CADATA
              i++;
              i = readCommentAndCDATA(xmlData, i);
              continue;
            } else if (xmlData[i+1] === '?') {
              i = readPI(xmlData, ++i);
              if (i.err) return i;
            } else{
              break;
            }
          } else if (xmlData[i] === '&') {
            const afterAmp = validateAmpersand(xmlData, i);
            if (afterAmp == -1)
              return getErrorObject('InvalidChar', "char '&' is not expected.", getLineNumberForPosition(xmlData, i));
            i = afterAmp;
          }else{
            if (reachedRoot === true && !isWhiteSpace(xmlData[i])) {
              return getErrorObject('InvalidXml', "Extra text at the end", getLineNumberForPosition(xmlData, i));
            }
          }
        } //end of reading tag text value
        if (xmlData[i] === '<') {
          i--;
        }
      }
    } else {
      if ( isWhiteSpace(xmlData[i])) {
        continue;
      }
      return getErrorObject('InvalidChar', "char '"+xmlData[i]+"' is not expected.", getLineNumberForPosition(xmlData, i));
    }
  }

  if (!tagFound) {
    return getErrorObject('InvalidXml', 'Start tag expected.', 1);
  }else if (tags.length == 1) {
      return getErrorObject('InvalidTag', "Unclosed tag '"+tags[0].tagName+"'.", getLineNumberForPosition(xmlData, tags[0].tagStartPos));
  }else if (tags.length > 0) {
      return getErrorObject('InvalidXml', "Invalid '"+
          JSON.stringify(tags.map(t => t.tagName), null, 4).replace(/\r?\n/g, '')+
          "' found.", {line: 1, col: 1});
  }

  return true;
};

function isWhiteSpace(char){
  return char === ' ' || char === '\t' || char === '\n'  || char === '\r';
}
/**
 * Read Processing insstructions and skip
 * @param {*} xmlData
 * @param {*} i
 */
function readPI(xmlData, i) {
  const start = i;
  for (; i < xmlData.length; i++) {
    if (xmlData[i] == '?' || xmlData[i] == ' ') {
      //tagname
      const tagname = xmlData.substr(start, i - start);
      if (i > 5 && tagname === 'xml') {
        return getErrorObject('InvalidXml', 'XML declaration allowed only at the start of the document.', getLineNumberForPosition(xmlData, i));
      } else if (xmlData[i] == '?' && xmlData[i + 1] == '>') {
        //check if valid attribut string
        i++;
        break;
      } else {
        continue;
      }
    }
  }
  return i;
}

function readCommentAndCDATA(xmlData, i) {
  if (xmlData.length > i + 5 && xmlData[i + 1] === '-' && xmlData[i + 2] === '-') {
    //comment
    for (i += 3; i < xmlData.length; i++) {
      if (xmlData[i] === '-' && xmlData[i + 1] === '-' && xmlData[i + 2] === '>') {
        i += 2;
        break;
      }
    }
  } else if (
    xmlData.length > i + 8 &&
    xmlData[i + 1] === 'D' &&
    xmlData[i + 2] === 'O' &&
    xmlData[i + 3] === 'C' &&
    xmlData[i + 4] === 'T' &&
    xmlData[i + 5] === 'Y' &&
    xmlData[i + 6] === 'P' &&
    xmlData[i + 7] === 'E'
  ) {
    let angleBracketsCount = 1;
    for (i += 8; i < xmlData.length; i++) {
      if (xmlData[i] === '<') {
        angleBracketsCount++;
      } else if (xmlData[i] === '>') {
        angleBracketsCount--;
        if (angleBracketsCount === 0) {
          break;
        }
      }
    }
  } else if (
    xmlData.length > i + 9 &&
    xmlData[i + 1] === '[' &&
    xmlData[i + 2] === 'C' &&
    xmlData[i + 3] === 'D' &&
    xmlData[i + 4] === 'A' &&
    xmlData[i + 5] === 'T' &&
    xmlData[i + 6] === 'A' &&
    xmlData[i + 7] === '['
  ) {
    for (i += 8; i < xmlData.length; i++) {
      if (xmlData[i] === ']' && xmlData[i + 1] === ']' && xmlData[i + 2] === '>') {
        i += 2;
        break;
      }
    }
  }

  return i;
}

const doubleQuote = '"';
const singleQuote = "'";

/**
 * Keep reading xmlData until '<' is found outside the attribute value.
 * @param {string} xmlData
 * @param {number} i
 */
function readAttributeStr(xmlData, i) {
  let attrStr = '';
  let startChar = '';
  let tagClosed = false;
  for (; i < xmlData.length; i++) {
    if (xmlData[i] === doubleQuote || xmlData[i] === singleQuote) {
      if (startChar === '') {
        startChar = xmlData[i];
      } else if (startChar !== xmlData[i]) {
        //if vaue is enclosed with double quote then single quotes are allowed inside the value and vice versa
      } else {
        startChar = '';
      }
    } else if (xmlData[i] === '>') {
      if (startChar === '') {
        tagClosed = true;
        break;
      }
    }
    attrStr += xmlData[i];
  }
  if (startChar !== '') {
    return false;
  }

  return {
    value: attrStr,
    index: i,
    tagClosed: tagClosed
  };
}

/**
 * Select all the attributes whether valid or invalid.
 */
const validAttrStrRegxp = new RegExp('(\\s*)([^\\s=]+)(\\s*=)?(\\s*([\'"])(([\\s\\S])*?)\\5)?', 'g');

//attr, ="sd", a="amit's", a="sd"b="saf", ab  cd=""

function validateAttributeString(attrStr, options) {
  //console.log("start:"+attrStr+":end");

  //if(attrStr.trim().length === 0) return true; //empty string

  const matches = util.getAllMatches(attrStr, validAttrStrRegxp);
  const attrNames = {};

  for (let i = 0; i < matches.length; i++) {
    if (matches[i][1].length === 0) {
      //nospace before attribute name: a="sd"b="saf"
      return getErrorObject('InvalidAttr', "Attribute '"+matches[i][2]+"' has no space in starting.", getPositionFromMatch(matches[i]))
    } else if (matches[i][3] !== undefined && matches[i][4] === undefined) {
      return getErrorObject('InvalidAttr', "Attribute '"+matches[i][2]+"' is without value.", getPositionFromMatch(matches[i]));
    } else if (matches[i][3] === undefined && !options.allowBooleanAttributes) {
      //independent attribute: ab
      return getErrorObject('InvalidAttr', "boolean attribute '"+matches[i][2]+"' is not allowed.", getPositionFromMatch(matches[i]));
    }
    /* else if(matches[i][6] === undefined){//attribute without value: ab=
                    return { err: { code:"InvalidAttr",msg:"attribute " + matches[i][2] + " has no value assigned."}};
                } */
    const attrName = matches[i][2];
    if (!validateAttrName(attrName)) {
      return getErrorObject('InvalidAttr', "Attribute '"+attrName+"' is an invalid name.", getPositionFromMatch(matches[i]));
    }
    if (!attrNames.hasOwnProperty(attrName)) {
      //check for duplicate attribute.
      attrNames[attrName] = 1;
    } else {
      return getErrorObject('InvalidAttr', "Attribute '"+attrName+"' is repeated.", getPositionFromMatch(matches[i]));
    }
  }

  return true;
}

function validateNumberAmpersand(xmlData, i) {
  let re = /\d/;
  if (xmlData[i] === 'x') {
    i++;
    re = /[\da-fA-F]/;
  }
  for (; i < xmlData.length; i++) {
    if (xmlData[i] === ';')
      return i;
    if (!xmlData[i].match(re))
      break;
  }
  return -1;
}

function validateAmpersand(xmlData, i) {
  // https://www.w3.org/TR/xml/#dt-charref
  i++;
  if (xmlData[i] === ';')
    return -1;
  if (xmlData[i] === '#') {
    i++;
    return validateNumberAmpersand(xmlData, i);
  }
  let count = 0;
  for (; i < xmlData.length; i++, count++) {
    if (xmlData[i].match(/\w/) && count < 20)
      continue;
    if (xmlData[i] === ';')
      break;
    return -1;
  }
  return i;
}

function getErrorObject(code, message, lineNumber) {
  return {
    err: {
      code: code,
      msg: message,
      line: lineNumber.line || lineNumber,
      col: lineNumber.col,
    },
  };
}

function validateAttrName(attrName) {
  return util.isName(attrName);
}

// const startsWithXML = /^xml/i;

function validateTagName(tagname) {
  return util.isName(tagname) /* && !tagname.match(startsWithXML) */;
}

//this function returns the line number for the character at the given index
function getLineNumberForPosition(xmlData, index) {
  const lines = xmlData.substring(0, index).split(/\r?\n/);
  return {
    line: lines.length,

    // column number is last line's length + 1, because column numbering starts at 1:
    col: lines[lines.length - 1].length + 1
  };
}

//this function returns the position of the first character of match within attrStr
function getPositionFromMatch(match) {
  return match.startIndex + match[1].length;
}


/***/ }),

/***/ 753:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

//parse Empty Node as self closing node
const buildFromOrderedJs = __webpack_require__(287);

const defaultOptions = {
  attributeNamePrefix: '@_',
  attributesGroupName: false,
  textNodeName: '#text',
  ignoreAttributes: true,
  cdataPropName: false,
  format: false,
  indentBy: '  ',
  suppressEmptyNode: false,
  suppressUnpairedNode: true,
  suppressBooleanAttributes: true,
  tagValueProcessor: function(key, a) {
    return a;
  },
  attributeValueProcessor: function(attrName, a) {
    return a;
  },
  preserveOrder: false,
  commentPropName: false,
  unpairedTags: [],
  entities: [
    { regex: new RegExp("&", "g"), val: "&amp;" },//it must be on top
    { regex: new RegExp(">", "g"), val: "&gt;" },
    { regex: new RegExp("<", "g"), val: "&lt;" },
    { regex: new RegExp("\'", "g"), val: "&apos;" },
    { regex: new RegExp("\"", "g"), val: "&quot;" }
  ],
  processEntities: true,
  stopNodes: [],
  transformTagName: false,
};

function Builder(options) {
  this.options = Object.assign({}, defaultOptions, options);
  if (this.options.ignoreAttributes || this.options.attributesGroupName) {
    this.isAttribute = function(/*a*/) {
      return false;
    };
  } else {
    this.attrPrefixLen = this.options.attributeNamePrefix.length;
    this.isAttribute = isAttribute;
  }

  this.processTextOrObjNode = processTextOrObjNode

  if (this.options.format) {
    this.indentate = indentate;
    this.tagEndChar = '>\n';
    this.newLine = '\n';
  } else {
    this.indentate = function() {
      return '';
    };
    this.tagEndChar = '>';
    this.newLine = '';
  }

  if (this.options.suppressEmptyNode) {
    this.buildTextNode = buildEmptyTextNode;
    this.buildObjNode = buildEmptyObjNode;
  } else {
    this.buildTextNode = buildTextValNode;
    this.buildObjNode = buildObjectNode;
  }

  this.buildTextValNode = buildTextValNode;
  this.buildObjectNode = buildObjectNode;

  this.replaceEntitiesValue = replaceEntitiesValue;
  this.buildAttrPairStr = buildAttrPairStr;
}

Builder.prototype.build = function(jObj) {
  if(this.options.preserveOrder){
    return buildFromOrderedJs(jObj, this.options);
  }else {
    if(Array.isArray(jObj) && this.options.arrayNodeName && this.options.arrayNodeName.length > 1){
      jObj = {
        [this.options.arrayNodeName] : jObj
      }
    }
    return this.j2x(jObj, 0).val;
  }
};

Builder.prototype.j2x = function(jObj, level) {
  let attrStr = '';
  let val = '';
  for (let key in jObj) {
    if (typeof jObj[key] === 'undefined') {
      // supress undefined node
    } else if (jObj[key] === null) {
      if(key[0] === "?") val += this.indentate(level) + '<' + key + '?' + this.tagEndChar;
      else val += this.indentate(level) + '<' + key + '/' + this.tagEndChar;
      // val += this.indentate(level) + '<' + key + '/' + this.tagEndChar;
    } else if (jObj[key] instanceof Date) {
      val += this.buildTextNode(jObj[key], key, '', level);
    } else if (typeof jObj[key] !== 'object') {
      //premitive type
      const attr = this.isAttribute(key);
      if (attr) {
        attrStr += this.buildAttrPairStr(attr, '' + jObj[key]);
      }else {
        //tag value
        if (key === this.options.textNodeName) {
          let newval = this.options.tagValueProcessor(key, '' + jObj[key]);
          val += this.replaceEntitiesValue(newval);
        } else {
          val += this.buildTextNode(jObj[key], key, '', level);
        }
      }
    } else if (Array.isArray(jObj[key])) {
      //repeated nodes
      const arrLen = jObj[key].length;
      for (let j = 0; j < arrLen; j++) {
        const item = jObj[key][j];
        if (typeof item === 'undefined') {
          // supress undefined node
        } else if (item === null) {
          if(key[0] === "?") val += this.indentate(level) + '<' + key + '?' + this.tagEndChar;
          else val += this.indentate(level) + '<' + key + '/' + this.tagEndChar;
          // val += this.indentate(level) + '<' + key + '/' + this.tagEndChar;
        } else if (typeof item === 'object') {
          val += this.processTextOrObjNode(item, key, level)
        } else {
          val += this.buildTextNode(item, key, '', level);
        }
      }
    } else {
      //nested node
      if (this.options.attributesGroupName && key === this.options.attributesGroupName) {
        const Ks = Object.keys(jObj[key]);
        const L = Ks.length;
        for (let j = 0; j < L; j++) {
          attrStr += this.buildAttrPairStr(Ks[j], '' + jObj[key][Ks[j]]);
        }
      } else {
        val += this.processTextOrObjNode(jObj[key], key, level)
      }
    }
  }
  return {attrStr: attrStr, val: val};
};

function buildAttrPairStr(attrName, val){
  val = this.options.attributeValueProcessor(attrName, '' + val);
  val = this.replaceEntitiesValue(val);
  if (this.options.suppressBooleanAttributes && val === "true") {
    return ' ' + attrName;
  } else return ' ' + attrName + '="' + val + '"';
}

function processTextOrObjNode (object, key, level) {
  const result = this.j2x(object, level + 1);
  if (object[this.options.textNodeName] !== undefined && Object.keys(object).length === 1) {
    return this.buildTextNode(object[this.options.textNodeName], key, result.attrStr, level);
  } else {
    return this.buildObjNode(result.val, key, result.attrStr, level);
  }
}

function buildObjectNode(val, key, attrStr, level) {
  let tagEndExp = '</' + key + this.tagEndChar;
  let piClosingChar = "";
  
  if(key[0] === "?") {
    piClosingChar = "?";
    tagEndExp = "";
  }

  if (attrStr && val.indexOf('<') === -1) {
    return ( this.indentate(level) + '<' +  key + attrStr + piClosingChar + '>' + val + tagEndExp );
  } else if (this.options.commentPropName !== false && key === this.options.commentPropName && piClosingChar.length === 0) {
    return this.indentate(level) + `<!--${val}-->` + this.newLine;
  }else {
    return (
      this.indentate(level) + '<' + key + attrStr + piClosingChar + this.tagEndChar +
      val +
      this.indentate(level) + tagEndExp    );
  }
}

function buildEmptyObjNode(val, key, attrStr, level) {
  if (val !== '') {
    return this.buildObjectNode(val, key, attrStr, level);
  } else {
    if(key[0] === "?") return  this.indentate(level) + '<' + key + attrStr+ '?' + this.tagEndChar;
    else return  this.indentate(level) + '<' + key + attrStr + '/' + this.tagEndChar;
  }
}

function buildTextValNode(val, key, attrStr, level) {
  if (this.options.cdataPropName !== false && key === this.options.cdataPropName) {
    return this.indentate(level) + `<![CDATA[${val}]]>` +  this.newLine;
  }else if (this.options.commentPropName !== false && key === this.options.commentPropName) {
    return this.indentate(level) + `<!--${val}-->` +  this.newLine;
  }else{
    let textValue = this.options.tagValueProcessor(key, val);
    textValue = this.replaceEntitiesValue(textValue);
  
    if( textValue === '' && this.options.unpairedTags.indexOf(key) !== -1){ //unpaired
      if(this.options.suppressUnpairedNode){
        return this.indentate(level) + '<' + key + this.tagEndChar;
      }else{
        return this.indentate(level) + '<' + key + "/" + this.tagEndChar;
      }
    } else{
      return (
        this.indentate(level) + '<' + key + attrStr + '>' +
         textValue +
        '</' + key + this.tagEndChar  );
    }

  }
}

function replaceEntitiesValue(textValue){
  if(textValue && textValue.length > 0 && this.options.processEntities){
    for (let i=0; i<this.options.entities.length; i++) {
      const entity = this.options.entities[i];
      textValue = textValue.replace(entity.regex, entity.val);
    }
  }
  return textValue;
}

function buildEmptyTextNode(val, key, attrStr, level) {
  if( val === '' && this.options.unpairedTags.indexOf(key) !== -1){ //unpaired
    if(this.options.suppressUnpairedNode){
      return this.indentate(level) + '<' + key + this.tagEndChar;
    }else{
      return this.indentate(level) + '<' + key + "/" + this.tagEndChar;
    }
  }else if (val !== '') { //empty
    return this.buildTextValNode(val, key, attrStr, level);
  } else {
    if(key[0] === "?") return  this.indentate(level) + '<' + key + attrStr+ '?' + this.tagEndChar; //PI tag
    else return  this.indentate(level) + '<' + key + attrStr + '/' + this.tagEndChar; //normal
  }
}

function indentate(level) {
  return this.options.indentBy.repeat(level);
}

function isAttribute(name /*, options*/) {
  if (name.startsWith(this.options.attributeNamePrefix)) {
    return name.substr(this.attrPrefixLen);
  } else {
    return false;
  }
}

module.exports = Builder;


/***/ }),

/***/ 287:
/***/ ((module) => {

const EOL = "\n";

/**
 * 
 * @param {array} jArray 
 * @param {any} options 
 * @returns 
 */
function toXml(jArray, options){
    return arrToStr( jArray, options, "", 0);
}

function arrToStr(arr, options, jPath, level){
    let xmlStr = "";

    let indentation = "";
    if(options.format && options.indentBy.length > 0){//TODO: this logic can be avoided for each call
        indentation = EOL + "" + options.indentBy.repeat(level);
    }

    for (let i = 0; i < arr.length; i++) {
        const tagObj = arr[i];
        const tagName = propName(tagObj);
        let newJPath = "";
        if(jPath.length === 0) newJPath = tagName
        else newJPath = `${jPath}.${tagName}`;

        if(tagName === options.textNodeName){
            let tagText = tagObj[tagName];
            if(!isStopNode(newJPath, options)){
                tagText = options.tagValueProcessor( tagName, tagText);
                tagText = replaceEntitiesValue(tagText, options);
            }
            xmlStr += indentation + tagText;
            continue;
        }else if( tagName === options.cdataPropName){
            xmlStr += indentation + `<![CDATA[${tagObj[tagName][0][options.textNodeName]}]]>`;
            continue;
        }else if( tagName === options.commentPropName){
            xmlStr += indentation + `<!--${tagObj[tagName][0][options.textNodeName]}-->`;
            continue;
        }else if( tagName[0] === "?"){
            const attStr = attr_to_str(tagObj[":@"], options);
            const tempInd = tagName === "?xml" ? "" : indentation;
            let piTextNodeName = tagObj[tagName][0][options.textNodeName];
            piTextNodeName = piTextNodeName.length !== 0 ? " " + piTextNodeName : ""; //remove extra spacing
            xmlStr += tempInd + `<${tagName}${piTextNodeName}${attStr}?>`;
            continue;
        }
        const attStr = attr_to_str(tagObj[":@"], options);
        let tagStart =  indentation + `<${tagName}${attStr}`;
        let tagValue = arrToStr(tagObj[tagName], options, newJPath, level + 1);
        if(options.unpairedTags.indexOf(tagName) !== -1){
            if(options.suppressUnpairedNode)  xmlStr += tagStart + ">"; 
            else xmlStr += tagStart + "/>"; 
        }else if( (!tagValue || tagValue.length === 0) && options.suppressEmptyNode){ 
            xmlStr += tagStart + "/>"; 
        }else{ 
            //TODO: node with only text value should not parse the text value in next line
            xmlStr += tagStart + `>${tagValue}${indentation}</${tagName}>` ;
        }
    }
    
    return xmlStr;
}

function propName(obj){
    const keys = Object.keys(obj);
    for (let i = 0; i < keys.length; i++) {
      const key = keys[i];
      if(key !== ":@") return key;
    }
  }

function attr_to_str(attrMap, options){
    let attrStr = "";
    if(attrMap && !options.ignoreAttributes){
        for (let attr in attrMap){
            let attrVal = options.attributeValueProcessor(attr, attrMap[attr]);
            attrVal = replaceEntitiesValue(attrVal, options);
            if(attrVal === true && options.suppressBooleanAttributes){
                attrStr+= ` ${attr.substr(options.attributeNamePrefix.length)}`;
            }else{
                attrStr+= ` ${attr.substr(options.attributeNamePrefix.length)}="${attrVal}"`;
            }
        }
    }
    return attrStr;
}

function isStopNode(jPath, options){
    jPath = jPath.substr(0,jPath.length - options.textNodeName.length - 1);
    let tagName = jPath.substr(jPath.lastIndexOf(".") + 1);
    for(let index in options.stopNodes){
        if(options.stopNodes[index] === jPath || options.stopNodes[index] === "*."+tagName) return true;
    }
    return false;
}

function replaceEntitiesValue(textValue, options){
    if(textValue && textValue.length > 0 && options.processEntities){
      for (let i=0; i< options.entities.length; i++) {
        const entity = options.entities[i];
        textValue = textValue.replace(entity.regex, entity.val);
      }
    }
    return textValue;
  }
module.exports = toXml;

/***/ }),

/***/ 733:
/***/ ((module) => {

//TODO: handle comments
function readDocType(xmlData, i){
    
    const entities = {};
    if( xmlData[i + 3] === 'O' &&
         xmlData[i + 4] === 'C' &&
         xmlData[i + 5] === 'T' &&
         xmlData[i + 6] === 'Y' &&
         xmlData[i + 7] === 'P' &&
         xmlData[i + 8] === 'E')
    {    
        i = i+9;
        let angleBracketsCount = 1;
        let hasBody = false, entity = false, comment = false;
        let exp = "";
        for(;i<xmlData.length;i++){
            if (xmlData[i] === '<') {
                if( hasBody && 
                     xmlData[i+1] === '!' &&
                     xmlData[i+2] === 'E' &&
                     xmlData[i+3] === 'N' &&
                     xmlData[i+4] === 'T' &&
                     xmlData[i+5] === 'I' &&
                     xmlData[i+6] === 'T' &&
                     xmlData[i+7] === 'Y'
                ){
                    i += 7;
                    entity = true;
                }else if( hasBody && 
                    xmlData[i+1] === '!' &&
                     xmlData[i+2] === 'E' &&
                     xmlData[i+3] === 'L' &&
                     xmlData[i+4] === 'E' &&
                     xmlData[i+5] === 'M' &&
                     xmlData[i+6] === 'E' &&
                     xmlData[i+7] === 'N' &&
                     xmlData[i+8] === 'T'
                ){
                    //Not supported
                    i += 8;
                }else if( hasBody && 
                    xmlData[i+1] === '!' &&
                    xmlData[i+2] === 'A' &&
                    xmlData[i+3] === 'T' &&
                    xmlData[i+4] === 'T' &&
                    xmlData[i+5] === 'L' &&
                    xmlData[i+6] === 'I' &&
                    xmlData[i+7] === 'S' &&
                    xmlData[i+8] === 'T'
                ){
                    //Not supported
                    i += 8;
                }else if( hasBody && 
                    xmlData[i+1] === '!' &&
                    xmlData[i+2] === 'N' &&
                    xmlData[i+3] === 'O' &&
                    xmlData[i+4] === 'T' &&
                    xmlData[i+5] === 'A' &&
                    xmlData[i+6] === 'T' &&
                    xmlData[i+7] === 'I' &&
                    xmlData[i+8] === 'O' &&
                    xmlData[i+9] === 'N'
                ){
                    //Not supported
                    i += 9;
                }else if( //comment
                    xmlData[i+1] === '!' &&
                    xmlData[i+2] === '-' &&
                    xmlData[i+3] === '-'
                ){
                    comment = true;
                }else{
                    throw new Error("Invalid DOCTYPE");
                }
                angleBracketsCount++;
                exp = "";
            } else if (xmlData[i] === '>') {
                if(comment){
                    if( xmlData[i - 1] === "-" && xmlData[i - 2] === "-"){
                        comment = false;
                    }else{
                        throw new Error(`Invalid XML comment in DOCTYPE`);
                    }
                }else if(entity){
                    parseEntityExp(exp, entities);
                    entity = false;
                }
                angleBracketsCount--;
                if (angleBracketsCount === 0) {
                  break;
                }
            }else if( xmlData[i] === '['){
                hasBody = true;
            }else{
                exp += xmlData[i];
            }
        }
        if(angleBracketsCount !== 0){
            throw new Error(`Unclosed DOCTYPE`);
        }
    }else{
        throw new Error(`Invalid Tag instead of DOCTYPE`);
    }
    return {entities, i};
}

const entityRegex = RegExp("^\\s([a-zA-z0-0]+)[ \t](['\"])([^&]+)\\2");
function parseEntityExp(exp, entities){
    const match = entityRegex.exec(exp);
    if(match){
        entities[ match[1] ] = {
            regx : RegExp( `&${match[1]};`,"g"),
            val: match[3]
        };
    }
}
module.exports = readDocType;

/***/ }),

/***/ 757:
/***/ ((__unused_webpack_module, exports) => {


const defaultOptions = {
    preserveOrder: false,
    attributeNamePrefix: '@_',
    attributesGroupName: false,
    textNodeName: '#text',
    ignoreAttributes: true,
    removeNSPrefix: false, // remove NS from tag name or attribute name if true
    allowBooleanAttributes: false, //a tag can have attributes without any value
    //ignoreRootElement : false,
    parseTagValue: true,
    parseAttributeValue: false,
    trimValues: true, //Trim string values of tag and attributes
    cdataPropName: false,
    numberParseOptions: {
      hex: true,
      leadingZeros: true
    },
    tagValueProcessor: function(tagName, val) {
      return val;
    },
    attributeValueProcessor: function(attrName, val) {
      return val;
    },
    stopNodes: [], //nested tags will not be parsed even for errors
    alwaysCreateTextNode: false,
    isArray: () => false,
    commentPropName: false,
    unpairedTags: [],
    processEntities: true,
    htmlEntities: false,
    ignoreDeclaration: false,
    ignorePiTags: false,
    transformTagName: false,
};
   
const buildOptions = function(options) {
    return Object.assign({}, defaultOptions, options);
};

exports.buildOptions = buildOptions;
exports.defaultOptions = defaultOptions;

/***/ }),

/***/ 492:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

///@ts-check

const util = __webpack_require__(298);
const xmlNode = __webpack_require__(581);
const readDocType = __webpack_require__(733);
const toNumber = __webpack_require__(868);

const regx =
  '<((!\\[CDATA\\[([\\s\\S]*?)(]]>))|((NAME:)?(NAME))([^>]*)>|((\\/)(NAME)\\s*>))([^<]*)'
  .replace(/NAME/g, util.nameRegexp);

//const tagsRegx = new RegExp("<(\\/?[\\w:\\-\._]+)([^>]*)>(\\s*"+cdataRegx+")*([^<]+)?","g");
//const tagsRegx = new RegExp("<(\\/?)((\\w*:)?([\\w:\\-\._]+))([^>]*)>([^<]*)("+cdataRegx+"([^<]*))*([^<]+)?","g");

class OrderedObjParser{
  constructor(options){
    this.options = options;
    this.currentNode = null;
    this.tagsNodeStack = [];
    this.docTypeEntities = {};
    this.lastEntities = {
      "apos" : { regex: /&(apos|#39|#x27);/g, val : "'"},
      "gt" : { regex: /&(gt|#62|#x3E);/g, val : ">"},
      "lt" : { regex: /&(lt|#60|#x3C);/g, val : "<"},
      "quot" : { regex: /&(quot|#34|#x22);/g, val : "\""},
    };
    this.ampEntity = { regex: /&(amp|#38|#x26);/g, val : "&"};
    this.htmlEntities = {
      "space": { regex: /&(nbsp|#160);/g, val: " " },
      // "lt" : { regex: /&(lt|#60);/g, val: "<" },
      // "gt" : { regex: /&(gt|#62);/g, val: ">" },
      // "amp" : { regex: /&(amp|#38);/g, val: "&" },
      // "quot" : { regex: /&(quot|#34);/g, val: "\"" },
      // "apos" : { regex: /&(apos|#39);/g, val: "'" },
      "cent" : { regex: /&(cent|#162);/g, val: "¢" },
      "pound" : { regex: /&(pound|#163);/g, val: "£" },
      "yen" : { regex: /&(yen|#165);/g, val: "¥" },
      "euro" : { regex: /&(euro|#8364);/g, val: "€" },
      "copyright" : { regex: /&(copy|#169);/g, val: "©" },
      "reg" : { regex: /&(reg|#174);/g, val: "®" },
      "inr" : { regex: /&(inr|#8377);/g, val: "₹" },
    };
    this.addExternalEntities = addExternalEntities;
    this.parseXml = parseXml;
    this.parseTextData = parseTextData;
    this.resolveNameSpace = resolveNameSpace;
    this.buildAttributesMap = buildAttributesMap;
    this.isItStopNode = isItStopNode;
    this.replaceEntitiesValue = replaceEntitiesValue;
    this.readStopNodeData = readStopNodeData;
    this.saveTextToParentTag = saveTextToParentTag;
  }

}

function addExternalEntities(externalEntities){
  const entKeys = Object.keys(externalEntities);
  for (let i = 0; i < entKeys.length; i++) {
    const ent = entKeys[i];
    this.lastEntities[ent] = {
       regex: new RegExp("&"+ent+";","g"),
       val : externalEntities[ent]
    }
  }
}

/**
 * @param {string} val
 * @param {string} tagName
 * @param {string} jPath
 * @param {boolean} dontTrim
 * @param {boolean} hasAttributes
 * @param {boolean} isLeafNode
 * @param {boolean} escapeEntities
 */
function parseTextData(val, tagName, jPath, dontTrim, hasAttributes, isLeafNode, escapeEntities) {
  if (val !== undefined) {
    if (this.options.trimValues && !dontTrim) {
      val = val.trim();
    }
    if(val.length > 0){
      if(!escapeEntities) val = this.replaceEntitiesValue(val);
      
      const newval = this.options.tagValueProcessor(tagName, val, jPath, hasAttributes, isLeafNode);
      if(newval === null || newval === undefined){
        //don't parse
        return val;
      }else if(typeof newval !== typeof val || newval !== val){
        //overwrite
        return newval;
      }else if(this.options.trimValues){
        return parseValue(val, this.options.parseTagValue, this.options.numberParseOptions);
      }else{
        const trimmedVal = val.trim();
        if(trimmedVal === val){
          return parseValue(val, this.options.parseTagValue, this.options.numberParseOptions);
        }else{
          return val;
        }
      }
    }
  }
}

function resolveNameSpace(tagname) {
  if (this.options.removeNSPrefix) {
    const tags = tagname.split(':');
    const prefix = tagname.charAt(0) === '/' ? '/' : '';
    if (tags[0] === 'xmlns') {
      return '';
    }
    if (tags.length === 2) {
      tagname = prefix + tags[1];
    }
  }
  return tagname;
}

//TODO: change regex to capture NS
//const attrsRegx = new RegExp("([\\w\\-\\.\\:]+)\\s*=\\s*(['\"])((.|\n)*?)\\2","gm");
const attrsRegx = new RegExp('([^\\s=]+)\\s*(=\\s*([\'"])([\\s\\S]*?)\\3)?', 'gm');

function buildAttributesMap(attrStr, jPath) {
  if (!this.options.ignoreAttributes && typeof attrStr === 'string') {
    // attrStr = attrStr.replace(/\r?\n/g, ' ');
    //attrStr = attrStr || attrStr.trim();

    const matches = util.getAllMatches(attrStr, attrsRegx);
    const len = matches.length; //don't make it inline
    const attrs = {};
    for (let i = 0; i < len; i++) {
      const attrName = this.resolveNameSpace(matches[i][1]);
      let oldVal = matches[i][4];
      const aName = this.options.attributeNamePrefix + attrName;
      if (attrName.length) {
        if (oldVal !== undefined) {
          if (this.options.trimValues) {
            oldVal = oldVal.trim();
          }
          oldVal = this.replaceEntitiesValue(oldVal);
          const newVal = this.options.attributeValueProcessor(attrName, oldVal, jPath);
          if(newVal === null || newVal === undefined){
            //don't parse
            attrs[aName] = oldVal;
          }else if(typeof newVal !== typeof oldVal || newVal !== oldVal){
            //overwrite
            attrs[aName] = newVal;
          }else{
            //parse
            attrs[aName] = parseValue(
              oldVal,
              this.options.parseAttributeValue,
              this.options.numberParseOptions
            );
          }
        } else if (this.options.allowBooleanAttributes) {
          attrs[aName] = true;
        }
      }
    }
    if (!Object.keys(attrs).length) {
      return;
    }
    if (this.options.attributesGroupName) {
      const attrCollection = {};
      attrCollection[this.options.attributesGroupName] = attrs;
      return attrCollection;
    }
    return attrs;
  }
}

const parseXml = function(xmlData) {
  xmlData = xmlData.replace(/\r\n?/g, "\n"); //TODO: remove this line
  const xmlObj = new xmlNode('!xml');
  let currentNode = xmlObj;
  let textData = "";
  let jPath = "";
  for(let i=0; i< xmlData.length; i++){//for each char in XML data
    const ch = xmlData[i];
    if(ch === '<'){
      // const nextIndex = i+1;
      // const _2ndChar = xmlData[nextIndex];
      if( xmlData[i+1] === '/') {//Closing Tag
        const closeIndex = findClosingIndex(xmlData, ">", i, "Closing Tag is not closed.")
        let tagName = xmlData.substring(i+2,closeIndex).trim();

        if(this.options.removeNSPrefix){
          const colonIndex = tagName.indexOf(":");
          if(colonIndex !== -1){
            tagName = tagName.substr(colonIndex+1);
          }
        }

        if(this.options.transformTagName) {
          tagName = this.options.transformTagName(tagName);
        }

        if(currentNode){
          textData = this.saveTextToParentTag(textData, currentNode, jPath);
        }

        jPath = jPath.substr(0, jPath.lastIndexOf("."));
        
        currentNode = this.tagsNodeStack.pop();//avoid recurssion, set the parent tag scope
        textData = "";
        i = closeIndex;
      } else if( xmlData[i+1] === '?') {

        let tagData = readTagExp(xmlData,i, false, "?>");
        if(!tagData) throw new Error("Pi Tag is not closed.");

        textData = this.saveTextToParentTag(textData, currentNode, jPath);
        if( (this.options.ignoreDeclaration && tagData.tagName === "?xml") || this.options.ignorePiTags){

        }else{
  
          const childNode = new xmlNode(tagData.tagName);
          childNode.add(this.options.textNodeName, "");
          
          if(tagData.tagName !== tagData.tagExp && tagData.attrExpPresent){
            childNode[":@"] = this.buildAttributesMap(tagData.tagExp, jPath);
          }
          currentNode.addChild(childNode);

        }


        i = tagData.closeIndex + 1;
      } else if(xmlData.substr(i + 1, 3) === '!--') {
        const endIndex = findClosingIndex(xmlData, "-->", i+4, "Comment is not closed.")
        if(this.options.commentPropName){
          const comment = xmlData.substring(i + 4, endIndex - 2);

          textData = this.saveTextToParentTag(textData, currentNode, jPath);

          currentNode.add(this.options.commentPropName, [ { [this.options.textNodeName] : comment } ]);
        }
        i = endIndex;
      } else if( xmlData.substr(i + 1, 2) === '!D') {
        const result = readDocType(xmlData, i);
        this.docTypeEntities = result.entities;
        i = result.i;
      }else if(xmlData.substr(i + 1, 2) === '![') {
        const closeIndex = findClosingIndex(xmlData, "]]>", i, "CDATA is not closed.") - 2;
        const tagExp = xmlData.substring(i + 9,closeIndex);

        textData = this.saveTextToParentTag(textData, currentNode, jPath);

        //cdata should be set even if it is 0 length string
        if(this.options.cdataPropName){
          // let val = this.parseTextData(tagExp, this.options.cdataPropName, jPath + "." + this.options.cdataPropName, true, false, true);
          // if(!val) val = "";
          currentNode.add(this.options.cdataPropName, [ { [this.options.textNodeName] : tagExp } ]);
        }else{
          let val = this.parseTextData(tagExp, currentNode.tagname, jPath, true, false, true);
          if(val == undefined) val = "";
          currentNode.add(this.options.textNodeName, val);
        }
        
        i = closeIndex + 2;
      }else {//Opening tag
        let result = readTagExp(xmlData,i, this. options.removeNSPrefix);
        let tagName= result.tagName;
        let tagExp = result.tagExp;
        let attrExpPresent = result.attrExpPresent;
        let closeIndex = result.closeIndex;

        if (this.options.transformTagName) {
          tagName = this.options.transformTagName(tagName);
        }
        
        //save text as child node
        if (currentNode && textData) {
          if(currentNode.tagname !== '!xml'){
            //when nested tag is found
            textData = this.saveTextToParentTag(textData, currentNode, jPath, false);
          }
        }

        if(tagName !== xmlObj.tagname){
          jPath += jPath ? "." + tagName : tagName;
        }

        //check if last tag was unpaired tag
        const lastTag = currentNode;
        if(lastTag && this.options.unpairedTags.indexOf(lastTag.tagname) !== -1 ){
          currentNode = this.tagsNodeStack.pop();
        }

        if (this.isItStopNode(this.options.stopNodes, jPath, tagName)) { //TODO: namespace
          let tagContent = "";
          //self-closing tag
          if(tagExp.length > 0 && tagExp.lastIndexOf("/") === tagExp.length - 1){
            i = result.closeIndex;
          }
          //boolean tag
          else if(this.options.unpairedTags.indexOf(tagName) !== -1){
            i = result.closeIndex;
          }
          //normal tag
          else{
            //read until closing tag is found
            const result = this.readStopNodeData(xmlData, tagName, closeIndex + 1);
            if(!result) throw new Error(`Unexpected end of ${tagName}`);
            i = result.i;
            tagContent = result.tagContent;
          }

          const childNode = new xmlNode(tagName);
          if(tagName !== tagExp && attrExpPresent){
            childNode[":@"] = this.buildAttributesMap(tagExp, jPath);
          }
          if(tagContent) {
            tagContent = this.parseTextData(tagContent, tagName, jPath, true, attrExpPresent, true, true);
          }
          
          jPath = jPath.substr(0, jPath.lastIndexOf("."));
          childNode.add(this.options.textNodeName, tagContent);
          
          currentNode.addChild(childNode);
        }else{
  //selfClosing tag
          if(tagExp.length > 0 && tagExp.lastIndexOf("/") === tagExp.length - 1){
            if(tagName[tagName.length - 1] === "/"){ //remove trailing '/'
              tagName = tagName.substr(0, tagName.length - 1);
              tagExp = tagName;
            }else{
              tagExp = tagExp.substr(0, tagExp.length - 1);
            }
            
            if(this.options.transformTagName) {
              tagName = this.options.transformTagName(tagName);
            }

            const childNode = new xmlNode(tagName);
            if(tagName !== tagExp && attrExpPresent){
              childNode[":@"] = this.buildAttributesMap(tagExp, jPath);
            }
            jPath = jPath.substr(0, jPath.lastIndexOf("."));
            currentNode.addChild(childNode);
          }
    //opening tag
          else{
            const childNode = new xmlNode( tagName);
            this.tagsNodeStack.push(currentNode);
            
            if(tagName !== tagExp && attrExpPresent){
              childNode[":@"] = this.buildAttributesMap(tagExp, jPath);
            }
            currentNode.addChild(childNode);
            currentNode = childNode;
          }
          textData = "";
          i = closeIndex;
        }
      }
    }else{
      textData += xmlData[i];
    }
  }
  return xmlObj.child;
}

const replaceEntitiesValue = function(val){

  if(this.options.processEntities){
    for(let entityName in this.docTypeEntities){
      const entity = this.docTypeEntities[entityName];
      val = val.replace( entity.regx, entity.val);
    }
    for(let entityName in this.lastEntities){
      const entity = this.lastEntities[entityName];
      val = val.replace( entity.regex, entity.val);
    }
    if(this.options.htmlEntities){
      for(let entityName in this.htmlEntities){
        const entity = this.htmlEntities[entityName];
        val = val.replace( entity.regex, entity.val);
      }
    }
    val = val.replace( this.ampEntity.regex, this.ampEntity.val);
  }
  return val;
}
function saveTextToParentTag(textData, currentNode, jPath, isLeafNode) {
  if (textData) { //store previously collected data as textNode
    if(isLeafNode === undefined) isLeafNode = Object.keys(currentNode.child).length === 0
    
    textData = this.parseTextData(textData,
      currentNode.tagname,
      jPath,
      false,
      currentNode[":@"] ? Object.keys(currentNode[":@"]).length !== 0 : false,
      isLeafNode);

    if (textData !== undefined && textData !== "")
      currentNode.add(this.options.textNodeName, textData);
    textData = "";
  }
  return textData;
}

//TODO: use jPath to simplify the logic
/**
 * 
 * @param {string[]} stopNodes 
 * @param {string} jPath
 * @param {string} currentTagName 
 */
function isItStopNode(stopNodes, jPath, currentTagName){
  const allNodesExp = "*." + currentTagName;
  for (const stopNodePath in stopNodes) {
    const stopNodeExp = stopNodes[stopNodePath];
    if( allNodesExp === stopNodeExp || jPath === stopNodeExp  ) return true;
  }
  return false;
}

/**
 * Returns the tag Expression and where it is ending handling single-dobule quotes situation
 * @param {string} xmlData 
 * @param {number} i starting index
 * @returns 
 */
function tagExpWithClosingIndex(xmlData, i, closingChar = ">"){
  let attrBoundary;
  let tagExp = "";
  for (let index = i; index < xmlData.length; index++) {
    let ch = xmlData[index];
    if (attrBoundary) {
        if (ch === attrBoundary) attrBoundary = "";//reset
    } else if (ch === '"' || ch === "'") {
        attrBoundary = ch;
    } else if (ch === closingChar[0]) {
      if(closingChar[1]){
        if(xmlData[index + 1] === closingChar[1]){
          return {
            data: tagExp,
            index: index
          }
        }
      }else{
        return {
          data: tagExp,
          index: index
        }
      }
    } else if (ch === '\t') {
      ch = " "
    }
    tagExp += ch;
  }
}

function findClosingIndex(xmlData, str, i, errMsg){
  const closingIndex = xmlData.indexOf(str, i);
  if(closingIndex === -1){
    throw new Error(errMsg)
  }else{
    return closingIndex + str.length - 1;
  }
}

function readTagExp(xmlData,i, removeNSPrefix, closingChar = ">"){
  const result = tagExpWithClosingIndex(xmlData, i+1, closingChar);
  if(!result) return;
  let tagExp = result.data;
  const closeIndex = result.index;
  const separatorIndex = tagExp.search(/\s/);
  let tagName = tagExp;
  let attrExpPresent = true;
  if(separatorIndex !== -1){//separate tag name and attributes expression
    tagName = tagExp.substr(0, separatorIndex).replace(/\s\s*$/, '');
    tagExp = tagExp.substr(separatorIndex + 1);
  }

  if(removeNSPrefix){
    const colonIndex = tagName.indexOf(":");
    if(colonIndex !== -1){
      tagName = tagName.substr(colonIndex+1);
      attrExpPresent = tagName !== result.data.substr(colonIndex + 1);
    }
  }

  return {
    tagName: tagName,
    tagExp: tagExp,
    closeIndex: closeIndex,
    attrExpPresent: attrExpPresent,
  }
}
/**
 * find paired tag for a stop node
 * @param {string} xmlData 
 * @param {string} tagName 
 * @param {number} i 
 */
function readStopNodeData(xmlData, tagName, i){
  const startIndex = i;
  // Starting at 1 since we already have an open tag
  let openTagCount = 1;

  for (; i < xmlData.length; i++) {
    if( xmlData[i] === "<"){ 
      if (xmlData[i+1] === "/") {//close tag
          const closeIndex = findClosingIndex(xmlData, ">", i, `${tagName} is not closed`);
          let closeTagName = xmlData.substring(i+2,closeIndex).trim();
          if(closeTagName === tagName){
            openTagCount--;
            if (openTagCount === 0) {
              return {
                tagContent: xmlData.substring(startIndex, i),
                i : closeIndex
              }
            }
          }
          i=closeIndex;
        } else if(xmlData[i+1] === '?') { 
          const closeIndex = findClosingIndex(xmlData, "?>", i+1, "StopNode is not closed.")
          i=closeIndex;
        } else if(xmlData.substr(i + 1, 3) === '!--') { 
          const closeIndex = findClosingIndex(xmlData, "-->", i+3, "StopNode is not closed.")
          i=closeIndex;
        } else if(xmlData.substr(i + 1, 2) === '![') { 
          const closeIndex = findClosingIndex(xmlData, "]]>", i, "StopNode is not closed.") - 2;
          i=closeIndex;
        } else {
          const tagData = readTagExp(xmlData, i, '>')

          if (tagData) {
            const openTagName = tagData && tagData.tagName;
            if (openTagName === tagName && tagData.tagExp[tagData.tagExp.length-1] !== "/") {
              openTagCount++;
            }
            i=tagData.closeIndex;
          }
        }
      }
  }//end for loop
}

function parseValue(val, shouldParse, options) {
  if (shouldParse && typeof val === 'string') {
    //console.log(options)
    const newval = val.trim();
    if(newval === 'true' ) return true;
    else if(newval === 'false' ) return false;
    else return toNumber(val, options);
  } else {
    if (util.isExist(val)) {
      return val;
    } else {
      return '';
    }
  }
}


module.exports = OrderedObjParser;


/***/ }),

/***/ 696:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const { buildOptions} = __webpack_require__(757);
const OrderedObjParser = __webpack_require__(492);
const { prettify} = __webpack_require__(200);
const validator = __webpack_require__(754);

class XMLParser{
    
    constructor(options){
        this.externalEntities = {};
        this.options = buildOptions(options);
        
    }
    /**
     * Parse XML dats to JS object 
     * @param {string|Buffer} xmlData 
     * @param {boolean|Object} validationOption 
     */
    parse(xmlData,validationOption){
        if(typeof xmlData === "string"){
        }else if( xmlData.toString){
            xmlData = xmlData.toString();
        }else{
            throw new Error("XML data is accepted in String or Bytes[] form.")
        }
        if( validationOption){
            if(validationOption === true) validationOption = {}; //validate with default options
            
            const result = validator.validate(xmlData, validationOption);
            if (result !== true) {
              throw Error( `${result.err.msg}:${result.err.line}:${result.err.col}` )
            }
          }
        const orderedObjParser = new OrderedObjParser(this.options);
        orderedObjParser.addExternalEntities(this.externalEntities);
        const orderedResult = orderedObjParser.parseXml(xmlData);
        if(this.options.preserveOrder || orderedResult === undefined) return orderedResult;
        else return prettify(orderedResult, this.options);
    }

    /**
     * Add Entity which is not by default supported by this library
     * @param {string} key 
     * @param {string} value 
     */
    addEntity(key, value){
        if(value.indexOf("&") !== -1){
            throw new Error("Entity value can't have '&'")
        }else if(key.indexOf("&") !== -1 || key.indexOf(";") !== -1){
            throw new Error("An entity must be set without '&' and ';'. Eg. use '#xD' for '&#xD;'")
        }else if(value === "&"){
            throw new Error("An entity with value '&' is not permitted");
        }else{
            this.externalEntities[key] = value;
        }
    }
}

module.exports = XMLParser;

/***/ }),

/***/ 200:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


/**
 * 
 * @param {array} node 
 * @param {any} options 
 * @returns 
 */
function prettify(node, options){
  return compress( node, options);
}

/**
 * 
 * @param {array} arr 
 * @param {object} options 
 * @param {string} jPath 
 * @returns object
 */
function compress(arr, options, jPath){
  let text;
  const compressedObj = {};
  for (let i = 0; i < arr.length; i++) {
    const tagObj = arr[i];
    const property = propName(tagObj);
    let newJpath = "";
    if(jPath === undefined) newJpath = property;
    else newJpath = jPath + "." + property;

    if(property === options.textNodeName){
      if(text === undefined) text = tagObj[property];
      else text += "" + tagObj[property];
    }else if(property === undefined){
      continue;
    }else if(tagObj[property]){
      
      let val = compress(tagObj[property], options, newJpath);
      const isLeaf = isLeafTag(val, options);

      if(tagObj[":@"]){
        assignAttributes( val, tagObj[":@"], newJpath, options);
      }else if(Object.keys(val).length === 1 && val[options.textNodeName] !== undefined && !options.alwaysCreateTextNode){
        val = val[options.textNodeName];
      }else if(Object.keys(val).length === 0){
        if(options.alwaysCreateTextNode) val[options.textNodeName] = "";
        else val = "";
      }

      if(compressedObj[property] !== undefined && compressedObj.hasOwnProperty(property)) {
        if(!Array.isArray(compressedObj[property])) {
            compressedObj[property] = [ compressedObj[property] ];
        }
        compressedObj[property].push(val);
      }else{
        //TODO: if a node is not an array, then check if it should be an array
        //also determine if it is a leaf node
        if (options.isArray(property, newJpath, isLeaf )) {
          compressedObj[property] = [val];
        }else{
          compressedObj[property] = val;
        }
      }
    }
    
  }
  // if(text && text.length > 0) compressedObj[options.textNodeName] = text;
  if(typeof text === "string"){
    if(text.length > 0) compressedObj[options.textNodeName] = text;
  }else if(text !== undefined) compressedObj[options.textNodeName] = text;
  return compressedObj;
}

function propName(obj){
  const keys = Object.keys(obj);
  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    if(key !== ":@") return key;
  }
}

function assignAttributes(obj, attrMap, jpath, options){
  if (attrMap) {
    const keys = Object.keys(attrMap);
    const len = keys.length; //don't make it inline
    for (let i = 0; i < len; i++) {
      const atrrName = keys[i];
      if (options.isArray(atrrName, jpath + "." + atrrName, true, true)) {
        obj[atrrName] = [ attrMap[atrrName] ];
      } else {
        obj[atrrName] = attrMap[atrrName];
      }
    }
  }
}

function isLeafTag(obj, options){
  const propCount = Object.keys(obj).length;
  if( propCount === 0 || (propCount === 1 && obj[options.textNodeName]) ) return true;
  return false;
}
exports.prettify = prettify;


/***/ }),

/***/ 581:
/***/ ((module) => {

"use strict";


class XmlNode{
  constructor(tagname) {
    this.tagname = tagname;
    this.child = []; //nested tags, text, cdata, comments in order
    this[":@"] = {}; //attributes map
  }
  add(key,val){
    // this.child.push( {name : key, val: val, isCdata: isCdata });
    this.child.push( {[key]: val });
  }
  addChild(node) {
    if(node[":@"] && Object.keys(node[":@"]).length > 0){
      this.child.push( { [node.tagname]: node.child, [":@"]: node[":@"] });
    }else{
      this.child.push( { [node.tagname]: node.child });
    }
  };
};


module.exports = XmlNode;

/***/ }),

/***/ 187:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/**
 * Mnemonist LRUCache
 * ===================
 *
 * JavaScript implementation of the LRU Cache data structure. To save up
 * memory and allocations this implementation represents its underlying
 * doubly-linked list as static arrays and pointers. Thus, memory is allocated
 * only once at instantiation and JS objects are never created to serve as
 * pointers. This also means this implementation does not trigger too many
 * garbage collections.
 *
 * Note that to save up memory, a LRU Cache can be implemented using a singly
 * linked list by storing predecessors' pointers as hashmap values.
 * However, this means more hashmap lookups and would probably slow the whole
 * thing down. What's more, pointers are not the things taking most space in
 * memory.
 */
var Iterator = __webpack_require__(217),
    forEach = __webpack_require__(210),
    typed = __webpack_require__(670),
    iterables = __webpack_require__(118);

/**
 * LRUCache.
 *
 * @constructor
 * @param {function} Keys     - Array class for storing keys.
 * @param {function} Values   - Array class for storing values.
 * @param {number}   capacity - Desired capacity.
 */
function LRUCache(Keys, Values, capacity) {
  if (arguments.length < 2) {
    capacity = Keys;
    Keys = null;
    Values = null;
  }

  this.capacity = capacity;

  if (typeof this.capacity !== 'number' || this.capacity <= 0)
    throw new Error('mnemonist/lru-cache: capacity should be positive number.');

  var PointerArray = typed.getPointerArray(capacity);

  this.forward = new PointerArray(capacity);
  this.backward = new PointerArray(capacity);
  this.K = typeof Keys === 'function' ? new Keys(capacity) : new Array(capacity);
  this.V = typeof Values === 'function' ? new Values(capacity) : new Array(capacity);

  // Properties
  this.size = 0;
  this.head = 0;
  this.tail = 0;
  this.items = {};
}

/**
 * Method used to clear the structure.
 *
 * @return {undefined}
 */
LRUCache.prototype.clear = function() {
  this.size = 0;
  this.head = 0;
  this.tail = 0;
  this.items = {};
};

/**
 * Method used to splay a value on top.
 *
 * @param  {number}   pointer - Pointer of the value to splay on top.
 * @return {LRUCache}
 */
LRUCache.prototype.splayOnTop = function(pointer) {
  var oldHead = this.head;

  if (this.head === pointer)
    return this;

  var previous = this.backward[pointer],
      next = this.forward[pointer];

  if (this.tail === pointer) {
    this.tail = previous;
  }
  else {
    this.backward[next] = previous;
  }

  this.forward[previous] = next;

  this.backward[oldHead] = pointer;
  this.head = pointer;
  this.forward[pointer] = oldHead;

  return this;
};

/**
 * Method used to set the value for the given key in the cache.
 *
 * @param  {any} key   - Key.
 * @param  {any} value - Value.
 * @return {undefined}
 */
LRUCache.prototype.set = function(key, value) {

  // The key already exists, we just need to update the value and splay on top
  var pointer = this.items[key];

  if (typeof pointer !== 'undefined') {
    this.splayOnTop(pointer);
    this.V[pointer] = value;

    return;
  }

  // The cache is not yet full
  if (this.size < this.capacity) {
    pointer = this.size++;
  }

  // Cache is full, we need to drop the last value
  else {
    pointer = this.tail;
    this.tail = this.backward[pointer];
    delete this.items[this.K[pointer]];
  }

  // Storing key & value
  this.items[key] = pointer;
  this.K[pointer] = key;
  this.V[pointer] = value;

  // Moving the item at the front of the list
  this.forward[pointer] = this.head;
  this.backward[this.head] = pointer;
  this.head = pointer;
};

/**
 * Method used to set the value for the given key in the cache
 *
 * @param  {any} key   - Key.
 * @param  {any} value - Value.
 * @return {{evicted: boolean, key: any, value: any}} An object containing the
 * key and value of an item that was overwritten or evicted in the set
 * operation, as well as a boolean indicating whether it was evicted due to
 * limited capacity. Return value is null if nothing was evicted or overwritten
 * during the set operation.
 */
LRUCache.prototype.setpop = function(key, value) {
  var oldValue = null;
  var oldKey = null;
  // The key already exists, we just need to update the value and splay on top
  var pointer = this.items[key];

  if (typeof pointer !== 'undefined') {
    this.splayOnTop(pointer);
    oldValue = this.V[pointer];
    this.V[pointer] = value;
    return {evicted: false, key: key, value: oldValue};
  }

  // The cache is not yet full
  if (this.size < this.capacity) {
    pointer = this.size++;
  }

  // Cache is full, we need to drop the last value
  else {
    pointer = this.tail;
    this.tail = this.backward[pointer];
    oldValue = this.V[pointer];
    oldKey = this.K[pointer];
    delete this.items[this.K[pointer]];
  }

  // Storing key & value
  this.items[key] = pointer;
  this.K[pointer] = key;
  this.V[pointer] = value;

  // Moving the item at the front of the list
  this.forward[pointer] = this.head;
  this.backward[this.head] = pointer;
  this.head = pointer;

  // Return object if eviction took place, otherwise return null
  if (oldKey) {
    return {evicted: true, key: oldKey, value: oldValue};
  }
  else {
    return null;
  }
};

/**
 * Method used to check whether the key exists in the cache.
 *
 * @param  {any} key   - Key.
 * @return {boolean}
 */
LRUCache.prototype.has = function(key) {
  return key in this.items;
};

/**
 * Method used to get the value attached to the given key. Will move the
 * related key to the front of the underlying linked list.
 *
 * @param  {any} key   - Key.
 * @return {any}
 */
LRUCache.prototype.get = function(key) {
  var pointer = this.items[key];

  if (typeof pointer === 'undefined')
    return;

  this.splayOnTop(pointer);

  return this.V[pointer];
};

/**
 * Method used to get the value attached to the given key. Does not modify
 * the ordering of the underlying linked list.
 *
 * @param  {any} key   - Key.
 * @return {any}
 */
LRUCache.prototype.peek = function(key) {
    var pointer = this.items[key];

    if (typeof pointer === 'undefined')
        return;

    return this.V[pointer];
};

/**
 * Method used to iterate over the cache's entries using a callback.
 *
 * @param  {function}  callback - Function to call for each item.
 * @param  {object}    scope    - Optional scope.
 * @return {undefined}
 */
LRUCache.prototype.forEach = function(callback, scope) {
  scope = arguments.length > 1 ? scope : this;

  var i = 0,
      l = this.size;

  var pointer = this.head,
      keys = this.K,
      values = this.V,
      forward = this.forward;

  while (i < l) {

    callback.call(scope, values[pointer], keys[pointer], this);
    pointer = forward[pointer];

    i++;
  }
};

/**
 * Method used to create an iterator over the cache's keys from most
 * recently used to least recently used.
 *
 * @return {Iterator}
 */
LRUCache.prototype.keys = function() {
  var i = 0,
      l = this.size;

  var pointer = this.head,
      keys = this.K,
      forward = this.forward;

  return new Iterator(function() {
    if (i >= l)
      return {done: true};

    var key = keys[pointer];

    i++;

    if (i < l)
      pointer = forward[pointer];

    return {
      done: false,
      value: key
    };
  });
};

/**
 * Method used to create an iterator over the cache's values from most
 * recently used to least recently used.
 *
 * @return {Iterator}
 */
LRUCache.prototype.values = function() {
  var i = 0,
      l = this.size;

  var pointer = this.head,
      values = this.V,
      forward = this.forward;

  return new Iterator(function() {
    if (i >= l)
      return {done: true};

    var value = values[pointer];

    i++;

    if (i < l)
      pointer = forward[pointer];

    return {
      done: false,
      value: value
    };
  });
};

/**
 * Method used to create an iterator over the cache's entries from most
 * recently used to least recently used.
 *
 * @return {Iterator}
 */
LRUCache.prototype.entries = function() {
  var i = 0,
      l = this.size;

  var pointer = this.head,
      keys = this.K,
      values = this.V,
      forward = this.forward;

  return new Iterator(function() {
    if (i >= l)
      return {done: true};

    var key = keys[pointer],
        value = values[pointer];

    i++;

    if (i < l)
      pointer = forward[pointer];

    return {
      done: false,
      value: [key, value]
    };
  });
};

/**
 * Attaching the #.entries method to Symbol.iterator if possible.
 */
if (typeof Symbol !== 'undefined')
  LRUCache.prototype[Symbol.iterator] = LRUCache.prototype.entries;

/**
 * Convenience known methods.
 */
LRUCache.prototype.inspect = function() {
  var proxy = new Map();

  var iterator = this.entries(),
      step;

  while ((step = iterator.next(), !step.done))
    proxy.set(step.value[0], step.value[1]);

  // Trick so that node displays the name of the constructor
  Object.defineProperty(proxy, 'constructor', {
    value: LRUCache,
    enumerable: false
  });

  return proxy;
};

if (typeof Symbol !== 'undefined')
  LRUCache.prototype[Symbol.for('nodejs.util.inspect.custom')] = LRUCache.prototype.inspect;

/**
 * Static @.from function taking an arbitrary iterable & converting it into
 * a structure.
 *
 * @param  {Iterable} iterable - Target iterable.
 * @param  {function} Keys     - Array class for storing keys.
 * @param  {function} Values   - Array class for storing values.
 * @param  {number}   capacity - Cache's capacity.
 * @return {LRUCache}
 */
LRUCache.from = function(iterable, Keys, Values, capacity) {
  if (arguments.length < 2) {
    capacity = iterables.guessLength(iterable);

    if (typeof capacity !== 'number')
      throw new Error('mnemonist/lru-cache.from: could not guess iterable length. Please provide desired capacity as last argument.');
  }
  else if (arguments.length === 2) {
    capacity = Keys;
    Keys = null;
    Values = null;
  }

  var cache = new LRUCache(Keys, Values, capacity);

  forEach(iterable, function(value, key) {
    cache.set(key, value);
  });

  return cache;
};

/**
 * Exporting.
 */
module.exports = LRUCache;


/***/ }),

/***/ 118:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

/**
 * Mnemonist Iterable Function
 * ============================
 *
 * Harmonized iteration helpers over mixed iterable targets.
 */
var forEach = __webpack_require__(210);

var typed = __webpack_require__(670);

/**
 * Function used to determine whether the given object supports array-like
 * random access.
 *
 * @param  {any} target - Target object.
 * @return {boolean}
 */
function isArrayLike(target) {
  return Array.isArray(target) || typed.isTypedArray(target);
}

/**
 * Function used to guess the length of the structure over which we are going
 * to iterate.
 *
 * @param  {any} target - Target object.
 * @return {number|undefined}
 */
function guessLength(target) {
  if (typeof target.length === 'number')
    return target.length;

  if (typeof target.size === 'number')
    return target.size;

  return;
}

/**
 * Function used to convert an iterable to an array.
 *
 * @param  {any}   target - Iteration target.
 * @return {array}
 */
function toArray(target) {
  var l = guessLength(target);

  var array = typeof l === 'number' ? new Array(l) : [];

  var i = 0;

  // TODO: we could optimize when given target is array like
  forEach(target, function(value) {
    array[i++] = value;
  });

  return array;
}

/**
 * Same as above but returns a supplementary indices array.
 *
 * @param  {any}   target - Iteration target.
 * @return {array}
 */
function toArrayWithIndices(target) {
  var l = guessLength(target);

  var IndexArray = typeof l === 'number' ?
    typed.getPointerArray(l) :
    Array;

  var array = typeof l === 'number' ? new Array(l) : [];
  var indices = typeof l === 'number' ? new IndexArray(l) : [];

  var i = 0;

  // TODO: we could optimize when given target is array like
  forEach(target, function(value) {
    array[i] = value;
    indices[i] = i++;
  });

  return [array, indices];
}

/**
 * Exporting.
 */
exports.isArrayLike = isArrayLike;
exports.guessLength = guessLength;
exports.toArray = toArray;
exports.toArrayWithIndices = toArrayWithIndices;


/***/ }),

/***/ 670:
/***/ ((__unused_webpack_module, exports) => {

/**
 * Mnemonist Typed Array Helpers
 * ==============================
 *
 * Miscellaneous helpers related to typed arrays.
 */

/**
 * When using an unsigned integer array to store pointers, one might want to
 * choose the optimal word size in regards to the actual numbers of pointers
 * to store.
 *
 * This helpers does just that.
 *
 * @param  {number} size - Expected size of the array to map.
 * @return {TypedArray}
 */
var MAX_8BIT_INTEGER = Math.pow(2, 8) - 1,
    MAX_16BIT_INTEGER = Math.pow(2, 16) - 1,
    MAX_32BIT_INTEGER = Math.pow(2, 32) - 1;

var MAX_SIGNED_8BIT_INTEGER = Math.pow(2, 7) - 1,
    MAX_SIGNED_16BIT_INTEGER = Math.pow(2, 15) - 1,
    MAX_SIGNED_32BIT_INTEGER = Math.pow(2, 31) - 1;

exports.getPointerArray = function(size) {
  var maxIndex = size - 1;

  if (maxIndex <= MAX_8BIT_INTEGER)
    return Uint8Array;

  if (maxIndex <= MAX_16BIT_INTEGER)
    return Uint16Array;

  if (maxIndex <= MAX_32BIT_INTEGER)
    return Uint32Array;

  return Float64Array;
};

exports.getSignedPointerArray = function(size) {
  var maxIndex = size - 1;

  if (maxIndex <= MAX_SIGNED_8BIT_INTEGER)
    return Int8Array;

  if (maxIndex <= MAX_SIGNED_16BIT_INTEGER)
    return Int16Array;

  if (maxIndex <= MAX_SIGNED_32BIT_INTEGER)
    return Int32Array;

  return Float64Array;
};

/**
 * Function returning the minimal type able to represent the given number.
 *
 * @param  {number} value - Value to test.
 * @return {TypedArrayClass}
 */
exports.getNumberType = function(value) {

  // <= 32 bits itnteger?
  if (value === (value | 0)) {

    // Negative
    if (Math.sign(value) === -1) {
      if (value <= 127 && value >= -128)
        return Int8Array;

      if (value <= 32767 && value >= -32768)
        return Int16Array;

      return Int32Array;
    }
    else {

      if (value <= 255)
        return Uint8Array;

      if (value <= 65535)
        return Uint16Array;

      return Uint32Array;
    }
  }

  // 53 bits integer & floats
  // NOTE: it's kinda hard to tell whether we could use 32bits or not...
  return Float64Array;
};

/**
 * Function returning the minimal type able to represent the given array
 * of JavaScript numbers.
 *
 * @param  {array}    array  - Array to represent.
 * @param  {function} getter - Optional getter.
 * @return {TypedArrayClass}
 */
var TYPE_PRIORITY = {
  Uint8Array: 1,
  Int8Array: 2,
  Uint16Array: 3,
  Int16Array: 4,
  Uint32Array: 5,
  Int32Array: 6,
  Float32Array: 7,
  Float64Array: 8
};

// TODO: make this a one-shot for one value
exports.getMinimalRepresentation = function(array, getter) {
  var maxType = null,
      maxPriority = 0,
      p,
      t,
      v,
      i,
      l;

  for (i = 0, l = array.length; i < l; i++) {
    v = getter ? getter(array[i]) : array[i];
    t = exports.getNumberType(v);
    p = TYPE_PRIORITY[t.name];

    if (p > maxPriority) {
      maxPriority = p;
      maxType = t;
    }
  }

  return maxType;
};

/**
 * Function returning whether the given value is a typed array.
 *
 * @param  {any} value - Value to test.
 * @return {boolean}
 */
exports.isTypedArray = function(value) {
  return typeof ArrayBuffer !== 'undefined' && ArrayBuffer.isView(value);
};

/**
 * Function used to concat byte arrays.
 *
 * @param  {...ByteArray}
 * @return {ByteArray}
 */
exports.concat = function() {
  var length = 0,
      i,
      o,
      l;

  for (i = 0, l = arguments.length; i < l; i++)
    length += arguments[i].length;

  var array = new (arguments[0].constructor)(length);

  for (i = 0, o = 0; i < l; i++) {
    array.set(arguments[i], o);
    o += arguments[i].length;
  }

  return array;
};

/**
 * Function used to initialize a byte array of indices.
 *
 * @param  {number}    length - Length of target.
 * @return {ByteArray}
 */
exports.indices = function(length) {
  var PointerArray = exports.getPointerArray(length);

  var array = new PointerArray(length);

  for (var i = 0; i < length; i++)
    array[i] = i;

  return array;
};


/***/ }),

/***/ 210:
/***/ ((module) => {

/**
 * Obliterator ForEach Function
 * =============================
 *
 * Helper function used to easily iterate over mixed values.
 */

/**
 * Constants.
 */
var ARRAY_BUFFER_SUPPORT = typeof ArrayBuffer !== 'undefined',
    SYMBOL_SUPPORT = typeof Symbol !== 'undefined';

/**
 * Function able to iterate over almost any iterable JS value.
 *
 * @param  {any}      iterable - Iterable value.
 * @param  {function} callback - Callback function.
 */
function forEach(iterable, callback) {
  var iterator, k, i, l, s;

  if (!iterable)
    throw new Error('obliterator/forEach: invalid iterable.');

  if (typeof callback !== 'function')
    throw new Error('obliterator/forEach: expecting a callback.');

  // The target is an array or a string or function arguments
  if (
    Array.isArray(iterable) ||
    (ARRAY_BUFFER_SUPPORT && ArrayBuffer.isView(iterable)) ||
    typeof iterable === 'string' ||
    iterable.toString() === '[object Arguments]'
  ) {
    for (i = 0, l = iterable.length; i < l; i++)
      callback(iterable[i], i);
    return;
  }

  // The target has a #.forEach method
  if (typeof iterable.forEach === 'function') {
    iterable.forEach(callback);
    return;
  }

  // The target is iterable
  if (
    SYMBOL_SUPPORT &&
    Symbol.iterator in iterable &&
    typeof iterable.next !== 'function'
  ) {
    iterable = iterable[Symbol.iterator]();
  }

  // The target is an iterator
  if (typeof iterable.next === 'function') {
    iterator = iterable;
    i = 0;

    while ((s = iterator.next(), s.done !== true)) {
      callback(s.value, i);
      i++;
    }

    return;
  }

  // The target is a plain object
  for (k in iterable) {
    if (iterable.hasOwnProperty(k)) {
      callback(iterable[k], k);
    }
  }

  return;
}

/**
 * Same function as the above `forEach` but will yield `null` when the target
 * does not have keys.
 *
 * @param  {any}      iterable - Iterable value.
 * @param  {function} callback - Callback function.
 */
forEach.forEachWithNullKeys = function(iterable, callback) {
  var iterator, k, i, l, s;

  if (!iterable)
    throw new Error('obliterator/forEachWithNullKeys: invalid iterable.');

  if (typeof callback !== 'function')
    throw new Error('obliterator/forEachWithNullKeys: expecting a callback.');

  // The target is an array or a string or function arguments
  if (
    Array.isArray(iterable) ||
    (ARRAY_BUFFER_SUPPORT && ArrayBuffer.isView(iterable)) ||
    typeof iterable === 'string' ||
    iterable.toString() === '[object Arguments]'
  ) {
    for (i = 0, l = iterable.length; i < l; i++)
      callback(iterable[i], null);
    return;
  }

  // The target is a Set
  if (iterable instanceof Set) {
    iterable.forEach(function(value) {
      callback(value, null);
    });
    return;
  }

  // The target has a #.forEach method
  if (typeof iterable.forEach === 'function') {
    iterable.forEach(callback);
    return;
  }

  // The target is iterable
  if (
    SYMBOL_SUPPORT &&
    Symbol.iterator in iterable &&
    typeof iterable.next !== 'function'
  ) {
    iterable = iterable[Symbol.iterator]();
  }

  // The target is an iterator
  if (typeof iterable.next === 'function') {
    iterator = iterable;
    i = 0;

    while ((s = iterator.next(), s.done !== true)) {
      callback(s.value, null);
      i++;
    }

    return;
  }

  // The target is a plain object
  for (k in iterable) {
    if (iterable.hasOwnProperty(k)) {
      callback(iterable[k], k);
    }
  }

  return;
};

/**
 * Exporting.
 */
module.exports = forEach;


/***/ }),

/***/ 217:
/***/ ((module) => {

/**
 * Obliterator Iterator Class
 * ===========================
 *
 * Simple class representing the library's iterators.
 */

/**
 * Iterator class.
 *
 * @constructor
 * @param {function} next - Next function.
 */
function Iterator(next) {

  // Hiding the given function
  Object.defineProperty(this, '_next', {
    writable: false,
    enumerable: false,
    value: next
  });

  // Is the iterator complete?
  this.done = false;
}

/**
 * Next function.
 *
 * @return {object}
 */
// NOTE: maybe this should dropped for performance?
Iterator.prototype.next = function() {
  if (this.done)
    return {done: true};

  var step = this._next();

  if (step.done)
    this.done = true;

  return step;
};

/**
 * If symbols are supported, we add `next` to `Symbol.iterator`.
 */
if (typeof Symbol !== 'undefined')
  Iterator.prototype[Symbol.iterator] = function() {
    return this;
  };

/**
 * Returning an iterator of the given values.
 *
 * @param  {any...} values - Values.
 * @return {Iterator}
 */
Iterator.of = function() {
  var args = arguments,
      l = args.length,
      i = 0;

  return new Iterator(function() {
    if (i >= l)
      return {done: true};

    return {done: false, value: args[i++]};
  });
};

/**
 * Returning an empty iterator.
 *
 * @return {Iterator}
 */
Iterator.empty = function() {
  var iterator = new Iterator(null);
  iterator.done = true;

  return iterator;
};

/**
 * Returning whether the given value is an iterator.
 *
 * @param  {any} value - Value.
 * @return {boolean}
 */
Iterator.is = function(value) {
  if (value instanceof Iterator)
    return true;

  return (
    typeof value === 'object' &&
    value !== null &&
    typeof value.next === 'function'
  );
};

/**
 * Exporting.
 */
module.exports = Iterator;


/***/ }),

/***/ 868:
/***/ ((module) => {

const hexRegex = /^[-+]?0x[a-fA-F0-9]+$/;
const numRegex = /^([\-\+])?(0*)(\.[0-9]+([eE]\-?[0-9]+)?|[0-9]+(\.[0-9]+([eE]\-?[0-9]+)?)?)$/;
// const octRegex = /0x[a-z0-9]+/;
// const binRegex = /0x[a-z0-9]+/;


//polyfill
if (!Number.parseInt && window.parseInt) {
    Number.parseInt = window.parseInt;
}
if (!Number.parseFloat && window.parseFloat) {
    Number.parseFloat = window.parseFloat;
}

  
const consider = {
    hex :  true,
    leadingZeros: true,
    decimalPoint: "\.",
    eNotation: true
    //skipLike: /regex/
};

function toNumber(str, options = {}){
    // const options = Object.assign({}, consider);
    // if(opt.leadingZeros === false){
    //     options.leadingZeros = false;
    // }else if(opt.hex === false){
    //     options.hex = false;
    // }

    options = Object.assign({}, consider, options );
    if(!str || typeof str !== "string" ) return str;
    
    let trimmedStr  = str.trim();
    // if(trimmedStr === "0.0") return 0;
    // else if(trimmedStr === "+0.0") return 0;
    // else if(trimmedStr === "-0.0") return -0;

    if(options.skipLike !== undefined && options.skipLike.test(trimmedStr)) return str;
    else if (options.hex && hexRegex.test(trimmedStr)) {
        return Number.parseInt(trimmedStr, 16);
    // } else if (options.parseOct && octRegex.test(str)) {
    //     return Number.parseInt(val, 8);
    // }else if (options.parseBin && binRegex.test(str)) {
    //     return Number.parseInt(val, 2);
    }else{
        //separate negative sign, leading zeros, and rest number
        const match = numRegex.exec(trimmedStr);
        if(match){
            const sign = match[1];
            const leadingZeros = match[2];
            let numTrimmedByZeros = trimZeros(match[3]); //complete num without leading zeros
            //trim ending zeros for floating number
            
            const eNotation = match[4] || match[6];
            if(!options.leadingZeros && leadingZeros.length > 0 && sign && trimmedStr[2] !== ".") return str; //-0123
            else if(!options.leadingZeros && leadingZeros.length > 0 && !sign && trimmedStr[1] !== ".") return str; //0123
            else{//no leading zeros or leading zeros are allowed
                const num = Number(trimmedStr);
                const numStr = "" + num;
                if(numStr.search(/[eE]/) !== -1){ //given number is long and parsed to eNotation
                    if(options.eNotation) return num;
                    else return str;
                }else if(eNotation){ //given number has enotation
                    if(options.eNotation) return num;
                    else return str;
                }else if(trimmedStr.indexOf(".") !== -1){ //floating number
                    // const decimalPart = match[5].substr(1);
                    // const intPart = trimmedStr.substr(0,trimmedStr.indexOf("."));

                    
                    // const p = numStr.indexOf(".");
                    // const givenIntPart = numStr.substr(0,p);
                    // const givenDecPart = numStr.substr(p+1);
                    if(numStr === "0" && (numTrimmedByZeros === "") ) return num; //0.0
                    else if(numStr === numTrimmedByZeros) return num; //0.456. 0.79000
                    else if( sign && numStr === "-"+numTrimmedByZeros) return num;
                    else return str;
                }
                
                if(leadingZeros){
                    // if(numTrimmedByZeros === numStr){
                    //     if(options.leadingZeros) return num;
                    //     else return str;
                    // }else return str;
                    if(numTrimmedByZeros === numStr) return num;
                    else if(sign+numTrimmedByZeros === numStr) return num;
                    else return str;
                }

                if(trimmedStr === numStr) return num;
                else if(trimmedStr === sign+numStr) return num;
                // else{
                //     //number with +/- sign
                //     trimmedStr.test(/[-+][0-9]);

                // }
                return str;
            }
            // else if(!eNotation && trimmedStr && trimmedStr !== Number(trimmedStr) ) return str;
            
        }else{ //non-numeric string
            return str;
        }
    }
}

/**
 * 
 * @param {string} numStr without leading zeros
 * @returns 
 */
function trimZeros(numStr){
    if(numStr && numStr.indexOf(".") !== -1){//float
        numStr = numStr.replace(/0+$/, ""); //remove ending zeros
        if(numStr === ".")  numStr = "0";
        else if(numStr[0] === ".")  numStr = "0"+numStr;
        else if(numStr[numStr.length-1] === ".")  numStr = numStr.substr(0,numStr.length-1);
        return numStr;
    }
    return numStr;
}
module.exports = toNumber


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/harmony module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.hmd = (module) => {
/******/ 			module = Object.create(module);
/******/ 			if (!module.children) module.children = [];
/******/ 			Object.defineProperty(module, 'exports', {
/******/ 				enumerable: true,
/******/ 				set: () => {
/******/ 					throw new Error('ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: ' + module.id);
/******/ 				}
/******/ 			});
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module used 'module' so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(232);
/******/ 	module.exports = __webpack_exports__;
/******/ 	
/******/ })()
;
//# sourceMappingURL=getproductslist.js.map